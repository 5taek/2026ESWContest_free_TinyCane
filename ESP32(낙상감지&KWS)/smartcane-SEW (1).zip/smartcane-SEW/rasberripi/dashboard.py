"""
시각장애인 보조기기 - PySide6 대시보드 (시연용)

ircamera(ESP32-S3, /dev/ircamera) 프로토콜에 연결된 상태:
  - 카메라 영상(TCP :8090, JPEG)   -> ircamera_link.IrCameraLink.frame_received
  - 장애물/버스OCR/점자블록 결과   -> obstacle_detected / bus_result / braille_result
  - 모드 전환(0x01/0x02 송신)      -> request_bus_mode() / request_braille_mode()
    (지금은 UI의 수동 버튼으로 트리거함. 나중에 키워드스파팅 보드(/dev/keyword, pipeline.py)가
     "1"/"2"를 인식하면 그 즉시 같은 메서드를 호출해주도록 릴레이만 붙이면 된다.)

/dev/ircamera, /dev/keyword는 ttyACM 번호가 아니라 USB 시리얼 번호로 고정한 udev 심볼릭
링크다(/etc/udev/rules.d/99-sew-boards.rules). ttyACM 번호는 연결 순서에 따라 매번 바뀌므로
직접 참조하면 안 됨. TOF(/dev/ttyACM2)는 아직 해당 보드의 시리얼 번호를 확보 못해서 번호를
그대로 쓰는 중 - 나중에 보드 꽂고 시리얼 확인해서 같은 방식으로 고정해야 함.

블루투스 이어폰 연결 상태는 BluetoothWatcher(bluetoothctl info 폴링)로 실연동됨.
GPS 연결 상태는 아직 실데이터 연동 전이라 회색 "미연동"으로 정직하게 표시만 한다
(가짜로 초록/빨강 흔드는 짓은 안 함). 실연동 붙이면 set_gps_connected()를
True/False로 호출해주면 됨.
"""

import os
import subprocess
import sys

from PySide6.QtCore import Qt, QTimer, Signal, QObject
from PySide6.QtGui import QImage, QPixmap, QColor, QPainter
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QLabel, QVBoxLayout, QHBoxLayout,
    QFrame, QGraphicsOpacityEffect, QPushButton,
)

from ircamera_link import IrCameraLink
from keyword_spotting_link import KeywordSpottingLink

TOF_PORT = "/dev/ttyACM2"  # 아직 패킷 스펙 미정, 포트 연결여부(꽂혀있는지)만 표시

# 블루투스 이어폰(DST-S02) MAC 주소. `pactl list short cards`에서 실제 오디오 카드로
# 잡히는 기기가 이거라 이 MAC을 기준으로 연결 상태를 확인한다.
BT_EARPHONE_MAC = "3C:71:57:81:77:C9"

MODE_BRAILLE = "braille"
MODE_BUS_OCR = "bus_ocr"
MODE_OBSTACLE = "obstacle"

MODE_LABELS = {
    MODE_BRAILLE: "점자블록 모드",
    MODE_BUS_OCR: "버스 OCR 모드",
    MODE_OBSTACLE: "장애물 감지 모드",
}

MODE_COLORS = {
    MODE_BRAILLE: "#5b8def",
    MODE_BUS_OCR: "#e8a33d",
    MODE_OBSTACLE: "#3ddc84",
}

BG = "#0f1115"
PANEL = "#181b21"
PANEL_BORDER = "#262a33"
TEXT_MAIN = "#eef1f6"
TEXT_SUB = "#8a90a0"
GREEN = "#3ddc84"
RED = "#e5484d"


# ============================================================
# 연결 상태 배지 (GPS / 블루투스 이어폰)
# ============================================================
class StatusBadge(QFrame):
    def __init__(self, icon: str, label: str, parent=None):
        super().__init__(parent)
        self._connected = False

        self.setObjectName("StatusBadge")
        layout = QHBoxLayout(self)
        layout.setContentsMargins(14, 8, 14, 8)
        layout.setSpacing(8)

        self.dot = QLabel("●")
        self.dot.setFixedWidth(14)

        self.icon_label = QLabel(icon)
        self.text_label = QLabel(label)
        self.state_label = QLabel("연결 안 됨")

        layout.addWidget(self.dot)
        layout.addWidget(self.icon_label)
        layout.addWidget(self.text_label)
        layout.addStretch(1)
        layout.addWidget(self.state_label)

        self.set_connected(None)

    def set_connected(self, connected):
        """connected: True(연결됨)/False(연결 안 됨)/None(아직 실데이터 미연동 - 회색으로 정직하게 표시)"""
        self._connected = connected
        if connected is None:
            color = TEXT_SUB
            text = "미연동"
        else:
            color = GREEN if connected else RED
            text = "연결됨" if connected else "연결 안 됨"
        self.dot.setStyleSheet(f"color: {color}; font-size: 14px;")
        self.state_label.setText(text)
        self.state_label.setStyleSheet(f"color: {color}; font-weight: 600;")
        self.setStyleSheet(f"""
            #StatusBadge {{
                background-color: {PANEL};
                border: 1px solid {PANEL_BORDER};
                border-radius: 10px;
            }}
        """)


# ============================================================
# 아직 패킷 프로토콜이 없는 보드(TOF 등)용 - 장치 노드가 잡혀있는지만 주기적으로 확인
# ============================================================
class PortWatcher(QObject):
    connected_changed = Signal(bool)

    def __init__(self, port: str, poll_interval_ms: int = 2000, parent=None):
        super().__init__(parent)
        self.port = port
        self._last = None
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._check)
        self._timer.start(poll_interval_ms)
        self._check()

    def _check(self):
        exists = os.path.exists(self.port)
        if exists != self._last:
            self._last = exists
            self.connected_changed.emit(exists)


# ============================================================
# 블루투스 이어폰 연결 상태 - bluetoothctl info로 주기적 확인 (호출당 ~15ms라 메인 스레드에서 돌려도 됨)
# ============================================================
class BluetoothWatcher(QObject):
    connected_changed = Signal(bool)

    def __init__(self, mac: str, poll_interval_ms: int = 3000, parent=None):
        super().__init__(parent)
        self.mac = mac
        self._last = None
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._check)
        self._timer.start(poll_interval_ms)
        # 생성 직후에는 아직 connected_changed를 아무도 구독 안 했을 수 있으니
        # 이번 이벤트루프 턴이 끝난 뒤(=호출부가 connect()까지 마친 뒤)로 첫 체크를 미룬다.
        QTimer.singleShot(0, self._check)

    def _check(self):
        try:
            result = subprocess.run(
                ["bluetoothctl", "info", self.mac],
                capture_output=True, text=True, timeout=2,
            )
            connected = "Connected: yes" in result.stdout
        except (subprocess.TimeoutExpired, FileNotFoundError):
            connected = False

        if connected != self._last:
            self._last = connected
            self.connected_changed.emit(connected)


# ============================================================
# 모드 표시 (점자블록 / 버스 OCR / 장애물 감지)
# ============================================================
class ModeBar(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("ModeBar")
        layout = QHBoxLayout(self)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.setSpacing(4)

        self._chips = {}
        for mode in (MODE_BRAILLE, MODE_BUS_OCR, MODE_OBSTACLE):
            chip = QLabel(MODE_LABELS[mode])
            chip.setAlignment(Qt.AlignCenter)
            chip.setFixedHeight(44)
            layout.addWidget(chip, 1)
            self._chips[mode] = chip

        self.set_active(MODE_OBSTACLE)

    def set_active(self, active_mode: str):
        for mode, chip in self._chips.items():
            if mode == active_mode:
                color = MODE_COLORS[mode]
                chip.setStyleSheet(f"""
                    background-color: {color};
                    color: #0f1115;
                    font-weight: 700;
                    font-size: 15px;
                    border-radius: 10px;
                """)
            else:
                chip.setStyleSheet(f"""
                    background-color: {PANEL};
                    color: {TEXT_SUB};
                    font-weight: 500;
                    font-size: 15px;
                    border: 1px solid {PANEL_BORDER};
                    border-radius: 10px;
                """)


# ============================================================
# 카메라 프리뷰 (MJPEG 프레임이 들어올 자리, 지금은 placeholder)
# ============================================================
class CameraPreview(QLabel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("CameraPreview")
        self.setMinimumSize(480, 360)
        self.setAlignment(Qt.AlignCenter)
        self.setStyleSheet(f"""
            #CameraPreview {{
                background-color: #05060a;
                border: 1px solid {PANEL_BORDER};
                border-radius: 12px;
                color: {TEXT_SUB};
                font-size: 15px;
            }}
        """)
        self.set_no_signal()

    def set_no_signal(self):
        self.setText("📷  카메라 스트림 대기 중…\n(MJPEG / Wi-Fi)")

    def set_frame(self, image: QImage):
        pix = QPixmap.fromImage(image).scaled(
            self.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation
        )
        self.setPixmap(pix)


# ============================================================
# OCR / AI 결과 패널
# ============================================================
class ResultPanel(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("ResultPanel")
        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 16, 18, 16)
        layout.setSpacing(6)

        title = QLabel("AI 인식 결과")
        title.setStyleSheet(f"color: {TEXT_SUB}; font-size: 13px; font-weight: 600;")

        self.value_label = QLabel("—")
        self.value_label.setStyleSheet(f"color: {TEXT_MAIN}; font-size: 34px; font-weight: 800;")

        self.conf_label = QLabel("신뢰도 —")
        self.conf_label.setStyleSheet(f"color: {TEXT_SUB}; font-size: 13px;")

        layout.addWidget(title)
        layout.addWidget(self.value_label)
        layout.addWidget(self.conf_label)

        self.setStyleSheet(f"""
            #ResultPanel {{
                background-color: {PANEL};
                border: 1px solid {PANEL_BORDER};
                border-radius: 12px;
            }}
        """)

    def show_result(self, text: str, confidence: float):
        self.value_label.setText(text)
        self.conf_label.setText(f"신뢰도 {confidence * 100:.0f}%")

    def clear_result(self):
        self.value_label.setText("—")
        self.conf_label.setText("신뢰도 —")


# ============================================================
# 장애물 실시간 상태 (0xB0 패킷마다 ~300ms 간격으로 계속 갱신, 배너처럼 반짝이진 않음)
# ============================================================
class ObstacleStatus(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("ObstacleStatus")
        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 16, 18, 16)
        layout.setSpacing(6)

        title = QLabel("장애물 실시간 감지")
        title.setStyleSheet(f"color: {TEXT_SUB}; font-size: 13px; font-weight: 600;")

        self.value_label = QLabel("감지된 장애물 없음")
        self.value_label.setStyleSheet(f"color: {TEXT_MAIN}; font-size: 20px; font-weight: 700;")

        self.conf_label = QLabel("")
        self.conf_label.setStyleSheet(f"color: {TEXT_SUB}; font-size: 13px;")

        layout.addWidget(title)
        layout.addWidget(self.value_label)
        layout.addWidget(self.conf_label)

        self.setStyleSheet(f"""
            #ObstacleStatus {{
                background-color: {PANEL};
                border: 1px solid {PANEL_BORDER};
                border-radius: 12px;
            }}
        """)

    def update_status(self, object_name: str, direction_name: str, confidence: int):
        if object_name == "미상":
            self.value_label.setText("감지된 장애물 없음")
            self.conf_label.setText("")
        else:
            self.value_label.setText(f"{direction_name} · {object_name}")
            self.conf_label.setText(f"신뢰도 {confidence}%")


# ============================================================
# 수동 모드 트리거 버튼 (키워드스파팅 릴레이가 붙기 전까지 시연/테스트용)
# ============================================================
class ModeControls(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)

        self.bus_btn = QPushButton("🚌 버스 OCR 모드 요청")
        self.braille_btn = QPushButton("🟨 점자블록 모드 요청")

        for btn in (self.bus_btn, self.braille_btn):
            btn.setFixedHeight(40)
            btn.setStyleSheet(f"""
                QPushButton {{
                    background-color: {PANEL};
                    color: {TEXT_MAIN};
                    border: 1px solid {PANEL_BORDER};
                    border-radius: 8px;
                    font-size: 13px;
                    font-weight: 600;
                }}
                QPushButton:hover {{ border-color: {MODE_COLORS[MODE_BUS_OCR]}; }}
                QPushButton:pressed {{ background-color: {PANEL_BORDER}; }}
            """)
            layout.addWidget(btn)


# ============================================================
# 키워드스파팅 상태 표시 (GPIO17 버튼 누름 -> "말씀하세요" -> "인식 중" -> 결과)
# 심사위원이 "지금 뭘 하고 있는지" 바로 알 수 있게 항상 보이는 상태줄로 둔다.
# ============================================================
class KeywordStatus(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("KeywordStatus")
        self.setFixedHeight(48)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(18, 0, 18, 0)

        self.label = QLabel("")
        self.label.setStyleSheet("font-size: 15px; font-weight: 700;")
        layout.addWidget(self.label)
        layout.addStretch(1)

        self._result_timer = QTimer(self)
        self._result_timer.setSingleShot(True)
        self._result_timer.timeout.connect(self.show_idle)

        self.show_idle()

    def _set(self, text: str, color: str):
        self.label.setText(text)
        self.label.setStyleSheet(f"font-size: 15px; font-weight: 700; color: {color};")
        self.setStyleSheet(f"""
            #KeywordStatus {{ background-color: {PANEL}; border-radius: 10px; border: 2px solid {color}; }}
        """)

    def show_idle(self):
        self._set("🎤  버튼을 누르고 말씀하세요", TEXT_SUB)

    def show_listening(self):
        self._result_timer.stop()
        self._set("🎤  듣는 중…", GREEN)

    def show_processing(self):
        self._set("🧠  키워드 인식 중…", "#e8a33d")

    def show_result(self, mode):
        if mode == MODE_BUS_OCR:
            self._set("✅  '버스' 인식 → 버스 OCR 모드로 전환", MODE_COLORS[MODE_BUS_OCR])
        elif mode == MODE_BRAILLE:
            self._set("✅  '점자블록' 인식 → 점자블록 모드로 전환", MODE_COLORS[MODE_BRAILLE])
        else:
            self._set("❓  인식 실패, 다시 시도해주세요", RED)
        self._result_timer.start(2500)


# ============================================================
# 이벤트 알림 배너 (장애물 감지 / 낙상 감지) - 이모지로 재미있게
# ============================================================
class EventBanner(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("EventBanner")
        self.setFixedHeight(64)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(18, 0, 18, 0)

        self.label = QLabel("")
        self.label.setStyleSheet("font-size: 20px; font-weight: 700;")
        layout.addWidget(self.label)
        layout.addStretch(1)

        self._effect = QGraphicsOpacityEffect(self)
        self.setGraphicsEffect(self._effect)
        self._effect.setOpacity(0.0)

        self._hide_timer = QTimer(self)
        self._hide_timer.setSingleShot(True)
        self._hide_timer.timeout.connect(self._hide)

        self._hide()

    def _hide(self):
        self._effect.setOpacity(0.0)
        self.setStyleSheet(f"""
            #EventBanner {{ background-color: {PANEL}; border-radius: 12px; border: 1px solid {PANEL_BORDER}; }}
        """)

    def flash(self, text: str, color: str, duration_ms: int = 2600):
        self.label.setText(text)
        self.label.setStyleSheet(f"font-size: 20px; font-weight: 700; color: {color};")
        self.setStyleSheet(f"""
            #EventBanner {{ background-color: {PANEL}; border-radius: 12px; border: 2px solid {color}; }}
        """)
        self._effect.setOpacity(1.0)
        self._hide_timer.start(duration_ms)

    def obstacle(self, label: str, confidence: float):
        self.flash(f"⚠️  장애물 감지 — {label} ({confidence * 100:.0f}%)", "#e8a33d")

    def braille(self, present: bool, confidence: int, near: bool):
        if not present:
            self.flash("🟨  점자블록 인식 안 됨", TEXT_SUB)
        elif near:
            self.flash(f"🟨  점자블록 인식됨 (근접, {confidence}%)", MODE_COLORS[MODE_BRAILLE])
        else:
            self.flash(f"🟨  점자블록 인식됨 ({confidence}%)", MODE_COLORS[MODE_BRAILLE])

    def crosswalk(self):
        self.flash("🚦  횡단보도 인식됨", "#5b8def")

    def fall(self):
        self.flash("🚨  낙상 감지! 확인이 필요합니다", RED)


# ============================================================
# 메인 윈도우
# ============================================================
class DashboardWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("보조기기 대시보드")
        self.setMinimumSize(1000, 620)
        self.setStyleSheet(f"background-color: {BG}; color: {TEXT_MAIN}; font-family: 'Pretendard', 'Malgun Gothic', sans-serif;")

        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(20, 20, 20, 20)
        root.setSpacing(14)

        # 상단 1행: GPS / 블루투스 이어폰
        top_bar = QHBoxLayout()
        top_bar.setSpacing(10)
        self.gps_badge = StatusBadge("🛰️", "GPS")
        self.bt_badge = StatusBadge("🎧", "블루투스 이어폰")
        top_bar.addWidget(self.gps_badge)
        top_bar.addWidget(self.bt_badge)
        top_bar.addStretch(1)
        root.addLayout(top_bar)

        # 상단 2행: 3개 ESP32-S3 보드 + 영상 스트림 연결 상태
        board_bar = QHBoxLayout()
        board_bar.setSpacing(10)
        self.keyword_badge = StatusBadge("🎙️", "키워드+IMU")
        self.serial_badge = StatusBadge("🔌", "AI모드")
        self.tof_badge = StatusBadge("📏", "TOF (ACM2)")
        self.video_badge = StatusBadge("📡", "영상 스트림")
        board_bar.addWidget(self.keyword_badge)
        board_bar.addWidget(self.serial_badge)
        board_bar.addWidget(self.tof_badge)
        board_bar.addWidget(self.video_badge)
        board_bar.addStretch(1)
        root.addLayout(board_bar)

        # 모드 바 + 키워드스파팅 상태 + 수동 트리거 버튼
        self.mode_bar = ModeBar()
        root.addWidget(self.mode_bar)

        self.keyword_status = KeywordStatus()
        root.addWidget(self.keyword_status)

        self.mode_controls = ModeControls()
        root.addWidget(self.mode_controls)

        # 본문: 카메라 프리뷰 + 결과 패널
        body = QHBoxLayout()
        body.setSpacing(14)

        self.camera_preview = CameraPreview()
        body.addWidget(self.camera_preview, 3)

        side = QVBoxLayout()
        side.setSpacing(14)
        self.result_panel = ResultPanel()
        self.obstacle_status = ObstacleStatus()
        side.addWidget(self.result_panel)
        side.addWidget(self.obstacle_status)
        side.addStretch(1)
        body.addLayout(side, 2)

        root.addLayout(body, 1)

        # 하단: 이벤트 배너
        self.event_banner = EventBanner()
        root.addWidget(self.event_banner)

        self._last_obstacle_key = None

    # ---- 외부에서 상태를 밀어넣는 인터페이스 (나중에 실데이터 연결 지점) ----
    def set_gps_connected(self, connected: bool):
        self.gps_badge.set_connected(connected)

    def set_bt_connected(self, connected: bool):
        self.bt_badge.set_connected(connected)

    def set_mode(self, mode: str):
        self.mode_bar.set_active(mode)

    def set_camera_frame(self, image: QImage):
        self.camera_preview.set_frame(image)

    def show_ocr_result(self, text: str, confidence: float):
        self.result_panel.show_result(text, confidence)

    def show_obstacle_event(self, label: str, confidence: float):
        self.event_banner.obstacle(label, confidence)

    def show_crosswalk_event(self):
        self.event_banner.crosswalk()

    def show_fall_event(self):
        self.event_banner.fall()

    def set_ircamera_serial_connected(self, connected: bool):
        self.serial_badge.set_connected(connected)

    def set_ircamera_video_connected(self, connected: bool):
        self.video_badge.set_connected(connected)

    def handle_obstacle_packet(self, object_name: str, direction_name: str, confidence: int):
        """0xB0 패킷(~300ms 간격, 미탐지 포함)마다 호출됨.
        실시간 상태는 매번 갱신하되, 배너 반짝임은 '없음 -> 감지' 전환(rising edge)에서만 띄운다."""
        self.obstacle_status.update_status(object_name, direction_name, confidence)

        key = (object_name, direction_name)
        if object_name == "미상":
            self._last_obstacle_key = None
        elif key != self._last_obstacle_key:
            self._last_obstacle_key = key
            self.show_obstacle_event(f"{direction_name} {object_name}", confidence / 100)

    def show_braille_result(self, present: bool, confidence: int, near: bool):
        self.event_banner.braille(present, confidence, near)

    def set_keyword_serial_connected(self, connected: bool):
        self.keyword_badge.set_connected(connected)

    def set_tof_connected(self, connected: bool):
        self.tof_badge.set_connected(connected)


def main():
    app = QApplication(sys.argv)
    window = DashboardWindow()

    # ---- ircamera (ACM1: 장애물/버스OCR/점자블록 + TCP:8090 영상) ----
    link = IrCameraLink()
    link.frame_received.connect(window.set_camera_frame)
    link.mode_changed.connect(window.set_mode)
    link.obstacle_detected.connect(window.handle_obstacle_packet)
    link.bus_result.connect(lambda text, conf: window.show_ocr_result(text, conf / 100))
    link.braille_result.connect(window.show_braille_result)
    link.serial_connected.connect(window.set_ircamera_serial_connected)
    link.video_client_connected.connect(window.set_ircamera_video_connected)

    window.mode_controls.bus_btn.clicked.connect(link.request_bus_mode)
    window.mode_controls.braille_btn.clicked.connect(link.request_braille_mode)

    # ---- 키워드스파팅 (ACM0: GPIO17 버튼 -> 녹음 -> 인식 -> ircamera 모드 릴레이) ----
    keyword_link = KeywordSpottingLink()
    keyword_link.serial_connected.connect(window.set_keyword_serial_connected)
    keyword_link.listening_started.connect(window.keyword_status.show_listening)
    keyword_link.listening_stopped.connect(window.keyword_status.show_processing)

    def on_keyword_recognized(mode):
        window.keyword_status.show_result(mode)
        if mode == MODE_BUS_OCR:
            link.request_bus_mode()
        elif mode == MODE_BRAILLE:
            link.request_braille_mode()

    keyword_link.keyword_recognized.connect(on_keyword_recognized)

    # ---- TOF (ACM2: 패킷 스펙 미정, 장치 연결여부만 표시) ----
    tof_watcher = PortWatcher(TOF_PORT)
    tof_watcher.connected_changed.connect(window.set_tof_connected)

    # ---- 블루투스 이어폰 (bluetoothctl 폴링) ----
    bt_watcher = BluetoothWatcher(BT_EARPHONE_MAC)
    bt_watcher.connected_changed.connect(window.set_bt_connected)

    link.start()
    keyword_link.start()

    # GPS는 아직 실데이터 연동 전이라 배지가 회색 "미연동"으로 뜬다.
    # 실연동 붙이면 window.set_gps_connected(bool) 호출.

    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
