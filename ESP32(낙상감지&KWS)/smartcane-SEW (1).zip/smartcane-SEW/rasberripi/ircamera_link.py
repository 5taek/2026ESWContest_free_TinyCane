"""
ircamera(ESP32-S3) <-> 라즈베리파이 통신 백엔드

- USB-CDC 시리얼(기본 /dev/ircamera, udev 심볼릭 링크): 모드 전환 명령(1바이트) 송신 + 결과 패킷(0xB0/0xB1/0xB2) 수신
- TCP 서버(기본 0.0.0.0:8090): ESP32가 붙어서 밀어넣는 그레이스케일 JPEG 프레임(약 5fps) 수신

dashboard.py 에서 IrCameraLink 인스턴스를 만들고 시그널을 UI 갱신 메서드에 연결해서 쓴다.
serial_port/tcp_port를 생성자 인자로 뺀 건 테스트(가짜 pty/포트)와 나중에 설정 바꿀 때를 위함.
"""

import socket
import struct
import threading
import time

import serial
from PySide6.QtCore import QObject, Signal
from PySide6.QtGui import QImage

DEFAULT_SERIAL_PORT = "/dev/ircamera"  # udev 심볼릭 링크(/etc/udev/rules.d/99-sew-boards.rules) - ttyACM 번호는 꽂는 순서에 따라 바뀌므로 시리얼 번호로 고정
DEFAULT_SERIAL_BAUD = 921600
DEFAULT_TCP_HOST = "0.0.0.0"
DEFAULT_TCP_PORT = 8090

MODE_BUS_OCR = 0x01
MODE_BRAILLE = 0x02

PKT_OBSTACLE = 0xB0
PKT_BUS = 0xB1
PKT_BRAILLE = 0xB2

OBJECT_NAMES = {0x01: "자전거", 0x02: "킥보드", 0x03: "볼라드", 0x04: "사람", 0x05: "미상"}
DIRECTION_NAMES = {0x01: "왼쪽", 0x02: "중앙", 0x03: "오른쪽"}

# ESP32가 각 모드에서 결과를 못 보내도 자동으로 장애물모드로 복귀하기까지 걸리는 최대 시간(스펙 기준).
# 결과 패킷(0xB1/0xB2)이 먼저 도착하면 이 타이머는 취소되고 그쪽이 우선한다.
BUS_MODE_TIMEOUT_S = 30
BRAILLE_MODE_TIMEOUT_S = 5

# 버스 OCR 모드는 결과(0xB1)가 와도 최소 이 시간 동안은 유지한다.
# 그 전에는 실제로 텍스트를 못 읽었어도 결과 패킷만 먼저 보내는 경우가 있어서,
# 그대로 두면 모드가 켜지자마자 바로 꺼지는 것처럼 보인다.
MIN_BUS_MODE_DWELL_S = 10

# 영상 스트림(길이 헤더 + JPEG) 관련 상수.
# ESP32가 모드 전환 중 프레임 전송을 멈추거나 프레이밍이 깨진 데이터를 보내면
# recv()가 무한정 블록되거나 length 헤더를 잘못 해석해 스트림이 영구히 어긋날 수 있다.
# 그래서 (1) 응답이 없으면 타임아웃으로 재접속을 유도하고, (2) 프레임이 손상됐으면
# 다음 유효한 프레임 경계를 스트림에서 찾아 재동기화한다.
RECV_TIMEOUT_S = 3.0
MAX_FRAME_BYTES = 400_000  # 정상 프레임 크기보다 넉넉한 상한(이보다 크면 헤더 손상으로 간주)
JPEG_SOI = b"\xff\xd8"
JPEG_EOI = b"\xff\xd9"
RESYNC_SCAN_LIMIT = MAX_FRAME_BYTES * 2  # 이만큼 스캔해도 못 찾으면 포기하고 재접속


class IrCameraLink(QObject):
    frame_received = Signal(QImage)
    obstacle_detected = Signal(str, str, int)   # object_name, direction_name, confidence(0~100)
    bus_result = Signal(str, int)                # text, confidence(0~100)
    braille_result = Signal(bool, int, bool)     # present, confidence(0~100), near
    mode_changed = Signal(str)                   # "obstacle" | "bus_ocr" | "braille"
    serial_connected = Signal(bool)
    video_client_connected = Signal(bool)

    def __init__(self, serial_port=DEFAULT_SERIAL_PORT, serial_baud=DEFAULT_SERIAL_BAUD,
                 tcp_host=DEFAULT_TCP_HOST, tcp_port=DEFAULT_TCP_PORT, parent=None):
        super().__init__(parent)
        self.serial_port = serial_port
        self.serial_baud = serial_baud
        self.tcp_host = tcp_host
        self.tcp_port = tcp_port

        self._ser = None
        self._ser_lock = threading.Lock()
        self._revert_timer = None
        self._active_mode = None
        self._mode_start_time = 0.0
        self._stop = threading.Event()

    # ---------------- 시작/종료 ----------------
    def start(self):
        threading.Thread(target=self._serial_loop, daemon=True).start()
        threading.Thread(target=self._tcp_server_loop, daemon=True).start()

    def stop(self):
        self._stop.set()
        if self._revert_timer:
            self._revert_timer.cancel()

    # ---------------- 모드 전환 명령 (키워드스파팅 릴레이 / 수동 버튼 둘 다 이걸 호출) ----------------
    def request_bus_mode(self):
        # UI 갱신(칩 색상/타이머)은 즉시 반영하고, 시리얼 전송은 백그라운드 스레드로 보낸다.
        # ser.write()가 (ESP32가 UART를 못 받아주는 동안) 블로킹되더라도 이 메서드는
        # 버튼 클릭 슬롯 등 GUI 메인 스레드에서 호출되므로, 여기서 막히면 창 전체가 먹통이 된다.
        self._active_mode = "bus_ocr"
        self._mode_start_time = time.time()
        self.mode_changed.emit("bus_ocr")
        self._arm_revert_timer(BUS_MODE_TIMEOUT_S)
        threading.Thread(target=self._send_mode_byte, args=(MODE_BUS_OCR,), daemon=True).start()

    def request_braille_mode(self):
        self._active_mode = "braille"
        self._mode_start_time = time.time()
        self.mode_changed.emit("braille")
        self._arm_revert_timer(BRAILLE_MODE_TIMEOUT_S)
        threading.Thread(target=self._send_mode_byte, args=(MODE_BRAILLE,), daemon=True).start()

    def _arm_revert_timer(self, timeout_s):
        if self._revert_timer:
            self._revert_timer.cancel()
        self._revert_timer = threading.Timer(timeout_s, self._revert_to_obstacle)
        self._revert_timer.daemon = True
        self._revert_timer.start()

    def _revert_to_obstacle(self):
        self._active_mode = None
        self.mode_changed.emit("obstacle")

    def _send_mode_byte(self, value: int):
        with self._ser_lock:
            if self._ser and self._ser.is_open:
                try:
                    self._ser.write(bytes([value]))
                except Exception as e:
                    print(f"[ircamera] 모드 전송 실패: {e}")
            else:
                print("[ircamera] 시리얼 연결 안 됨, 모드 전송 스킵")

    # ---------------- 시리얼 수신 루프 ----------------
    def _serial_loop(self):
        while not self._stop.is_set():
            try:
                with self._ser_lock:
                    # write_timeout을 안 주면 ser.write()가 무한 블로킹될 수 있는데, 그러면
                    # 그 write를 감싼 _ser_lock도 계속 잡혀 있어서 여기(재연결 시도)까지 같이 멈춘다.
                    self._ser = serial.Serial(self.serial_port, self.serial_baud, timeout=1, write_timeout=1)
                self.serial_connected.emit(True)
                print(f"[ircamera] 시리얼 연결됨: {self.serial_port}")
                self._read_packets()
            except Exception as e:
                print(f"[ircamera] 시리얼 연결 실패: {e}")
                self.serial_connected.emit(False)
                self._stop.wait(2.0)

    def _read_packets(self):
        ser = self._ser
        while not self._stop.is_set():
            head = ser.read(1)
            if not head:
                continue
            msg_type = head[0]
            try:
                if msg_type == PKT_OBSTACLE:
                    self._handle_obstacle(ser)
                elif msg_type == PKT_BUS:
                    self._handle_bus(ser)
                elif msg_type == PKT_BRAILLE:
                    self._handle_braille(ser)
            except (TimeoutError, serial.SerialException) as e:
                print(f"[ircamera] 시리얼 끊김/timeout: {e}")
                self.serial_connected.emit(False)
                return  # 바깥 _serial_loop에서 재연결

    def _read_exact(self, ser, n):
        buf = b""
        while len(buf) < n:
            chunk = ser.read(n - len(buf))
            if not chunk:
                raise TimeoutError(f"시리얼 읽기 timeout ({n}바이트 기대, {len(buf)}바이트 받음)")
            buf += chunk
        return buf

    def _handle_obstacle(self, ser):
        payload = self._read_exact(ser, 3)
        object_code, direction_code, confidence = payload[0], payload[1], payload[2]
        obj_name = OBJECT_NAMES.get(object_code, "미상")
        dir_name = DIRECTION_NAMES.get(direction_code, "-")
        self.obstacle_detected.emit(obj_name, dir_name, confidence)

    def _handle_bus(self, ser):
        length = self._read_exact(ser, 1)[0]
        text = self._read_exact(ser, length).decode("utf-8", errors="replace") if length else ""
        confidence = self._read_exact(ser, 1)[0]
        self.bus_result.emit(text, confidence)
        self._finish_active_mode()

    def _handle_braille(self, ser):
        payload = self._read_exact(ser, 3)
        present, confidence, near = bool(payload[0]), payload[1], bool(payload[2])
        self.braille_result.emit(present, confidence, near)
        self._finish_active_mode()

    def _finish_active_mode(self):
        # 결과가 왔으니 타임아웃 revert 타이머보다 먼저 장애물모드로 되돌린다.
        # 단, 버스 OCR 모드는 결과가 너무 일찍 와도 MIN_BUS_MODE_DWELL_S는 채우고 되돌린다.
        if self._revert_timer:
            self._revert_timer.cancel()

        if self._active_mode == "bus_ocr":
            remaining = MIN_BUS_MODE_DWELL_S - (time.time() - self._mode_start_time)
            if remaining > 0:
                self._revert_timer = threading.Timer(remaining, self._revert_to_obstacle)
                self._revert_timer.daemon = True
                self._revert_timer.start()
                return

        self._revert_to_obstacle()

    # ---------------- TCP 영상 서버 ----------------
    def _tcp_server_loop(self):
        srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        srv.bind((self.tcp_host, self.tcp_port))
        srv.listen(1)
        print(f"[ircamera] 영상 TCP 서버 대기 중: {self.tcp_host}:{self.tcp_port}")

        while not self._stop.is_set():
            try:
                conn, addr = srv.accept()
            except OSError:
                return  # stop() 등으로 소켓이 닫힌 경우
            print(f"[ircamera] 영상 클라이언트 연결: {addr}")
            self.video_client_connected.emit(True)
            try:
                self._recv_frames(conn)
            except Exception as e:
                print(f"[ircamera] 영상 수신 오류: {e}")
            finally:
                conn.close()
                self.video_client_connected.emit(False)
                print("[ircamera] 영상 클라이언트 연결 끊김, 재접속 대기")

    def _recv_frames(self, conn):
        # 타임아웃 없이 recv()를 걸면 ESP32가 모드 전환 중 프레임 전송을 멈췄을 때
        # 이 스레드가 무한정 블록된다. RECV_TIMEOUT_S 안에 응답이 없으면 socket.timeout이
        # 터져서 바깥 _tcp_server_loop의 except로 빠지고, 그쪽에서 conn을 닫고 재접속을 기다린다.
        conn.settimeout(RECV_TIMEOUT_S)
        while not self._stop.is_set():
            header = self._recv_exact(conn, 4)
            (length,) = struct.unpack("<I", header)

            jpeg_bytes = None
            if 0 < length <= MAX_FRAME_BYTES:
                body = self._recv_exact(conn, length)
                if body[:2] == JPEG_SOI and body[-2:] == JPEG_EOI:
                    jpeg_bytes = body
                else:
                    print(f"[ircamera] 프레임 손상(길이={length}), 재동기화 시도")
            else:
                print(f"[ircamera] 비정상 프레임 길이({length}), 재동기화 시도")

            if jpeg_bytes is None:
                jpeg_bytes = self._resync(conn)
                if jpeg_bytes is None:
                    raise ConnectionError("영상 스트림 재동기화 실패, 재접속 유도")
                print("[ircamera] 재동기화 성공")

            image = QImage.fromData(jpeg_bytes, "JPG")
            if not image.isNull():
                self.frame_received.emit(image)

    def _resync(self, conn):
        """프레임 프레이밍이 깨졌을 때, 스트림을 1바이트씩 밀어가며 다음으로 유효해
        보이는 (length 헤더 + JPEG SOI) 패턴을 찾아 복구한다.
        RESYNC_SCAN_LIMIT 안에 못 찾으면 None을 돌려주고, 호출부가 연결을 끊어 재접속을 유도한다."""
        window = b""
        scanned = 0
        while scanned < RESYNC_SCAN_LIMIT and not self._stop.is_set():
            b = conn.recv(1)
            if not b:
                return None
            window = (window + b)[-6:]
            scanned += 1
            if len(window) == 6:
                (length,) = struct.unpack("<I", window[:4])
                if 0 < length <= MAX_FRAME_BYTES and window[4:6] == JPEG_SOI:
                    rest = self._recv_exact(conn, length - 2)
                    body = JPEG_SOI + rest
                    if body[-2:] == JPEG_EOI:
                        return body
                    # SOI만 우연히 맞아떨어졌을 수 있으니 여기서 포기하지 않고 계속 스캔한다
        return None

    def _recv_exact(self, conn, n):
        buf = b""
        while len(buf) < n:
            chunk = conn.recv(n - len(buf))
            if not chunk:
                raise ConnectionError("영상 연결 종료됨")
            buf += chunk
        return buf
