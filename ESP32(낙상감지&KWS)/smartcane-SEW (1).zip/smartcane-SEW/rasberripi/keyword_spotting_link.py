"""
키워드스파팅+낙상감지 ESP32-S3(/dev/keyword, udev 심볼릭 링크) <-> 라즈베리파이 연동 - 오디오 키워드스파팅 부분

pipeline.py의 record_and_get_result()를 그대로 가져옴:
  - GPIO17 버튼을 누르고 있는 동안 pw-record로 녹음
  - 버튼 떼면 녹음 종료 -> wav를 16kHz로 리샘플링 -> 32000바이트를 512바이트씩 전송
  - 보드가 "RESULT:one"/"RESULT:two" 줄로 응답하면 파싱해서 keyword_recognized 시그널로 방출

낙상감지(IMU) 쪽은 같은 물리 보드가 보내는 것으로 보이는데 패킷 스펙이 아직 안 정해져서
이 모듈은 다루지 않는다 (포트 연결 상태만 serial_connected로 노출).
"""

import os
import subprocess
import signal as sys_signal
import threading
import time
import wave

import numpy as np
import serial
from scipy.signal import resample_poly
from PySide6.QtCore import QObject, Signal

DEFAULT_SERIAL_PORT = "/dev/keyword"  # udev 심볼릭 링크(/etc/udev/rules.d/99-sew-boards.rules) - ttyACM 번호는 꽂는 순서에 따라 바뀌므로 시리얼 번호로 고정
DEFAULT_SERIAL_BAUD = 921600
CHUNK_SIZE = 512
BUTTON_PIN = 17
TEMP_WAV = "/home/cane/sew/dashboard_recorded.wav"
BT_TARGET = "88"  # pipeline.py와 동일한 pw-record 타깃(블루투스 마이크 노드 ID).
                   # PipeWire 노드 ID라 재부팅/재페어링하면 바뀔 수 있음 - 안 되면 `pw-record --list-targets`로 재확인.

ESP_SAMPLE_COUNT = 32000  # 1초 * 16000Hz * 2바이트
RESULT_TIMEOUT_S = 10


class KeywordSpottingLink(QObject):
    listening_started = Signal()       # 버튼 누름 - 녹음 시작
    listening_stopped = Signal()       # 버튼 뗌 - 녹음 종료, 전송 + 인식 대기 시작
    keyword_recognized = Signal(object)  # "bus_ocr" | "braille" | None(인식 실패/timeout)
    serial_connected = Signal(bool)
    button_available = Signal(bool)

    def __init__(self, serial_port=DEFAULT_SERIAL_PORT, serial_baud=DEFAULT_SERIAL_BAUD,
                 button_pin=BUTTON_PIN, parent=None):
        super().__init__(parent)
        self.serial_port = serial_port
        self.serial_baud = serial_baud
        self.button_pin = button_pin

        self._ser = None
        self._button = None
        self._stop = threading.Event()

    # ---------------- 시작 ----------------
    def start(self):
        threading.Thread(target=self._serial_loop, daemon=True).start()
        self._init_button()

    def stop(self):
        self._stop.set()

    def _init_button(self):
        try:
            from gpiozero import Button
            self._button = Button(self.button_pin, pull_up=True)
            self._button.when_pressed = self._on_press
            self.button_available.emit(True)
            print(f"[keyword] GPIO{self.button_pin} 버튼 초기화 완료")
        except Exception as e:
            print(f"[keyword] GPIO 초기화 실패: {e}")
            self.button_available.emit(False)

    # ---------------- 시리얼 연결 유지 (버튼 트리거 시에만 실제로 주고받음) ----------------
    def _serial_loop(self):
        while not self._stop.is_set():
            try:
                self._ser = serial.Serial(self.serial_port, self.serial_baud, timeout=2)
                self._ser.reset_input_buffer()
                self.serial_connected.emit(True)
                print(f"[keyword] 시리얼 연결됨: {self.serial_port}")
                # is_open만 보면 물리적 연결 해제를 못 잡아냄(우리가 직접 close()하지 않는 한 계속 True).
                # 실제 I/O가 버튼 눌렸을 때만 일어나므로, 장치 노드 존재 여부를 주기적으로 같이 확인한다.
                while not self._stop.is_set() and self._ser and self._ser.is_open:
                    if not os.path.exists(self.serial_port):
                        print(f"[keyword] 시리얼 끊김 감지: {self.serial_port}")
                        break
                    time.sleep(1.0)
                else:
                    continue
                self.serial_connected.emit(False)
                try:
                    self._ser.close()
                except Exception:
                    pass
                self._stop.wait(2.0)
            except Exception as e:
                print(f"[keyword] 시리얼 연결 실패: {e}")
                self.serial_connected.emit(False)
                self._stop.wait(2.0)

    # ---------------- 버튼 콜백 (gpiozero 내부 스레드에서 호출됨) ----------------
    def _on_press(self):
        self.listening_started.emit()
        threading.Thread(target=self._record_and_process, daemon=True).start()

    def _record_and_process(self):
        try:
            self._record_while_held()
            self.listening_stopped.emit()
            result = self._send_and_get_result()
            self.keyword_recognized.emit(result)
        except Exception as e:
            print(f"[keyword] 처리 오류: {e}")
            self.keyword_recognized.emit(None)

    def _record_while_held(self):
        proc = subprocess.Popen(
            ["pw-record", f"--target={BT_TARGET}", "--rate=48000", "--channels=1", TEMP_WAV],
            stderr=subprocess.DEVNULL,
        )
        while self._button and self._button.is_pressed:
            time.sleep(0.01)
        proc.send_signal(sys_signal.SIGINT)
        proc.wait()

    def _send_and_get_result(self):
        if self._ser is None or not self._ser.is_open:
            print("[keyword] 시리얼 연결 없음, 전송 스킵")
            return None

        with wave.open(TEMP_WAV, "rb") as wf:
            raw_rate = wf.getframerate()
            raw = np.frombuffer(wf.readframes(wf.getnframes()), dtype=np.int16).astype(np.float32)

        if raw_rate == 48000:
            resampled = resample_poly(raw, 1, 3)
        elif raw_rate == 32000:
            resampled = resample_poly(raw, 1, 2)
        else:
            resampled = raw

        resampled = np.clip(resampled, -32768, 32767).astype(np.int16)
        audio_data = resampled.tobytes()

        if len(audio_data) < ESP_SAMPLE_COUNT:
            print(f"[keyword] 녹음 데이터 부족: {len(audio_data)} bytes (필요: {ESP_SAMPLE_COUNT})")
            return None

        self._ser.reset_input_buffer()
        time.sleep(0.1)
        for i in range(0, ESP_SAMPLE_COUNT, CHUNK_SIZE):
            chunk = audio_data[i:i + CHUNK_SIZE]
            self._ser.write(chunk)
            time.sleep(0.002)

        result_line = None
        timeout_start = time.time()
        while time.time() - timeout_start < RESULT_TIMEOUT_S:
            if self._ser.in_waiting > 0:
                line = self._ser.readline().decode("utf-8", errors="ignore").strip()
                if "RESULT:" in line:
                    result_line = line
                    break

        if not result_line or "REJECTED" in result_line:
            return None

        label = result_line.replace("RESULT:", "").split("(")[0].strip().lower()
        if "one" in label:
            return "bus_ocr"
        if "two" in label:
            return "braille"
        return None
