# esp32ocr 프로젝트 규칙

ESP32-S3 (Seeed XIAO, 8MB Flash / 8MB Octal PSRAM) 위에서 PaddleOCR PP-OCRv3
det + rec 모델을 돌려 버스 번호를 읽는 시각장애인 보조 시스템.

---

## 파일 수정 규칙 (중요)

**어떤 파일이든 수정하기 전에 반드시 나에게 먼저 물어볼 것.**

- 무엇을, 왜 바꿀 것인지 설명하고 승인을 받은 뒤에 수정한다
- 여러 파일을 고쳐야 하면 전체 목록을 먼저 보여주고 한 번에 승인받는다
- 읽기(Read/Grep/Glob)는 물어보지 않아도 된다
- 예외 없음. "사소한 수정이라서" 같은 판단으로 건너뛰지 않는다

---

## 개발 기록 규칙

문제를 해결하거나 중요한 사실을 알아낼 때마다 `docs/개발기록.md`에 추가한다.
따로 요청받지 않아도 한다.

형식: **문제 → 증상 → 시도한 것(실패한 것 포함) → 원인 → 해결 → 교훈**

실패한 시도와 헛다리 짚은 가설도 반드시 남긴다. 나중에 같은 길을 다시 가지
않게 해주고, 결과보고서에서는 그 과정 자체가 가장 설득력 있는 재료가 된다.

---

## 절대 실행하면 안 되는 명령

### `idf.py fullclean`

`managed_components`를 지우고 다시 내려받는다. 아래에 정리된 우리 패치가
**전부 날아간다.** 전체 재빌드가 필요하면 `build` 폴더만 지울 것:

```
Remove-Item -Recurse -Force C:\Users\shiny\esp32ocr\build
idf.py build
```

---

## managed_components 직접 패치 목록

esp-tflite-micro / esp-nn 원본을 직접 수정해서 쓰고 있다.
컴포넌트를 다시 받으면 아래를 전부 다시 적용해야 한다.

| 파일 | 수정 내용 | 이유 |
|---|---|---|
| `tensorflow/lite/micro/micro_mutable_op_resolver.h` | `AddRelu0To1()` 메서드 추가 | RELU_0_TO_1 등록 수단이 없음 (AddBuiltin이 private) |
| `tensorflow/lite/micro/kernels/strided_slice_common.cc` | `kMaxDim` 4 → 5 | rec 모델의 SVTR 부분이 5차원 STRIDED_SLICE 사용 |
| `tensorflow/lite/micro/kernels/esp_nn/conv.cc` | 그룹 conv면 reference 구현으로 우회 (Prepare/Eval 양쪽) | esp-nn이 그룹 conv 미지원, MatchingDim DCHECK에서 abort |
| `tensorflow/lite/micro/micro_interpreter_graph.cc` | 노드 실행 시 `MicroPrintf` 디버그 출력 | 어느 노드에서 죽는지 추적용 (필요 없으면 제거 가능) |

---

## 하드웨어 / 설정 고정값

이미 시행착오로 확정된 값들. 함부로 바꾸지 말 것.

- **PSRAM 모드: Octal** — Quad로 두면 `mspi_init`에서 부팅 패닉
- **Flash 크기: 8MB** — 기본값 2MB로는 파티션 테이블이 안 들어감
- **플래시 방식: UART** — 이 보드는 JTAG 플래싱 불가
- **Task WDT: 비활성** — 추론이 수 초~수십 초 걸려서 워치독이 짖음

## 파티션 구성 (`partitions.csv`)

| 이름 | 크기 | 내용 |
|---|---|---|
| factory | 2M | 앱 |
| detmodel | 1M | `paddle_det_full_int8.tflite` |
| recmodel | 3M | `paddle_rec_full_int8.tflite` |
| testimg | 1M | 테스트 이미지 (640x480 uint8 RGB, 921,600 bytes) |

모델/이미지는 코드에 배열로 박지 않고 파티션에 원본 그대로 플래싱한 뒤
`esp_partition_mmap()`으로 매핑해서 쓴다 (RAM 소모 0).
`xxd -i` C 배열 방식은 내부 DRAM 오버플로를 일으켰으므로 쓰지 말 것.

플래싱:
```
parttool.py -p COM7 write_partition --partition-name=testimg --input test_image.bin
```
반드시 **ESP-IDF Terminal**에서 실행 (일반 PowerShell은 esptool을 못 찾음).

---

## 파이프라인 구조

```
640x480 uint8 RGB (flash mmap)
  → 224x224 축소 + ImageNet 정규화
  → det 추론 → 확률맵
  → BFS 최대 연결영역 → unclip(ratio 1.6)
  → 박스를 원본 좌표로 환산
  → 원본에서 crop → 48x320, (x/255-0.5)/0.5
  → rec 추론 → CTC 그리디 디코딩
  → 전각/혼동문자 정규화 → 후보 매칭
```

Colab 검증 파이프라인(`test_full_pipeline.py`)과 동일한 결과를 내는 것이 기준.
정확도 문제가 생기면 보드에서 반복하지 말고 **Colab에서 같은 조건으로 재현해
비교**할 것. 보드 1회 실행은 1분 이상 걸린다.

---

## 현재 상태 (2026-07-30)

- det + rec 전체 파이프라인 동작. 503 버스 사진에서 `-503` 인식 성공
  (Colab 검증 파이프라인과 동일한 결과)
- **속도: det 9.2초 + rec 11.6초 = 20.8초** (초기 109초 대비 5.2배)
- 적용된 최적화: 컴파일러 `-O2`, CPU 240MHz, PSRAM 80MHz, flash QIO,
  esp-nn 최적화 커널(`CONFIG_NN_OPTIMIZED=y`)
- `CONFIG_SPIRAM_RODATA`는 해제 (자투리 PSRAM 풀을 만들어 힙 검사기를 오작동시킴)

### esp-nn 커널별 우회 현황

전부 켜면 rec 정확도가 무너져서 커널 단위로 조정한 상태.
자세한 경위는 `docs/개발기록.md` 5-A 참고.

| 커널 | 현재 경로 | 이유 |
|---|---|---|
| conv 1x1 등 | esp-nn SIMD | 정상 |
| conv general/precomp | **esp-nn SIMD** | 크래시는 오탐이었음. 복귀 완료 (det -35%) |
| depthwise 3x3 | **esp-nn SIMD** | 정상 확인 |
| depthwise 5x5 + 패딩 | esp-nn ANSI C | SIMD가 패딩 경계를 잘못 처리 (오차 최대 255) |
| softmax | **esp-nn SIMD** | 무죄로 밝혀져 복귀 |
| 그룹 conv | TFLite reference | esp-nn 미지원 |
| fully connected (per-ch) | TFLite reference | SIMD 크래시 (`ESP_NN_FC_PER_CH_DISABLED`) |

**우회를 넣었으면 목록으로 관리하고, 원인 가설이 바뀔 때마다 전부 재검토할 것.**
실제로 `ESP_NN_CONV_GENERAL_FORCE_ANSI`는 원인이 오탐으로 밝혀진 뒤에도 방치되어
5.5초를 계속 낭비하고 있었다.

**우회할 때 선택지는 셋이다.** 빠른 순서로
esp-nn SIMD > esp-nn ANSI C > TFLite reference.
무심코 가장 느린 TFLite reference로 보내지 말 것 (실제로 두 번 그래서 손해봤다).

## 남은 작업

- rec 모델 재변환: 그룹 conv → `DEPTHWISE_CONV_2D` (지금 TFLite reference 경로)
- det 입력 224 → 160 (연산량 절반)
- esp-nn depthwise SIMD가 어떤 조건에서 부정확한지 규명 → 조건만 피하면 SIMD 복귀
- softmax를 esp-nn으로 되돌려보기 (범인이 아니었음)
- 카메라 연동 (`resize_and_normalize_for_det`의 입력만 프레임버퍼로 교체하면 됨)
- 점자블록 검출 YOLO 모델 추가 (파티션 mmap 패턴 그대로 재사용)

## 반복금지(이미 알고있는 내용)
- Remove-Item C:\Users\shiny\brailblock\sdkconfig  (필요시)
- idf.py build flash monitor -p COM7
컴파일 하는방법, 빌드하는방법, 플래시하는방법, tflite파일 플래시하는방법