"""
스마트 지팡이 - 키워드 스파팅 + 버스 번호 OCR (ESP32 연동) 테스트 버전

원본 통합 코드에서 이번 테스트에 필요한 것만 남김:
- 택트스위치로 녹음 트리거 + 키워드 스파팅 (ESP32-S3, AUDIO_PORT)
- 버스 번호 OCR은 별도 ESP32-S3(esp32ocr 보드, BUS_OCR_PORT)가 담당.
  RPi는 카메라 프레임 공급 + 트리거 전송 + 결과 수신만 한다.

뺀 것: Hailo(점자블록), EasyOCR, 버스 API/정류장 DB, GPS, Firebase, IR LED.
(점자블록은 나중에 별도로 다시 붙일 예정)
"""

import time
import wave
import threading
import subprocess
import signal as sys_signal
import struct

import cv2
import numpy as np
import serial
from scipy.signal import resample_poly
from picamera2 import Picamera2

# ─────────────────────────────────────────
# 설정
# ─────────────────────────────────────────
AUDIO_PORT   = "/dev/ttyACM0"  # 키워드 스파팅 ESP32-S3
BUS_OCR_PORT = "/dev/ttyACM1"  # 버스 번호 OCR ESP32-S3 (esp32ocr 보드)

AUDIO_BAUD   = 921600
BUS_OCR_BAUD = 115200  # USB Serial/JTAG(네이티브 USB-CDC)라 실제로는 무시됨

CHUNK_SIZE = 4096  # ESP32 usb_serial_jtag rx_buffer_size(4096)와 맞춤
BUTTON_PIN = 17
TEMP_WAV   = "/home/cane/sew/recorded.wav"
BT_TARGET  = "88"

# ESP32 오디오 설정 (1초 x 16000Hz x 2바이트)
ESP_SAMPLE_COUNT = 32000
ESP_DATA_SIZE    = ESP_SAMPLE_COUNT

IMG_WIDTH, IMG_HEIGHT = 640, 480
IMG_BYTES = IMG_WIDTH * IMG_HEIGHT  # 그레이스케일 1바이트/픽셀, esp32ocr main.cpp의 BUS_IMG_BYTES와 일치해야 함

# ─────────────────────────────────────────
# 버스 OCR ESP32 <-> RPi 프로토콜
# (esp32ocr/main.cpp 의 MSG_TRIGGER / MSG_BUS_IMG_REQ 와 반드시 일치)
#
#   RPi   -> ESP32 : MSG_TRIGGER (0xC0)      페이로드 없음, OCR 세션 시작
#   ESP32 -> RPi   : MSG_BUS_IMG_REQ (0xA6)  페이로드 없음, 프레임 요청
#   RPi   -> ESP32 : 4바이트 length header(LE, uint32, 항상 IMG_BYTES) + RGB raw bytes
#   ESP32 -> RPi   : 텍스트 한 줄 + '\n'  ("937\n" 또는 못 찾으면 "NONE\n")
# ─────────────────────────────────────────
MSG_TRIGGER     = 0xC0
MSG_BUS_IMG_REQ = 0xA6

# ─────────────────────────────────────────
# 카메라 (상시 가동)
# ─────────────────────────────────────────
picam2 = None
camera_lock = threading.Lock()

def init_camera():
    global picam2
    picam2 = Picamera2()
    config = picam2.create_preview_configuration(
        main={"format": "RGB888", "size": (IMG_WIDTH, IMG_HEIGHT)}
    )
    picam2.configure(config)
    picam2.start()
    time.sleep(1)
    print("[카메라] 상시 가동 시작")

def capture_frame():
    """스레드 세이프하게 최신 프레임(RGB, 640x480) 한 장을 캡처한다.

    주의: picamera2의 "RGB888" 포맷이 실제로는 BGR 순서로 나오는 경우가 있다고
    알려져 있음. esp32ocr 쪽 grayscale 변환이 R/G/B 가중치를 고정으로 쓰고
    있어서, 만약 인식률이 이상하게 낮으면 여기서 채널 순서부터 의심할 것.
    """
    with camera_lock:
        return picam2.capture_array()

# ─────────────────────────────────────────
# GPIO (버튼)
# ─────────────────────────────────────────
GPIO_AVAILABLE = False
button = None
try:
    from gpiozero import Button
    button = Button(BUTTON_PIN, pull_up=True)
    GPIO_AVAILABLE = True
    print(f"[GPIO] 버튼 핀 {BUTTON_PIN} 초기화 완료")
except Exception as e:
    print(f"[GPIO] 초기화 실패: {e}")

# ─────────────────────────────────────────
# 시리얼 연결 (오디오/버스OCR 별도 보드, 별도 포트)
# ─────────────────────────────────────────
try:
    ser = serial.Serial(AUDIO_PORT, AUDIO_BAUD, timeout=2)
    ser.reset_input_buffer()
    ser.reset_output_buffer()
    print(f"✅ 오디오 S3 연결 성공: {AUDIO_PORT}")
except Exception as e:
    print(f"❌ 오디오 S3 포트 열기 실패: {e}")
    ser = None

try:
    # read(1) 폴링 간격용으로 짧은 timeout 사용 (데이터 없으면 그냥 다음 루프로)
    ser_bus = serial.Serial(BUS_OCR_PORT, BUS_OCR_BAUD, timeout=0.1)
    ser_bus.reset_input_buffer()
    ser_bus.reset_output_buffer()
    print(f"✅ 버스 OCR S3 연결 성공: {BUS_OCR_PORT}")
except Exception as e:
    print(f"❌ 버스 OCR S3 포트 열기 실패: {e}")
    ser_bus = None

# ─────────────────────────────────────────
# 녹음 (버튼 누르는 동안)
# ─────────────────────────────────────────
def record_while_button_held():
    print("[녹음] 버튼 누르는 동안 녹음 중...")
    proc = subprocess.Popen(
        ["pw-record", f"--target={BT_TARGET}", "--rate=48000", "--channels=1", TEMP_WAV],
        stderr=subprocess.DEVNULL
    )
    while True:
        if GPIO_AVAILABLE and button:
            if not button.is_pressed:
                break
        else:
            time.sleep(2.5)  # 버튼 없으면 2.5초 고정 녹음
            break
        time.sleep(0.01)
    proc.send_signal(sys_signal.SIGINT)
    proc.wait()
    print("[녹음] 완료")

# ─────────────────────────────────────────
# 키워드 스파팅
# ─────────────────────────────────────────
def record_and_get_result():
    if ser is None:
        print("[S3] 시리얼 연결 없음")
        return None
    try:
        record_while_button_held()

        with wave.open(TEMP_WAV, 'rb') as wf:
            raw_rate = wf.getframerate()
            raw = np.frombuffer(wf.readframes(wf.getnframes()), dtype=np.int16).astype(np.float32)

        if raw_rate == 48000:
            resampled = resample_poly(raw, 1, 3)
        elif raw_rate == 32000:
            resampled = resample_poly(raw, 1, 2)
        else:
            resampled = raw

        resampled = np.clip(resampled, -32768, 32767).astype(np.int16)
        audio_data = resampled.tobytes()

        if len(audio_data) < ESP_DATA_SIZE:
            print(f"[S3] 데이터 부족: {len(audio_data)} bytes (필요: {ESP_DATA_SIZE})")
            return None

        ser.reset_input_buffer()
        time.sleep(0.1)

        for i in range(0, ESP_DATA_SIZE, CHUNK_SIZE):
            chunk = audio_data[i:i + CHUNK_SIZE]
            ser.write(chunk)
            time.sleep(0.002)

        print("[S3] 전송 완료, 결과 대기 중...")

        result_line = None
        timeout_start = time.time()
        while time.time() - timeout_start < 10:
            if ser.in_waiting > 0:
                line = ser.readline().decode('utf-8', errors='ignore').strip()
                if "RESULT:" in line:
                    result_line = line
                    print(f"[S3] {line}")
                if "S3_READY" in line:
                    break

        if result_line:
            label = result_line.replace("RESULT:", "").split("(")[0].strip()
            if label.lower() == "bus":
                label = "버스"
            return label
        return None

    except Exception as e:
        print(f"[S3] 오류: {e}")
        return None

# ─────────────────────────────────────────
# 버스 OCR ESP32 통신
# ─────────────────────────────────────────
def send_trigger():
    if ser_bus is None:
        print("[버스OCR] 시리얼 연결 없음")
        return
    ser_bus.write(bytes([MSG_TRIGGER]))
    print("[버스OCR] 트리거 전송, OCR 세션 시작 요청")

def handle_bus_img_request():
    """ESP32가 0xA6를 보내면 최신 프레임을 4바이트 길이헤더 + 그레이스케일 raw로 응답한다.

    RGB 그대로 보내면 921,600바이트라 전송에만 ~0.9초가 걸렸다. 어차피 ESP32가
    받자마자 그레이스케일로만 쓰므로, RPi에서 미리 변환해서 307,200바이트(1/3)만
    보내도록 바꿈 — 체감상 0.9초 -> 0.3초대로 줄어드는 걸 기대.
    """
    t_req = time.time()

    t0 = time.time()
    frame = capture_frame()  # RGB888(또는 실제로는 BGR일 수 있음), 640x480
    t_capture = time.time() - t0

    t0 = time.time()
    # 디버그 미리보기는 컬러 원본으로 띄운다 (색이 반전돼 보여도 OCR 결과엔 무관)
    cv2.imshow("Bus OCR Preview", frame)
    cv2.waitKey(1)
    t_preview = time.time() - t0

    t0 = time.time()
    # picamera2가 실제로 BGR을 주는 경우엔 COLOR_BGR2GRAY로 바꿔야 함
    # (인식률이 이상하게 낮으면 여기부터 의심)
    gray = cv2.cvtColor(frame, cv2.COLOR_RGB2GRAY)
    img_bytes = gray.tobytes()
    t_convert = time.time() - t0

    try:
        t0 = time.time()
        ser_bus.write(struct.pack('<I', len(img_bytes)))
        for i in range(0, len(img_bytes), CHUNK_SIZE):
            chunk = img_bytes[i:i + CHUNK_SIZE]
            ser_bus.write(chunk)
        t_write = time.time() - t0

        t_total = time.time() - t_req
        print(f"[버스OCR TX] 촬영={t_capture:.2f}s 미리보기={t_preview:.2f}s "
              f"변환={t_convert:.2f}s 전송={t_write:.2f}s | 합계={t_total:.2f}s ({len(img_bytes)}B)")
    except Exception as e:
        print(f"[버스OCR TX] 프레임 응답 오류: {e}")

def bus_ocr_serial_thread_func():
    """버스 OCR ESP32가 보내는 바이트를 계속 읽는다.
    0xA6면 이미지 요청으로 처리하고, 그 외 바이트는 텍스트 줄로 누적한다
    ('\\n'을 만나면 한 줄 완성으로 보고 처리).

    줄은 두 종류:
      TRY:<text>     매 프레임 시도 결과 (실패 이유 or 인식된 raw 텍스트)
      RESULT:<text>  세션 최종 결과 (후보지 일치 or NONE)
    """
    line_buf = bytearray()
    while True:
        if ser_bus is None:
            time.sleep(0.5)
            continue
        try:
            b = ser_bus.read(1)
            if not b:
                continue  # timeout, 아직 데이터 없음

            byte_val = b[0]

            if byte_val == MSG_BUS_IMG_REQ:
                handle_bus_img_request()
                continue

            if byte_val == 0x0A:  # '\n' — 줄 완성
                text = line_buf.decode('utf-8', errors='ignore').strip()
                line_buf.clear()
                if text.startswith("TRY:"):
                    print(f"[버스OCR TRY] {text[4:]}")
                elif text.startswith("RESULT:"):
                    value = text[7:]
                    if value == "NONE":
                        print("[버스OCR] 최종 결과: 못 찾음 (타임아웃)")
                    else:
                        print(f"[버스OCR] 최종 결과: {value} 🚌")
                elif text:
                    print(f"[버스OCR] (알 수 없는 줄) {text}")
            else:
                line_buf.append(byte_val)

        except Exception as e:
            print(f"[버스OCR 수신] 오류: {e}")
            time.sleep(0.1)

# ─────────────────────────────────────────
# 메인
# ─────────────────────────────────────────
def main():
    print("=" * 50)
    print("  스마트 지팡이 - 키워드 스파팅 + 버스 OCR 테스트")
    print("  버튼 누르고 '1'이라고 말하면 버스 OCR 트리거")
    print("=" * 50)

    init_camera()

    bus_ocr_t = threading.Thread(target=bus_ocr_serial_thread_func, daemon=True)
    bus_ocr_t.start()

    print("[대기] 버튼 입력 대기 중...")

    try:
        while True:
            if GPIO_AVAILABLE and button:
                if button.is_pressed:
                    time.sleep(0.05)
                    if button.is_pressed:
                        print("[버튼] 눌림 감지!")
                        result = record_and_get_result()
                        print(f"[키워드] 인식 결과: {result}")

                        if result and "one" in result:
                            send_trigger()
                        else:
                            print(f"[키워드] 미인식: {result}")
                time.sleep(0.05)
            else:
                try:
                    user_input = input("\n[1] 버스 OCR 트리거  [q] 종료: ").strip()
                    if user_input == '1':
                        result = record_and_get_result()
                        if result and "one" in result:
                            send_trigger()
                    elif user_input.lower() == 'q':
                        break
                except EOFError:
                    time.sleep(1)

    finally:
        cv2.destroyAllWindows()
        if ser:
            ser.close()
        if ser_bus:
            ser_bus.close()
        print("🔌 종료 완료")

if __name__ == "__main__":
    main()
