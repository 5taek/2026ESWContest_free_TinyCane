"""
YOLOv8 teacher로 soft label 사전 생성
────────────────────────────────────
실행: Colab에서 train_brailblock.py 돌리기 전에 1회만 실행

출력:
  /content/soft_labels/train/{stem}.npy  shape=(7,7,3,6)  obj채널=teacher conf
  /content/soft_labels/val/{stem}.npy
"""

import os, glob, numpy as np
from pathlib import Path
from sklearn.cluster import KMeans
from ultralytics import YOLO

# ── 경로 ─────────────────────────────────────────────────────────────────────
TEACHER_PT  = "/content/drive/MyDrive/brailblock/best.pt"
TRAIN_IMG   = "/content/brailblock/brailblock/images/train"
VAL_IMG     = "/content/brailblock/brailblock/images/val"
TRAIN_LBL   = "/content/brailblock/brailblock/labels/train"
SOFT_TRAIN  = "/content/soft_labels/train"
SOFT_VAL    = "/content/soft_labels/val"

GRID        = 7
NUM_ANCHORS = 3
INFER_CONF  = 0.05   # 낮게 설정해 약한 신호도 캡처

# ── 앵커 (train_brailblock.py와 동일하게 계산) ───────────────────────────────
def compute_anchors(lbl_dir, n_anchors=3):
    whs = []
    for f in glob.glob(f"{lbl_dir}/*.txt"):
        for line in open(f):
            parts = line.strip().split()
            if len(parts) == 5:
                whs.append([float(parts[3]), float(parts[4])])
    if not whs:
        raise RuntimeError(f"라벨 없음: {lbl_dir}")
    whs = np.array(whs, dtype=np.float32)
    km = KMeans(n_clusters=n_anchors, n_init=10, random_state=42).fit(whs)
    anchors = km.cluster_centers_
    anchors = anchors[np.argsort(anchors[:,0] * anchors[:,1])]
    print(f"앵커:\n{anchors}")
    return anchors.astype(np.float32)

def iou_wh(wh1, wh2):
    inter = np.minimum(wh1[0], wh2[0]) * np.minimum(wh1[1], wh2[1])
    return inter / (wh1[0]*wh1[1] + wh2[0]*wh2[1] - inter + 1e-7)

def encode_soft(detections, anchors, grid):
    """
    detections: list of (cx, cy, w, h, conf)  — 정규화 좌표
    반환: (grid, grid, n_anchors, 6)  obj = teacher conf (0~1)
    """
    out = np.zeros((grid, grid, len(anchors), 6), dtype=np.float32)
    for cx, cy, w, h, conf in detections:
        gi = min(int(cx * grid), grid - 1)
        gj = min(int(cy * grid), grid - 1)
        best_a = int(np.argmax([iou_wh([w, h], a) for a in anchors]))
        tx = cx * grid - gi
        ty = cy * grid - gj
        tw = float(np.log(max(w  / anchors[best_a, 0], 1e-7)))
        th = float(np.log(max(h  / anchors[best_a, 1], 1e-7)))
        # 이미 더 높은 conf가 있으면 덮어쓰지 않음
        if out[gj, gi, best_a, 4] < conf:
            out[gj, gi, best_a] = [tx, ty, tw, th, conf, conf]
    return out

# ── 메인 ─────────────────────────────────────────────────────────────────────
print("앵커 계산 중...")
ANCHORS = compute_anchors(TRAIN_LBL)

print(f"\nTeacher 로드: {TEACHER_PT}")
teacher = YOLO(TEACHER_PT)

def process_dir(img_dir, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    exts  = ("*.jpg", "*.jpeg", "*.png", "*.bmp")
    paths = sorted(sum([glob.glob(f"{img_dir}/{e}") for e in exts], []))
    print(f"\n{os.path.basename(img_dir)}: {len(paths)}장")

    skipped = 0
    for i, p in enumerate(paths):
        stem     = Path(p).stem
        out_path = f"{out_dir}/{stem}.npy"
        if os.path.exists(out_path):
            skipped += 1
            continue

        results = teacher(p, verbose=False, conf=INFER_CONF, imgsz=640)
        dets = []
        for r in results:
            if r.boxes is not None and len(r.boxes) > 0:
                boxes = r.boxes.xywhn.cpu().numpy()   # (N, 4) normalized cx cy w h
                confs = r.boxes.conf.cpu().numpy()    # (N,)
                for j in range(len(boxes)):
                    cx, cy, w, h = boxes[j]
                    dets.append((float(cx), float(cy), float(w), float(h), float(confs[j])))

        soft = encode_soft(dets, ANCHORS, GRID)
        np.save(out_path, soft)

        if (i + 1) % 1000 == 0:
            print(f"  {i+1}/{len(paths)}")

    print(f"  완료 (건너뜀 {skipped}장)")

process_dir(TRAIN_IMG, SOFT_TRAIN)
process_dir(VAL_IMG,   SOFT_VAL)
print("\n✅ soft label 생성 완료")
