"""
라벨 검수용 격자 이미지 생성 (Colab 셀에 그대로 붙여넣어 실행)
──────────────────────────────────────────────────────────
AI-Hub 원본 라벨은 기준이 사진마다 달라(어떤 건 블록 한 장, 어떤 건 여러 장,
어떤 건 화면 일부만) 모델이 학습할 일관된 규칙이 없다.
전부 눈으로 보고 걸러내기 위해, 이미지에 박스를 그려 25장씩 격자로 묶는다.

8000장 → 320장 격자. 한 장씩 넘기며 이상한 칸의 번호만 적어두면 된다.

아래 CONFIG만 고치고 셀을 실행하면 된다.
"""

import os, glob, csv, time, shutil
import numpy as np
import cv2
from pathlib import Path

# ══ CONFIG ═══════════════════════════════════════════════════════════════════
IMG_DIR = "/content/brailblock/images/train"
LBL_DIR = "/content/brailblock/labels/train"
OUT_DIR = "/content/drive/MyDrive/brailblock/review"

MODE  = "build"        # "build" = 격자 생성,  "filter" = 검수 결과로 정제
START = 0              # 이어서 시작할 page 번호 (중단됐을 때만 바꾸면 됨)

# MODE="filter" 일 때만 사용
CLEAN_DIR  = "/content/brailblock_clean"
DROP       = ""        # 제거할 인덱스. 예: "3,17,42,105-108,233"
DROP_NOBOX = True      # 라벨이 없는 이미지도 함께 제외할지

CELL   = 260           # 격자 한 칸 픽셀 크기
GRID   = 5             # 5×5 = 25장
PER    = GRID * GRID
MARGIN = 26            # 번호 표시용 상단 여백
# ═════════════════════════════════════════════════════════════════════════════


def list_images(img_dir):
    exts = ("*.jpg", "*.jpeg", "*.png", "*.bmp", "*.JPG", "*.JPEG")
    return sorted(sum([glob.glob(os.path.join(img_dir, e)) for e in exts], []))


def load_boxes(lbl_path):
    """YOLO 형식 → [(cx, cy, w, h), ...]"""
    boxes = []
    if os.path.exists(lbl_path):
        for line in open(lbl_path):
            p = line.strip().split()
            if len(p) == 5:
                boxes.append(tuple(float(v) for v in p[1:]))
    return boxes


def make_cell(img_path, lbl_path, idx):
    """박스를 그린 한 칸 이미지 생성"""
    img = cv2.imread(img_path, cv2.IMREAD_COLOR)
    if img is None:
        img = np.zeros((CELL, CELL, 3), np.uint8)
    img = cv2.resize(img, (CELL, CELL))

    boxes = load_boxes(lbl_path)
    for cx, cy, w, h in boxes:
        x1, y1 = int((cx - w / 2) * CELL), int((cy - h / 2) * CELL)
        x2, y2 = int((cx + w / 2) * CELL), int((cy + h / 2) * CELL)
        cv2.rectangle(img, (x1, y1), (x2, y2), (0, 255, 0), 2)

    bar   = np.zeros((MARGIN, CELL, 3), np.uint8)
    label = f"{idx}" if boxes else f"{idx} [NO BOX]"
    color = (255, 255, 255) if boxes else (0, 165, 255)
    cv2.putText(bar, label, (6, MARGIN - 8),
                cv2.FONT_HERSHEY_SIMPLEX, 0.62, color, 2)
    return np.vstack([bar, img])


def build(img_dir=IMG_DIR, lbl_dir=LBL_DIR, out_dir=OUT_DIR, start=START):
    os.makedirs(out_dir, exist_ok=True)
    paths  = list_images(img_dir)
    n_page = (len(paths) + PER - 1) // PER
    print(f"이미지 {len(paths)}장 → 격자 {n_page}장")

    map_path = os.path.join(out_dir, "index.csv")
    if not os.path.exists(map_path):
        with open(map_path, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["index", "filename"])
            for i, p in enumerate(paths):
                w.writerow([i, os.path.basename(p)])
        print(f"매핑 저장: {map_path}")

    t0 = time.time()
    for page in range(start, n_page):
        out = os.path.join(out_dir, f"page_{page:04d}.jpg")
        if os.path.exists(out):
            continue

        cells = []
        for k in range(PER):
            i = page * PER + k
            if i < len(paths):
                stem = Path(paths[i]).stem
                cells.append(make_cell(paths[i],
                                       os.path.join(lbl_dir, stem + ".txt"), i))
            else:
                cells.append(np.zeros((CELL + MARGIN, CELL, 3), np.uint8))

        rows = [np.hstack(cells[r * GRID:(r + 1) * GRID]) for r in range(GRID)]
        cv2.imwrite(out, np.vstack(rows), [cv2.IMWRITE_JPEG_QUALITY, 85])

        if (page + 1) % 20 == 0:
            print(f"  {page+1}/{n_page}  ({time.time()-t0:.0f}s)", flush=True)

    print(f"완료: {out_dir}")


def parse_drop(spec):
    """'3,17,42,105-108' → {3,17,42,105,106,107,108}"""
    out = set()
    for part in spec.split(","):
        part = part.strip()
        if not part:
            continue
        if "-" in part:
            a, b = part.split("-")
            out.update(range(int(a), int(b) + 1))
        else:
            out.add(int(part))
    return out


def filter_dataset(img_dir=IMG_DIR, lbl_dir=LBL_DIR, out_dir=CLEAN_DIR,
                   drop_spec=DROP, drop_nobox=DROP_NOBOX):
    drop  = parse_drop(drop_spec) if drop_spec else set()
    paths = list_images(img_dir)

    out_img = os.path.join(out_dir, "images")
    out_lbl = os.path.join(out_dir, "labels")
    os.makedirs(out_img, exist_ok=True)
    os.makedirs(out_lbl, exist_ok=True)

    kept = dropped = nobox = 0
    for i, p in enumerate(paths):
        if i in drop:
            dropped += 1
            continue
        stem = Path(p).stem
        lbl  = os.path.join(lbl_dir, stem + ".txt")
        if drop_nobox and not load_boxes(lbl):
            nobox += 1
            continue
        shutil.copy(p,   os.path.join(out_img, os.path.basename(p)))
        shutil.copy(lbl, os.path.join(out_lbl, stem + ".txt"))
        kept += 1

    print(f"유지 {kept}장 / 검수 제외 {dropped}장 / 라벨없음 제외 {nobox}장")
    print(f"출력: {out_dir}")


# ── 실행 ─────────────────────────────────────────────────────────────────────
if MODE == "build":
    build()
elif MODE == "filter":
    filter_dataset()
else:
    print(f"MODE는 'build' 또는 'filter' 여야 함 (현재: {MODE})")
