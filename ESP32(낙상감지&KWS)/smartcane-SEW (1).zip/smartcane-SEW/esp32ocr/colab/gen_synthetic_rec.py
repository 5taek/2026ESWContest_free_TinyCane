# ============================================================
# 버스 노선번호 인식기(rec) 학습용 합성 데이터 생성기
#
# 출력: 32x160 그레이스케일 uint8 이미지 + 라벨
#       (보드의 전처리와 완전히 동일한 형식이어야 함)
#
# 보드 쪽 전처리 규칙 (main.cpp의 crop_and_prepare_rec_input):
#   - 종횡비를 유지해 높이를 32에 맞춤
#   - 남는 폭은 "중간 회색"으로 패딩
#     (C++에서는 정규화 공간의 0.0으로 채우는데, 이는 픽셀값 127.5에 해당)
#   - 정규화는 (x/255 - 0.5) / 0.5
#
# Colab에서 실행. 첫 셀에서 한글 폰트를 설치해야 함:
#   !apt-get install -y fonts-nanum fonts-noto-cjk > /dev/null
#   !fc-cache -fv > /dev/null
# ============================================================

import os
import glob
import random
import subprocess
import numpy as np
import cv2
from PIL import Image, ImageDraw, ImageFont

# ==========================================
# 설정
# ==========================================
OUT_DIR = "/content/drive/MyDrive/rec_v2/synth"
NUM_SAMPLES = 10000          # 생성할 장수 (노선 140개, 장당 다양한 증강으로 충분)
REC_H, REC_W = 32, 160       # 보드의 REC_H / REC_W 와 일치시킬 것
PAD_VALUE = 127              # 정규화 시 0.0이 되는 값 (중간 회색)
SEED = 42

# 한글 폰트는 경로를 하드코딩하지 않고 직접 찾는다.
# (Colab 이미지 버전에 따라 설치 경로가 바뀐다)
FONT_SEARCH_DIRS = [
    "/usr/share/fonts",
    "/usr/local/share/fonts",
    os.path.expanduser("~/.fonts"),
]

# ==========================================
# 대구 시내버스 노선명
# 합성할 문자열 목록. 실제 노선을 쓰면 글자 조합 분포가 현실적이 된다.
# ==========================================
ROUTES = [
    # 직행 / 급행 / 순환
    "직행1", "직행2",
    "급행1", "급행2", "급행3", "급행5", "급행7", "급행8", "급행8-1",
    "급행9", "급행9-1", "급행9-2", "급행9-3", "급행10",
    "순환2", "순환2-1", "순환3", "순환3-1",
    # 숫자 노선
    "101", "101-1", "156", "204", "232", "232-1", "240",
    "300", "304", "306", "309", "320", "326", "349", "356",
    "401", "402", "403", "405", "410", "410-1", "413", "425",
    "501", "503", "504", "509", "518", "520", "523", "527",
    "564", "609", "618", "623", "649", "650", "651", "653",
    "655", "665", "706", "707", "708", "719", "724", "725",
    "726", "730", "802", "805", "814", "836", "848", "894", "937",
    # 지역 노선
    "남구1", "남구1-1", "남구2",
    "동구1", "동구1-1", "동구3", "동구4", "동구4-1", "동구5",
    "동구6", "동구7", "동구8", "동구10",
    "북구1", "북구2", "북구3", "북구4", "북구5", "북구6", "북구7", "북구8",
    "서구1", "서구2",
    "성서1", "성서1-1", "성서2", "성서3",
    "수성1", "수성1-1", "수성2", "수성3", "수성3-1", "수성4", "수성5", "수성6",
    "달서1", "달서2", "달서3", "달서5", "달서6",
    "달성1", "달성2", "달성3", "달성4", "달성5", "달성6", "달성7",
    "칠곡1", "칠곡1-1", "칠곡2", "칠곡3", "칠곡5",
    "가창2", "팔공1",
]

# ==========================================
# 글자셋 (모델 출력 클래스)
# 인덱스 0은 CTC blank
# ==========================================
DIGITS = list("0123456789")
HANGUL = list("직행급순환남구동북서성수달칠곡가창팔공")
SYMBOLS = ["-"]
CHARSET = DIGITS + HANGUL + SYMBOLS
NUM_CLASSES = len(CHARSET) + 1   # blank 포함

char2idx = {c: i + 1 for i, c in enumerate(CHARSET)}
idx2char = {i + 1: c for i, c in enumerate(CHARSET)}
idx2char[0] = ""


def check_charset():
    """노선 목록에 글자셋 밖의 문자가 없는지 확인"""
    used = set("".join(ROUTES))
    unknown = used - set(CHARSET)
    if unknown:
        raise ValueError(f"글자셋에 없는 문자가 노선명에 있음: {sorted(unknown)}")
    unused = set(CHARSET) - used
    print(f"글자셋 {len(CHARSET)}자 (+blank = {NUM_CLASSES} 클래스)")
    if unused:
        print(f"  노선명에 안 쓰이는 글자: {sorted(unused)}")


# ==========================================
# 렌더링
# ==========================================
def _can_render_hangul(font_path):
    """이 폰트로 한글이 실제로 그려지는지 확인한다.
    한글 글리프가 없으면 빈 사각형(두부)이 나오는데, 그런 폰트는 걸러야 한다."""
    try:
        font = ImageFont.truetype(font_path, 40)
    except Exception:
        return False

    def ink(ch):
        img = Image.new("L", (60, 60), 0)
        ImageDraw.Draw(img).text((5, 5), ch, font=font, fill=255)
        return np.array(img).sum()

    try:
        # 한글이 숫자와 비슷한 수준으로 그려지면 정상
        return ink("북") > 0 and ink("행") > 0
    except Exception:
        return False


def load_fonts():
    """NanumGothic 계열만 사용한다.
    한글 글리프가 완전히 지원되는 폰트만 써야 한다.
    Liberation 등 라틴 위주 폰트는 한글을 검은 두부(□)로 그려서 학습 데이터를 오염시킨다.
    """
    NANUM_CANDIDATES = [
        "/usr/share/fonts/truetype/nanum/NanumGothicBold.ttf",
        "/usr/share/fonts/truetype/nanum/NanumGothic.ttf",
        "/usr/share/fonts/truetype/nanum/NanumGothicExtraBold.ttf",
        "/usr/share/fonts/truetype/nanum/NanumBarunGothic.ttf",
        "/usr/share/fonts/truetype/nanum/NanumBarunGothicBold.ttf",
    ]

    fonts = [p for p in NANUM_CANDIDATES if os.path.exists(p) and _can_render_hangul(p)]

    if not fonts:
        raise FileNotFoundError(
            "NanumGothic 폰트를 못 찾음. Colab에서 먼저 실행할 것:\n"
            "  !apt-get install -y fonts-nanum\n"
            "  !fc-cache -fv"
        )

    print(f"NanumGothic 폰트 {len(fonts)}개 사용:")
    for p in fonts:
        print(f"  {p}")
    return fonts


def pick_colors(style):
    """배경색 / 글자색 조합.

    실사진 58장 픽셀 측정 결과:
      배경(테두리 중앙값): mean=128, std=12, 범위 93~142   →  중간 회색 패널
      글자(상위 3% 밝기):  mean=230, std=7,  범위 207~245  →  거의 흰색
      대비: 101

    즉 "중간 회색 배경 + 흰 글자". 반대로 만들면 안 된다.
    """
    bg = int(np.clip(random.gauss(128, 12), 95, 145))     # 중간 회색 배경
    fg = int(np.clip(random.gauss(230, 8), 205, 250))     # 흰 글자
    return bg, fg


def render_text(text, font_path, font_size, style):
    """텍스트를 이미지로 그린다.

    중요: 여백을 작게 잡아 글자가 세로를 거의 꽉 채우게 해야 한다.
    실제 crop은 글자에 딱 붙어 있는데, 여백을 크게 주면 32픽셀로 줄였을 때
    글자가 절반 크기가 되어 획이 뭉개진다.
    """
    font = ImageFont.truetype(font_path, font_size)
    spacing = random.randint(0, max(1, font_size // 8))

    # 글자별 실제 잉크 영역
    boxes = [font.getbbox(ch) for ch in text]
    widths = [b[2] - b[0] for b in boxes]

    # 세로는 문자열 전체의 위/아래 끝을 기준으로 (글자마다 높이가 달라서)
    top = min(b[1] for b in boxes)
    bottom = max(b[3] for b in boxes)
    total_w = sum(widths) + spacing * (len(text) - 1)
    total_h = bottom - top

    # 여백은 무작위. 실전에서 rec에 들어오는 조각은 det가 잘라준 것이고,
    # det 박스는 unclip 때문에 글자보다 여유가 있으며 그 정도가 매번 다르다.
    # 상하좌우를 따로 흔들어 박스 오차를 흉내낸다.
    # 음수도 허용해 '박스가 너무 타이트해서 획 끝이 잘린' 경우까지 학습시킨다.
    def margin():
        """실사진 측정: 잉크 bbox 높이 / 전체 32px = 0.84 ~ 0.97
        즉 상하로 살짝 여백이 있다. 너무 크면 글자가 작아지고,
        0이면 실사진보다 꽉 차서 달라진다."""
        r = random.random()
        if r < 0.08:
            return random.uniform(-0.02, 0.0)    # 살짝 잘림
        if r < 0.65:
            return random.uniform(0.0, 0.06)     # 딱 붙음 (대부분)
        return random.uniform(0.06, 0.14)        # 약간 여유

    ml = int(total_h * margin())
    mr = int(total_h * margin())
    mt = int(total_h * margin())
    mb = int(total_h * margin())

    canvas_w = max(4, total_w + ml + mr)
    canvas_h = max(4, total_h + mt + mb)
    mx, my = ml, mt

    bg, fg = pick_colors(style)
    img = Image.new("L", (canvas_w, canvas_h), bg)
    draw = ImageDraw.Draw(img)

    # 입체 부착 글자의 그림자.
    # 실사진에는 뚜렷한 그림자가 거의 없다. 이전 버전은 60% 확률에 배경보다
    # 25~60 어두운 그림자를 넣어 글자 주변이 검게 번진 이미지를 만들었다.
    # 확률과 강도를 모두 낮춘다.
    shadow = (style in ("panel", "dark_panel")) and random.random() < 0.2
    if shadow:
        off = max(1, int(total_h * random.uniform(0.015, 0.035)))
        sh = max(0, bg - random.randint(8, 20))
        x = mx
        for i, ch in enumerate(text):
            draw.text((x - boxes[i][0] + off, my - top + off), ch, font=font, fill=sh)
            x += widths[i] + spacing

    x = mx
    for i, ch in enumerate(text):
        draw.text((x - boxes[i][0], my - top), ch, font=font, fill=fg)
        x += widths[i] + spacing

    return np.array(img)


# ==========================================
# 증강
# ==========================================
def aug_perspective(img):
    """원근 왜곡 (비스듬히 본 각도)"""
    h, w = img.shape
    m = min(h, w) * random.uniform(0.02, 0.10)
    src = np.float32([[0, 0], [w, 0], [w, h], [0, h]])
    dst = np.float32([
        [random.uniform(0, m), random.uniform(0, m)],
        [w - random.uniform(0, m), random.uniform(0, m)],
        [w - random.uniform(0, m), h - random.uniform(0, m)],
        [random.uniform(0, m), h - random.uniform(0, m)],
    ])
    M = cv2.getPerspectiveTransform(src, dst)
    border = int(np.median(img))
    return cv2.warpPerspective(img, M, (w, h), borderValue=border)


def aug_rotate(img):
    angle = random.uniform(-8, 8)
    h, w = img.shape
    M = cv2.getRotationMatrix2D((w / 2, h / 2), angle, 1.0)
    border = int(np.median(img))
    return cv2.warpAffine(img, M, (w, h), borderValue=border)


def aug_motion_blur(img):
    """움직이는 버스 / 흔들린 손"""
    k = random.choice([3, 5, 7, 9])
    kernel = np.zeros((k, k), dtype=np.float32)
    if random.random() < 0.7:
        kernel[k // 2, :] = 1.0   # 가로 방향 (버스가 지나감)
    else:
        kernel[:, k // 2] = 1.0
    kernel /= kernel.sum()
    return cv2.filter2D(img, -1, kernel)


def aug_brightness_contrast(img):
    """실사진 배경은 93~142, 글자는 207~245 범위 안에 있다.
    이전 범위(alpha 0.5~1.6, beta ±50)는 이 범위를 크게 벗어나
    새까맣거나 새하얀 이미지를 만들었다."""
    alpha = random.uniform(0.85, 1.15)   # 대비
    beta = random.uniform(-15, 15)       # 밝기
    return np.clip(img.astype(np.float32) * alpha + beta, 0, 255).astype(np.uint8)


def aug_gamma(img):
    g = random.uniform(0.85, 1.2)   # 실사진 범위 유지 (기존 0.5~2.0은 과함)
    table = ((np.arange(256) / 255.0) ** g * 255).astype(np.uint8)
    return table[img]


def aug_noise(img):
    sigma = random.uniform(2, 18)
    noise = np.random.normal(0, sigma, img.shape)
    return np.clip(img.astype(np.float32) + noise, 0, 255).astype(np.uint8)


def aug_led_dots(img):
    """LED 전광판의 도트 패턴 재현: 격자로 어둡게 깎아낸다"""
    h, w = img.shape
    step = random.choice([2, 3])
    mask = np.ones((h, w), dtype=np.float32)
    mask[::step, :] *= random.uniform(0.6, 0.9)
    mask[:, ::step] *= random.uniform(0.6, 0.9)
    return np.clip(img.astype(np.float32) * mask, 0, 255).astype(np.uint8)


def aug_occlusion(img):
    """와이퍼, 반사, 기둥 등에 의한 부분 가림"""
    h, w = img.shape
    out = img.copy()
    for _ in range(random.randint(1, 2)):
        bw = random.randint(w // 20, w // 6)
        bh = random.randint(h // 6, h)
        x = random.randint(0, max(0, w - bw))
        y = random.randint(0, max(0, h - bh))
        # 극단값(0=완전검정, 255=완전흰색)은 실사진에 없다.
        # 배경 근처 값으로 가림 효과만 낸다.
        val = int(np.clip(np.median(img) + random.randint(-35, 35), 60, 200))
        alpha = random.uniform(0.3, 0.7)
        patch = out[y:y + bh, x:x + bw].astype(np.float32)
        out[y:y + bh, x:x + bw] = (patch * (1 - alpha) + val * alpha).astype(np.uint8)
    return out


def aug_italic(img):
    """이탤릭(기울임) 효과 — 실제 대구 버스 번호판 폰트가 오른쪽으로 기운다.
    warpAffine shear 변환: 위쪽이 오른쪽으로 밀린다."""
    h, w = img.shape
    shear = random.uniform(0.08, 0.22)      # 기울기 (양수 = 오른쪽으로 기움)
    # x' = x + shear*(h-y) : 위일수록 오른쪽으로
    M = np.float32([[1, -shear, shear * h],
                    [0,  1,     0        ]])
    border = int(np.median(img))
    out = cv2.warpAffine(img, M, (w, h), borderValue=border)
    return out


def aug_condense(img):
    """가로 압축 — 실제 버스 번호판 폰트는 표준 고딕보다 훨씬 좁다.

    실사진 측정 ("410" 3글자 기준):
      잉크 bbox 39x28, 31x31  →  가로/세로 비 1.0 ~ 1.4
    NanumGothic으로 같은 글자를 그리면 비가 1.7~1.9가 되어 너무 넓다.
    → 가로를 0.55~0.80배로 눌러 실사진 비율에 맞춘다.
    """
    h, w = img.shape
    factor = random.uniform(0.48, 0.70)
    new_w = max(4, int(round(w * factor)))
    return cv2.resize(img, (new_w, h), interpolation=cv2.INTER_AREA)


def aug_jpeg(img):
    """JPEG 압축 아티팩트 — 실사진은 카메라 JPEG로 저장되어 블록 노이즈가 생긴다."""
    quality = random.randint(40, 85)
    _, buf = cv2.imencode(".jpg", img, [cv2.IMWRITE_JPEG_QUALITY, quality])
    return cv2.imdecode(buf, cv2.IMREAD_GRAYSCALE)


def aug_downscale(img):
    """멀리 있는 버스: 작게 줄였다 다시 키워 해상도를 떨어뜨린다"""
    h, w = img.shape
    f = random.uniform(0.25, 0.7)
    small = cv2.resize(img, (max(4, int(w * f)), max(4, int(h * f))),
                       interpolation=cv2.INTER_AREA)
    return cv2.resize(small, (w, h), interpolation=cv2.INTER_LINEAR)


# ==========================================
# 보드와 동일한 최종 전처리
# ==========================================
def to_board_format(img):
    """종횡비 유지하며 높이를 REC_H에 맞추고, 남는 폭은 중간회색으로 패딩"""
    h, w = img.shape
    scale = REC_H / h
    new_w = max(1, min(REC_W, int(round(w * scale))))
    resized = cv2.resize(img, (new_w, REC_H), interpolation=cv2.INTER_AREA)

    out = np.full((REC_H, REC_W), PAD_VALUE, dtype=np.uint8)
    out[:, :new_w] = resized
    return out


# ==========================================
# 한 장 생성
# ==========================================
def make_sample(fonts):
    text = random.choice(ROUTES)
    font_path = random.choice(fonts)
    # 폰트를 크게 그린 뒤 축소해야 획이 깨끗하다
    font_size = random.randint(48, 96)

    # 실사진이 전부 panel 스타일 → 스타일 고정
    style = "panel"

    img = render_text(text, font_path, font_size, style)

    # 가로 압축: 항상 적용 (실제 버스 폰트가 표준 고딕보다 훨씬 좁음)
    img = aug_condense(img)

    # 이탤릭: 90% 확률 (실사진 폰트가 거의 항상 기울어짐)
    if random.random() < 0.9:
        img = aug_italic(img)
    if random.random() < 0.7:
        img = aug_rotate(img)
    if random.random() < 0.6:
        img = aug_perspective(img)
    if random.random() < 0.5:
        img = aug_downscale(img)
    if random.random() < 0.5:
        img = aug_motion_blur(img)
    if random.random() < 0.4:
        k = random.choice([3, 5])
        img = cv2.GaussianBlur(img, (k, k), 0)
    if random.random() < 0.8:
        img = aug_brightness_contrast(img)
    if random.random() < 0.4:
        img = aug_gamma(img)
    if random.random() < 0.25:
        img = aug_occlusion(img)
    if random.random() < 0.7:
        img = aug_noise(img)
    # JPEG 압축 노이즈: 60% 확률 (카메라 촬영 특성)
    if random.random() < 0.6:
        img = aug_jpeg(img)

    return to_board_format(img), text


# ==========================================
# 실행
# ==========================================
def main():
    random.seed(SEED)
    np.random.seed(SEED)

    check_charset()
    fonts = load_fonts()
    os.makedirs(OUT_DIR, exist_ok=True)

    images = np.zeros((NUM_SAMPLES, REC_H, REC_W), dtype=np.uint8)
    labels = []

    for i in range(NUM_SAMPLES):
        img, text = make_sample(fonts)
        images[i] = img
        labels.append(text)
        if (i + 1) % 2000 == 0:
            print(f"  {i + 1} / {NUM_SAMPLES}")

    np.savez_compressed(
        os.path.join(OUT_DIR, "synth.npz"),
        images=images,
        labels=np.array(labels),
    )
    print(f"\n저장 완료: {OUT_DIR}/synth.npz")
    print(f"  이미지 {images.shape}, 라벨 {len(labels)}개")

    # 눈으로 확인할 샘플 몇 장 저장
    sample_dir = os.path.join(OUT_DIR, "preview")
    os.makedirs(sample_dir, exist_ok=True)
    for i in range(40):
        cv2.imwrite(os.path.join(sample_dir, f"{i:03d}_{labels[i]}.png"), images[i])
    print(f"  미리보기 40장: {sample_dir}")


if __name__ == "__main__":
    main()
