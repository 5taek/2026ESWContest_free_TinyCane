# ============================================================
# 버스 노선번호 인식기(rec) 학습
#
#   구조 : CNN + CTC  (LSTM / 어텐션 없음)
#   입력 : 32 x 160 그레이스케일
#   출력 : (T=40, 31클래스) 로짓  -> 디코딩은 보드의 C++이 담당
#
# TFLM이 아는 연산만 사용한다:
#   CONV_2D, DEPTHWISE_CONV_2D, RELU, MAX_POOL_2D, RESHAPE
# 금지: HARD_SWISH, RELU_0_TO_1, BATCH_MATMUL, STRIDED_SLICE, LSTM, SE 블록
# (자세한 경위는 docs/개발기록.md 3장 참고)
#
# 데이터 구조:
#   합성 27,000장 → 학습  (synth 90%)
#   합성  3,000장 → 검증  (synth 10%, val_loss 추적용)
#   실사진   58장 → 테스트 (extract_real_crops.py 산출물, 학습/검증에 안 씀)
# ============================================================

import os
import glob
import random
import numpy as np
import cv2
import tensorflow as tf

# ==========================================
# 설정
# ==========================================
SYNTH_NPZ  = "/content/drive/MyDrive/rec_v2/synth/synth.npz"
REAL_DIR   = "/content/drive/MyDrive/rec_v2/real/ok"
OUT_DIR    = "/content/drive/MyDrive/rec_v2/model"

REC_H, REC_W  = 32, 160
MAX_LABEL_LEN = 6       # 가장 긴 노선명 "급행8-1" = 5, 여유 1
BATCH_SIZE    = 64
EPOCHS        = 200
VAL_RATIO     = 0.1     # 합성 데이터의 10%를 검증용으로 분리
REAL_RATIO    = 0.5     # 배치 절반을 실사진으로 — 도메인 갭 해소 최우선
REAL_EVAL_RATIO = 0.0   # 실사진 전부 학습용 (45장 다 써야 함)
SEED          = 42

# ==========================================
# 글자셋 — gen_synthetic_rec.py 와 반드시 동일하게 유지
# 인덱스 0 = CTC blank
# ==========================================
DIGITS  = list("0123456789")
HANGUL  = list("직행급순환남구동북서성수달칠곡가창팔공")
SYMBOLS = ["-"]
CHARSET = DIGITS + HANGUL + SYMBOLS
NUM_CLASSES = len(CHARSET) + 1   # blank 포함

char2idx = {c: i + 1 for i, c in enumerate(CHARSET)}
idx2char = {i + 1: c for i, c in enumerate(CHARSET)}
idx2char[0] = ""


def encode(text):
    """문자열 -> 0으로 패딩된 정수 배열"""
    seq = [char2idx[c] for c in text if c in char2idx]
    seq = seq[:MAX_LABEL_LEN]
    return np.array(seq + [0] * (MAX_LABEL_LEN - len(seq)), dtype=np.int32)


def normalize(img_uint8):
    """보드와 동일: (x/255 - 0.5) / 0.5"""
    return (img_uint8.astype(np.float32) / 255.0 - 0.5) / 0.5


# ==========================================
# 데이터 로딩
# ==========================================
def load_synth():
    """합성 데이터를 학습/검증으로 분리한다."""
    d = np.load(SYNTH_NPZ)
    images = d["images"]
    labels = [str(s) for s in d["labels"]]
    n = len(images)
    print(f"합성 데이터: {n}장")

    rng = np.random.default_rng(SEED)
    idx = rng.permutation(n)
    n_val = int(n * VAL_RATIO)

    val_idx   = idx[:n_val]
    train_idx = idx[n_val:]

    tr_imgs = images[train_idx]
    tr_lbls = [labels[i] for i in train_idx]
    va_imgs = images[val_idx]
    va_lbls = [labels[i] for i in val_idx]

    print(f"  학습용 {len(tr_imgs)}장 / 검증용 {len(va_imgs)}장")
    return tr_imgs, tr_lbls, va_imgs, va_lbls


def load_real():
    """실사진 전부를 테스트용으로 로드한다. 학습/검증에는 쓰지 않는다."""
    paths = sorted(glob.glob(os.path.join(REAL_DIR, "*.png")))
    images, labels = [], []
    skipped = []

    for p in paths:
        name  = os.path.basename(p)
        label = name.split("_")[0]
        if not label or any(c not in char2idx for c in label):
            skipped.append(name)
            continue
        img = cv2.imread(p, cv2.IMREAD_GRAYSCALE)
        if img is None:
            skipped.append(name)
            continue
        if img.shape != (REC_H, REC_W):
            img = cv2.resize(img, (REC_W, REC_H), interpolation=cv2.INTER_AREA)
        images.append(img)
        labels.append(label)

    print(f"실사진(테스트): {len(images)}장")
    if skipped:
        print(f"  건너뜀 {len(skipped)}개: {skipped[:5]}{' ...' if len(skipped) > 5 else ''}")

    from collections import Counter
    print(f"  라벨 분포: {dict(Counter(labels))}")
    return np.array(images), labels


def split_real(images, labels):
    """실사진을 학습/테스트로 나눈다. REAL_EVAL_RATIO=0이면 전부 학습용."""
    by_label = {}
    for i, lb in enumerate(labels):
        by_label.setdefault(lb, []).append(i)

    tr_idx, ev_idx = [], []
    rng = random.Random(SEED)
    for lb, idxs in by_label.items():
        rng.shuffle(idxs)
        n_ev = int(round(len(idxs) * REAL_EVAL_RATIO))
        ev_idx += idxs[:n_ev]
        tr_idx += idxs[n_ev:]

    print(f"  실사진 학습용 {len(tr_idx)}장 / 테스트용 {len(ev_idx)}장")
    tr_i = images[tr_idx] if tr_idx else np.zeros((0, REC_H, REC_W), dtype=np.uint8)
    ev_i = images[ev_idx] if ev_idx else np.zeros((0, REC_H, REC_W), dtype=np.uint8)
    return tr_i, [labels[i] for i in tr_idx], ev_i, [labels[i] for i in ev_idx]


def augment_real(img):
    """실사진 증강 — 이미 32x160 최종 형식이므로 가볍게만."""
    out = img.copy()
    if random.random() < 0.7:
        alpha = random.uniform(0.7, 1.4)
        beta  = random.uniform(-30, 30)
        out = np.clip(out.astype(np.float32) * alpha + beta, 0, 255).astype(np.uint8)
    if random.random() < 0.4:
        out = cv2.GaussianBlur(out, (3, 3), 0)
    if random.random() < 0.5:
        out = np.clip(out.astype(np.float32) +
                      np.random.normal(0, random.uniform(2, 10), out.shape),
                      0, 255).astype(np.uint8)
    if random.random() < 0.5:
        dx, dy = random.randint(-4, 4), random.randint(-2, 2)
        M = np.float32([[1, 0, dx], [0, 1, dy]])
        out = cv2.warpAffine(out, M, (REC_W, REC_H), borderValue=127)
    return out


# ==========================================
# 배치 생성기
# ==========================================
class MixedSequence(tf.keras.utils.Sequence):
    """합성 + 실사진을 섞어 배치를 만든다.
    REAL_RATIO = 0.5이면 배치 절반이 실사진 — 도메인 갭 해소 핵심."""

    def __init__(self, synth_imgs, synth_lbls, real_imgs, real_lbls,
                 batch_size, real_ratio, steps):
        self.si, self.sl = synth_imgs, synth_lbls
        self.ri, self.rl = real_imgs, real_lbls
        self.bs     = batch_size
        self.n_real = int(batch_size * real_ratio) if len(real_imgs) else 0
        self.n_synth = batch_size - self.n_real
        self.steps  = steps

    def __len__(self):
        return self.steps

    def __getitem__(self, _):
        xs, ys = [], []
        si = np.random.randint(0, len(self.si), self.n_synth)
        for i in si:
            xs.append(self.si[i])
            ys.append(encode(self.sl[i]))
        if self.n_real:
            ri = np.random.randint(0, len(self.ri), self.n_real)
            for i in ri:
                xs.append(augment_real(self.ri[i]))
                ys.append(encode(self.rl[i]))
        x = normalize(np.array(xs))[..., np.newaxis]
        return x, np.array(ys)


def make_val_dataset(images, labels, batch_size):
    """검증용 tf.data.Dataset — 셔플 없이 고정."""
    x = normalize(images)[..., np.newaxis]
    y = np.array([encode(lb) for lb in labels])
    ds = tf.data.Dataset.from_tensor_slices((x, y))
    return ds.batch(batch_size).prefetch(tf.data.AUTOTUNE)


# ==========================================
# 모델 — TFLM 친화 연산만 사용
# ==========================================
def build_model():
    """
    수용 영역(receptive field) 개선 버전 (v2)

    이전(v1) 문제: 3x3 depthwise만 쓰면 수용 영역이 ~26px → 한글 글자(28-32px) 구분 부족
    변경:
      - 처음 두 dw_block에 5x5 depthwise 사용 → 수용 영역 ~34px
      - 채널 수 확대 (16→32, 32→64, 64→96→128)
      - 블록 하나 추가 (깊이 부족 보완)
      - 최종 squeeze 채널 128→192
    금지 연산 없음: CONV_2D, DEPTHWISE_CONV_2D, RELU, MAX_POOL_2D, RESHAPE만 사용
    """
    inp = tf.keras.Input(shape=(REC_H, REC_W, 1), name="image")

    def dw_block(x, ch, k=3):
        """Depthwise separable block."""
        x = tf.keras.layers.DepthwiseConv2D(k, padding="same", use_bias=False)(x)
        x = tf.keras.layers.BatchNormalization()(x)
        x = tf.keras.layers.ReLU()(x)
        x = tf.keras.layers.Conv2D(ch, 1, padding="same", use_bias=False)(x)
        x = tf.keras.layers.BatchNormalization()(x)
        x = tf.keras.layers.ReLU()(x)
        return x

    # 32x160 → stem
    x = tf.keras.layers.Conv2D(32, 3, padding="same", use_bias=False)(inp)
    x = tf.keras.layers.BatchNormalization()(x)
    x = tf.keras.layers.ReLU()(x)
    x = tf.keras.layers.MaxPooling2D((2, 2))(x)       # 16x80

    # 5x5 depthwise: 수용 영역을 빠르게 키운다
    x = dw_block(x, 64, k=5)
    x = tf.keras.layers.MaxPooling2D((2, 2))(x)       # 8x40

    x = dw_block(x, 96, k=5)
    x = tf.keras.layers.MaxPooling2D((2, 1))(x)       # 4x40

    # 이 아래는 공간이 작아 3x3으로 충분
    x = dw_block(x, 128, k=3)
    x = dw_block(x, 128, k=3)                         # 블록 추가 (깊이 보완)
    x = tf.keras.layers.MaxPooling2D((2, 1))(x)       # 2x40

    # 높이를 1로 눌러 시퀀스로 만든다
    x = tf.keras.layers.Conv2D(192, (2, 1), padding="valid", use_bias=False)(x)
    x = tf.keras.layers.BatchNormalization()(x)
    x = tf.keras.layers.ReLU()(x)                     # 1x40x192

    # 1x1 conv로 클래스 분류 (Dense 대신 → TFLM에서 더 안전)
    x = tf.keras.layers.Conv2D(NUM_CLASSES, 1, padding="same")(x)   # 1x40xC
    out = tf.keras.layers.Reshape((-1, NUM_CLASSES), name="logits")(x)

    return tf.keras.Model(inp, out, name="bus_rec_v2")


def ctc_loss_fn(y_true, y_pred):
    y_true = tf.cast(y_true, tf.int32)
    label_length  = tf.reduce_sum(tf.cast(y_true > 0, tf.int32), axis=-1)
    batch         = tf.shape(y_pred)[0]
    logit_length  = tf.fill([batch], tf.shape(y_pred)[1])
    loss = tf.nn.ctc_loss(
        labels=y_true,
        logits=y_pred,
        label_length=label_length,
        logit_length=logit_length,
        logits_time_major=False,
        blank_index=0,
    )
    return tf.reduce_mean(loss)


# ==========================================
# 평가 — 보드의 CTC 그리디 디코딩과 동일
# ==========================================
def greedy_decode(logits):
    idxs = np.argmax(logits, axis=-1)
    out, prev = [], -1
    for i in idxs:
        if i != prev and i != 0:
            out.append(int(i))
        prev = i
    return "".join(idx2char.get(i, "?") for i in out)


def evaluate(model, images, labels, tag="", show=10):
    if len(images) == 0:
        print(f"[{tag}] 평가 데이터 없음")
        return 0.0
    x     = normalize(images)[..., np.newaxis]
    preds = model.predict(x, verbose=0)

    correct, wrong = 0, []
    for i, lb in enumerate(labels):
        p = greedy_decode(preds[i])
        if p == lb:
            correct += 1
        else:
            wrong.append((lb, p))

    acc = correct / len(labels)
    print(f"[{tag}] 정확도 {acc:.3f}  ({correct}/{len(labels)})")
    for lb, p in wrong[:show]:
        print(f"    정답 '{lb}'  ->  예측 '{p}'")
    if len(wrong) > show:
        print(f"    ... 외 {len(wrong) - show}개")
    return acc


class ValAccCallback(tf.keras.callbacks.Callback):
    """합성 검증셋으로 val_accuracy를 5에폭마다 계산한다.
    val_loss만으로는 실제 인식 정확도를 알 수 없기 때문에 필요하다.
    CTC 그리디 디코딩 후 전체 문자열 일치 여부로 측정한다."""

    def __init__(self, images, labels, every=5):
        super().__init__()
        self.images = images
        self.labels = labels
        self.every  = every

    def on_epoch_end(self, epoch, logs=None):
        if (epoch + 1) % self.every:
            return
        acc = evaluate(self.model, self.images, self.labels,
                       tag=f"epoch {epoch + 1} val_acc", show=3)
        if logs is not None:
            logs["val_acc"] = acc


class RealTestCallback(tf.keras.callbacks.Callback):
    """실사진 테스트셋으로 주기적으로 점검한다.
    저장은 ModelCheckpoint(val_loss)가 담당하므로 여기서는 출력만 한다."""

    def __init__(self, images, labels, every=10):
        super().__init__()
        self.images = images
        self.labels = labels
        self.every  = every

    def on_epoch_end(self, epoch, logs=None):
        if (epoch + 1) % self.every:
            return
        val_loss = logs.get("val_loss", float("inf"))
        print(f"\n  [실사진 테스트 - epoch {epoch + 1}]  val_loss={val_loss:.4f}")
        evaluate(self.model, self.images, self.labels,
                 tag=f"epoch {epoch + 1} 실사진", show=5)


# ==========================================
# TFLite INT8 변환
# ==========================================
def convert_tflite(model, rep_images):
    def rep_data():
        for i in range(min(300, len(rep_images))):
            x = normalize(rep_images[i])[np.newaxis, ..., np.newaxis]
            yield [x.astype(np.float32)]

    conv = tf.lite.TFLiteConverter.from_keras_model(model)
    conv.optimizations = [tf.lite.Optimize.DEFAULT]
    conv.representative_dataset = rep_data
    conv.target_spec.supported_ops = [tf.lite.OpsSet.TFLITE_BUILTINS_INT8]
    conv.inference_input_type  = tf.float32   # 보드 코드와 동일
    conv.inference_output_type = tf.float32
    return conv.convert()


def check_tflite(tflite_bytes, images, labels):
    """양자화 후에도 정확도가 유지되는지 확인"""
    it = tf.lite.Interpreter(model_content=tflite_bytes)
    it.allocate_tensors()
    inp, outp = it.get_input_details(), it.get_output_details()

    correct = 0
    for i, lb in enumerate(labels):
        x = normalize(images[i])[np.newaxis, ..., np.newaxis].astype(np.float32)
        it.set_tensor(inp[0]["index"], x)
        it.invoke()
        p = greedy_decode(it.get_tensor(outp[0]["index"])[0])
        if p == lb:
            correct += 1
    acc = correct / max(1, len(labels))
    print(f"[INT8 변환 후] 실사진 정확도 {acc:.3f}  ({correct}/{len(labels)})")
    return acc


# ==========================================
# 실행
# ==========================================
def main():
    random.seed(SEED)
    np.random.seed(SEED)
    tf.random.set_seed(SEED)
    os.makedirs(OUT_DIR, exist_ok=True)

    print(f"클래스 수: {NUM_CLASSES} (blank 포함)\n")

    # 데이터 로드
    tr_imgs, tr_lbls, va_imgs, va_lbls = load_synth()
    real_imgs, real_lbls = load_real()
    r_tr_i, r_tr_l, r_ev_i, r_ev_l = split_real(real_imgs, real_lbls)

    # 모델
    model = build_model()
    model.summary()
    print(f"\n파라미터 {model.count_params():,}개")

    # 학습률: 워밍업 5에폭 + 코사인 감쇠
    steps_per_epoch = max(50, len(tr_imgs) // BATCH_SIZE)
    total_steps  = steps_per_epoch * EPOCHS
    warmup_steps = steps_per_epoch * 5

    cosine = tf.keras.optimizers.schedules.CosineDecay(
        initial_learning_rate=1e-3,
        decay_steps=total_steps - warmup_steps,
        alpha=1e-5,
    )

    class WarmupCosine(tf.keras.optimizers.schedules.LearningRateSchedule):
        def __init__(self, wu, cos):
            self.wu, self.cos = wu, cos

        def __call__(self, step):
            step = tf.cast(step, tf.float32)
            wu   = tf.cast(self.wu, tf.float32)
            warmup_lr = 1e-4 + (1e-3 - 1e-4) * step / wu
            cosine_lr = self.cos(tf.maximum(step - wu, 0))
            return tf.where(step < wu, warmup_lr, cosine_lr)

        def get_config(self):
            return {}

    model.compile(
        optimizer=tf.keras.optimizers.Adam(WarmupCosine(warmup_steps, cosine)),
        loss=ctc_loss_fn,
    )

    # 데이터셋
    train_seq = MixedSequence(tr_imgs, tr_lbls, r_tr_i, r_tr_l,
                              BATCH_SIZE, REAL_RATIO, steps_per_epoch)
    val_ds    = make_val_dataset(va_imgs, va_lbls, BATCH_SIZE)

    best_path = os.path.join(OUT_DIR, "best.weights.h5")

    callbacks = [
        # val_loss 기준으로 best 가중치 저장
        tf.keras.callbacks.ModelCheckpoint(
            filepath=best_path,
            monitor="val_loss",
            save_best_only=True,
            save_weights_only=True,
            verbose=1,
        ),
        # 합성 검증셋으로 val_accuracy 5에폭마다 계산
        ValAccCallback(va_imgs, va_lbls, every=5),
        # 실사진 10에폭마다 점검 (저장은 위에서 담당)
        RealTestCallback(real_imgs, real_lbls, every=10),
        # val_loss가 20에폭 동안 안 줄면 조기 종료
        tf.keras.callbacks.EarlyStopping(
            monitor="val_loss",
            patience=20,
            restore_best_weights=True,
            verbose=1,
        ),
    ]

    model.fit(
        train_seq,
        validation_data=val_ds,
        epochs=EPOCHS,
        callbacks=callbacks,
        verbose=1,
    )

    # 최종 평가
    print("\n===== 최종 평가 =====")
    evaluate(model, real_imgs, real_lbls, tag="실사진(테스트 전체)", show=20)
    evaluate(model, va_imgs[:500], va_lbls[:500], tag="합성 검증(참고용)", show=3)

    # TFLite INT8 변환
    print("\nTFLite INT8 변환...")
    rep = np.concatenate([tr_imgs[:200], real_imgs]) if len(real_imgs) else tr_imgs[:300]
    tfl = convert_tflite(model, rep)

    out_path = os.path.join(OUT_DIR, "bus_rec_int8.tflite")
    with open(out_path, "wb") as f:
        f.write(tfl)
    print(f"저장: {out_path}  ({len(tfl) / 1024:.1f} KB)")

    check_tflite(tfl, real_imgs, real_lbls)

    # 보드용 사전 헤더 생성
    header = os.path.join(OUT_DIR, "bus_dict.h")
    with open(header, "w", encoding="utf-8") as f:
        f.write("// 자동 생성됨: train_rec.py\n")
        f.write("// 버스 노선번호 전용 글자 사전 (CTC blank 포함)\n")
        f.write("#pragma once\n\n")
        f.write(f"static const int KOREAN_DICT_SIZE = {NUM_CLASSES};\n\n")
        f.write("static const char* const KOREAN_DICT_TABLE[] = {\n")
        f.write('    "",  // idx 0: blank\n')
        for c in CHARSET:
            f.write(f'    "{c}",\n')
        f.write("};\n\n")
        f.write("inline const char* idx2char(int idx) {\n")
        f.write("    if (idx < 0 || idx >= KOREAN_DICT_SIZE) return nullptr;\n")
        f.write("    return KOREAN_DICT_TABLE[idx];\n")
        f.write("}\n")
    print(f"저장: {header}")


if __name__ == "__main__":
    main()
