"""
점자블록 단일 박스 회귀 모델 학습
────────────────────────────────────
입력 : 그레이스케일 이미지 (어떤 해상도든 IMG_SIZE 로 리사이즈)
라벨 : YOLO 형식  class cx cy w h  (0~1 정규화)  — 이미지당 1개
백본 : MobileNetV2 alpha=0.35 (ImageNet pretrained)
헤드 : GAP → Dense → [cx, cy, w, h, conf]   (그리드/앵커/NMS 없음)

왜 그리드를 버렸나
────────────────
데이터를 보니 이미지당 객체 1.05개, 박스 크기가 이미지의 38~92%.
GRID=7이면 셀 하나가 이미지의 14%라 큰 박스가 6개 셀에 걸친다.
중심 셀만 positive로 두면 모델이 보기에 옆 셀과 특징이 동일해서
"이 셀만 정답"을 학습할 수 없다 (precision 0.02에 머물던 원인).
객체가 1개뿐이므로 탐지가 아니라 회귀로 푸는 것이 맞다.
"""

import os, glob, cv2, random, math
import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt
from pathlib import Path

# ── 설정 ─────────────────────────────────────────────────────────────────────
TRAIN_IMG  = "/content/brailblock/brailblock/images/train"
TRAIN_LBL  = "/content/brailblock/brailblock/labels/train"
VAL_IMG    = "/content/brailblock/brailblock/images/val"
VAL_LBL    = "/content/brailblock/brailblock/labels/val"
SAVE_DIR   = "/content/drive/MyDrive/brailblock/model3"
os.makedirs(SAVE_DIR, exist_ok=True)

IMG_SIZE   = 224
BATCH_SIZE = 32
EPOCHS     = 100
LR_INIT    = 1e-4   # 백본 전체 학습이라 낮게
IOU_THRESH = 0.5     # 평가 기준

N_TRAIN          = 11410
N_VAL            = 2844
STEPS_PER_EPOCH  = math.ceil(N_TRAIN / BATCH_SIZE)
VALIDATION_STEPS = math.ceil(N_VAL   / BATCH_SIZE)

# ── 1. 데이터 파이프라인 ──────────────────────────────────────────────────────
def load_sample(img_path, lbl_path, augment=False):
    """반환: img (H,W,1) float32, target (5,) = [cx, cy, w, h, has_obj]"""
    img = cv2.imread(str(img_path), cv2.IMREAD_GRAYSCALE)
    if img is None:
        img = np.zeros((IMG_SIZE, IMG_SIZE), dtype=np.uint8)
    img = cv2.resize(img, (IMG_SIZE, IMG_SIZE))

    # 라벨: 여러 개면 면적이 가장 큰 것 하나만 사용
    boxes = []
    if os.path.exists(lbl_path):
        for line in open(lbl_path):
            p = line.strip().split()
            if len(p) == 5:
                boxes.append([float(p[1]), float(p[2]), float(p[3]), float(p[4])])

    if boxes:
        boxes.sort(key=lambda b: b[2] * b[3], reverse=True)
        box = boxes[0]
    else:
        box = [0.0, 0.0, 0.0, 0.0]

    has_obj = 1.0 if boxes else 0.0

    if augment:
        if random.random() < 0.5:
            img = cv2.flip(img, 1)
            if has_obj:
                box = [1.0 - box[0], box[1], box[2], box[3]]
        alpha = random.uniform(0.75, 1.25)
        beta  = random.uniform(-25, 25)
        img = np.clip(img.astype(np.float32) * alpha + beta, 0, 255).astype(np.uint8)
        if random.random() < 0.4:
            img = np.clip(img.astype(np.float32)
                          + np.random.randn(*img.shape) * 6, 0, 255).astype(np.uint8)
        if random.random() < 0.2:
            k = random.choice([3, 5])
            kernel = np.zeros((k, k)); kernel[k // 2] = 1 / k
            img = cv2.filter2D(img, -1, kernel)

    img_f  = img.astype(np.float32)[..., np.newaxis] / 255.0
    target = np.array(box + [has_obj], dtype=np.float32)
    return img_f, target

def make_tf_dataset(img_dir, lbl_dir, augment, batch, shuffle):
    exts   = ("*.jpeg", "*.jpg", "*.png", "*.bmp")
    paths  = sorted(sum([glob.glob(f"{img_dir}/{e}") for e in exts], []))
    labels = [f"{lbl_dir}/{Path(p).stem}.txt" for p in paths]
    print(f"  {os.path.basename(img_dir)}: {len(paths)}장")

    def gen():
        idxs = list(range(len(paths)))
        if shuffle: random.shuffle(idxs)
        for i in idxs:
            yield load_sample(paths[i], labels[i], augment)

    ds = tf.data.Dataset.from_generator(
        gen,
        output_signature=(
            tf.TensorSpec((IMG_SIZE, IMG_SIZE, 1), tf.float32),
            tf.TensorSpec((5,), tf.float32),
        )
    )
    if shuffle: ds = ds.shuffle(1000)
    return ds.batch(batch).repeat().prefetch(tf.data.AUTOTUNE)

print("데이터셋 구성 중...")
train_ds = make_tf_dataset(TRAIN_IMG, TRAIN_LBL, augment=True,  batch=BATCH_SIZE, shuffle=True)
val_ds   = make_tf_dataset(VAL_IMG,   VAL_LBL,   augment=False, batch=BATCH_SIZE, shuffle=False)
print(f"  steps_per_epoch={STEPS_PER_EPOCH}, validation_steps={VALIDATION_STEPS}")

# ── 2. 배치 시각화 ────────────────────────────────────────────────────────────
def draw_box(img_gray, box, color=(0, 255, 0), vis=None):
    if vis is None:
        vis = cv2.cvtColor((img_gray * 255).astype(np.uint8), cv2.COLOR_GRAY2RGB)
    H, W = vis.shape[:2]
    cx, cy, w, h = box[:4]
    if w <= 0 or h <= 0:
        return vis
    x1, y1 = int((cx - w / 2) * W), int((cy - h / 2) * H)
    x2, y2 = int((cx + w / 2) * W), int((cy + h / 2) * H)
    cv2.rectangle(vis, (x1, y1), (x2, y2), color, 2)
    return vis

def show_batch(ds, title="배치 샘플", n=8):
    imgs, tgts = next(iter(ds))
    imgs_np, tgts_np = imgs.numpy()[:n], tgts.numpy()[:n]
    cols = 4; rows = (n + cols - 1) // cols
    fig, axes = plt.subplots(rows, cols, figsize=(cols * 3, rows * 3))
    for i, ax in enumerate(axes.flatten()):
        if i < n:
            ax.imshow(draw_box(imgs_np[i, ..., 0], tgts_np[i]))
        ax.axis("off")
    plt.suptitle(title + "  (green=GT)"); plt.tight_layout(); plt.show()

print("\n--- 학습 배치 샘플 ---")
show_batch(train_ds, "train batch")

# ── 3. 모델 ───────────────────────────────────────────────────────────────────
def build_model():
    """
    MobileNetV2 alpha=0.35 pretrained + 단일 박스 회귀 헤드
    출력: [cx, cy, w, h, conf]  — 전부 sigmoid로 0~1 범위
    """
    inp = tf.keras.Input((IMG_SIZE, IMG_SIZE, 1), name="image")

    # 그레이스케일 → 3채널 + MobileNetV2 전처리 ([0,1] → [-1,1])
    # output_shape를 명시해야 저장된 .keras를 나중에 load_model로 읽을 수 있다.
    # (없으면 Lambda의 출력 shape을 추론하지 못해 로드가 실패한다)
    x = tf.keras.layers.Lambda(
        lambda t: tf.keras.applications.mobilenet_v2.preprocess_input(
            tf.repeat(t * 255.0, 3, axis=-1)
        ),
        output_shape=(IMG_SIZE, IMG_SIZE, 3),
        name="gray_to_rgb"
    )(inp)

    backbone = tf.keras.applications.MobileNetV2(
        alpha=0.35, include_top=False,
        input_shape=(IMG_SIZE, IMG_SIZE, 3), weights="imagenet"
    )
    backbone.trainable = True            # 전체 학습 (freeze 없음)
    x = backbone(x, training=True)       # (B, 7, 7, 112)

    # GAP은 7×7 격자를 평균내 위치 정보를 없앤다 (분류용).
    # 박스 좌표 회귀에는 공간 정보가 필요하므로 채널만 줄이고 Flatten.
    x = tf.keras.layers.Conv2D(32, 1, activation="relu")(x)   # (B, 7, 7, 32)
    x = tf.keras.layers.Flatten()(x)                          # (B, 1568)
    x = tf.keras.layers.Dropout(0.3)(x)
    x = tf.keras.layers.Dense(128, activation="relu")(x)
    x = tf.keras.layers.Dropout(0.2)(x)
    out = tf.keras.layers.Dense(5, activation="sigmoid", name="box")(x)

    model = tf.keras.Model(inp, out, name="brailblock_reg")
    model._backbone = backbone
    return model

model = build_model()
print(f"\n파라미터: {model.count_params():,}")

# ── 4. 손실 · 메트릭 ──────────────────────────────────────────────────────────
def box_loss(y_true, y_pred):
    """
    y_true, y_pred: (B, 5) = [cx, cy, w, h, conf]
    객체가 있는 샘플만 좌표 손실을 계산한다.
    """
    has_obj = y_true[:, 4:5]

    coord_err = tf.reduce_sum(
        tf.square(y_true[:, :4] - y_pred[:, :4]), axis=-1, keepdims=True)
    coord_loss = tf.reduce_sum(has_obj * coord_err) / (tf.reduce_sum(has_obj) + 1e-7)

    conf_loss = tf.reduce_mean(
        tf.keras.losses.binary_crossentropy(y_true[:, 4:5], y_pred[:, 4:5]))

    return 5.0 * coord_loss + 1.0 * conf_loss

class MeanIoU(tf.keras.metrics.Metric):
    """객체가 있는 샘플의 평균 IoU"""
    def __init__(self, **kw):
        super().__init__(**kw)
        self.total = self.add_weight(name="total", shape=(), initializer="zeros")
        self.count = self.add_weight(name="count", shape=(), initializer="zeros")

    def update_state(self, y_true, y_pred, sample_weight=None):
        has_obj = y_true[:, 4]
        t, p = y_true[:, :4], y_pred[:, :4]

        t_x1, t_y1 = t[:, 0] - t[:, 2] / 2, t[:, 1] - t[:, 3] / 2
        t_x2, t_y2 = t[:, 0] + t[:, 2] / 2, t[:, 1] + t[:, 3] / 2
        p_x1, p_y1 = p[:, 0] - p[:, 2] / 2, p[:, 1] - p[:, 3] / 2
        p_x2, p_y2 = p[:, 0] + p[:, 2] / 2, p[:, 1] + p[:, 3] / 2

        iw = tf.maximum(0.0, tf.minimum(t_x2, p_x2) - tf.maximum(t_x1, p_x1))
        ih = tf.maximum(0.0, tf.minimum(t_y2, p_y2) - tf.maximum(t_y1, p_y1))
        inter = iw * ih
        union = t[:, 2] * t[:, 3] + p[:, 2] * p[:, 3] - inter + 1e-7
        iou = inter / union

        self.total.assign_add(tf.reduce_sum(iou * has_obj))
        self.count.assign_add(tf.reduce_sum(has_obj))

    def result(self):
        return self.total / (self.count + 1e-7)

    def reset_state(self):
        self.total.assign(0.0); self.count.assign(0.0)

class IoUAccuracy(tf.keras.metrics.Metric):
    """IoU >= threshold 인 샘플 비율 (실질 정확도)"""
    def __init__(self, thresh=IOU_THRESH, **kw):
        super().__init__(**kw)
        self.thresh = thresh
        self.hit   = self.add_weight(name="hit",   shape=(), initializer="zeros")
        self.count = self.add_weight(name="count", shape=(), initializer="zeros")

    def update_state(self, y_true, y_pred, sample_weight=None):
        has_obj = y_true[:, 4]
        t, p = y_true[:, :4], y_pred[:, :4]

        t_x1, t_y1 = t[:, 0] - t[:, 2] / 2, t[:, 1] - t[:, 3] / 2
        t_x2, t_y2 = t[:, 0] + t[:, 2] / 2, t[:, 1] + t[:, 3] / 2
        p_x1, p_y1 = p[:, 0] - p[:, 2] / 2, p[:, 1] - p[:, 3] / 2
        p_x2, p_y2 = p[:, 0] + p[:, 2] / 2, p[:, 1] + p[:, 3] / 2

        iw = tf.maximum(0.0, tf.minimum(t_x2, p_x2) - tf.maximum(t_x1, p_x1))
        ih = tf.maximum(0.0, tf.minimum(t_y2, p_y2) - tf.maximum(t_y1, p_y1))
        inter = iw * ih
        union = t[:, 2] * t[:, 3] + p[:, 2] * p[:, 3] - inter + 1e-7
        iou = inter / union

        self.hit.assign_add(
            tf.reduce_sum(tf.cast(iou >= self.thresh, tf.float32) * has_obj))
        self.count.assign_add(tf.reduce_sum(has_obj))

    def result(self):
        return self.hit / (self.count + 1e-7)

    def reset_state(self):
        self.hit.assign(0.0); self.count.assign(0.0)

model.compile(
    optimizer=tf.keras.optimizers.Adam(LR_INIT, clipnorm=1.0),
    loss=box_loss,
    metrics=[MeanIoU(name="iou"), IoUAccuracy(name="acc50")]
)

# ── 5. 콜백 ───────────────────────────────────────────────────────────────────
class SaveEvery10(tf.keras.callbacks.Callback):
    def on_epoch_end(self, epoch, logs=None):
        if (epoch + 1) % 10 == 0:
            path = f"{SAVE_DIR}/ckpt_{epoch+1:03d}.keras"
            self.model.save(path)
            print(f"  ckpt 저장: {path}")

callbacks = [
    tf.keras.callbacks.ModelCheckpoint(
        f"{SAVE_DIR}/best.keras",
        monitor="val_acc50", mode="max", save_best_only=True, verbose=1),
    tf.keras.callbacks.EarlyStopping(
        monitor="val_loss", patience=15, restore_best_weights=True, verbose=1),
    tf.keras.callbacks.ReduceLROnPlateau(
        monitor="val_loss", factor=0.5, patience=7, min_lr=1e-6, verbose=1),
    tf.keras.callbacks.CSVLogger(f"{SAVE_DIR}/log.csv", append=True),
    SaveEvery10(),
]

# ── 6. 학습 ───────────────────────────────────────────────────────────────────
history = model.fit(
    train_ds,
    validation_data=val_ds,
    epochs=EPOCHS,
    steps_per_epoch=STEPS_PER_EPOCH,
    validation_steps=VALIDATION_STEPS,
    callbacks=callbacks,
    verbose=1,
)

# ── 7. 학습 곡선 ──────────────────────────────────────────────────────────────
fig, (ax1, ax2, ax3) = plt.subplots(1, 3, figsize=(16, 4))
ax1.plot(history.history["loss"],     label="train")
ax1.plot(history.history["val_loss"], label="val")
ax1.set_title("Loss"); ax1.legend(); ax1.grid(True)

ax2.plot(history.history["iou"],     label="train")
ax2.plot(history.history["val_iou"], label="val")
ax2.set_title("Mean IoU"); ax2.legend(); ax2.grid(True)

ax3.plot(history.history["acc50"],     label="train")
ax3.plot(history.history["val_acc50"], label="val")
ax3.set_title("Accuracy (IoU>=0.5)"); ax3.legend(); ax3.grid(True)
plt.tight_layout()
plt.savefig(f"{SAVE_DIR}/curves.png", dpi=120)
plt.show()

print(f"최고 val IoU  : {max(history.history['val_iou']):.4f}")
print(f"최고 val acc50: {max(history.history['val_acc50']):.4f}")

# ── 8. 검증셋 예측 시각화 ─────────────────────────────────────────────────────
def show_predictions(model, ds, n=8):
    imgs, tgts = next(iter(ds))
    preds = model.predict(imgs[:n], verbose=0)
    cols = 4; rows = (n + cols - 1) // cols
    fig, axes = plt.subplots(rows, cols, figsize=(cols * 3, rows * 3))
    for i, ax in enumerate(axes.flatten()):
        if i >= n:
            ax.axis("off"); continue
        vis = draw_box(imgs.numpy()[i, ..., 0], tgts.numpy()[i], color=(0, 255, 0))
        vis = draw_box(None, preds[i], color=(0, 120, 255), vis=vis)
        ax.imshow(vis)
        ax.set_title(f"conf={preds[i][4]:.2f}", fontsize=8)
        ax.axis("off")
    plt.suptitle("val prediction   green=GT  blue=pred")
    plt.tight_layout(); plt.show()

print("\n--- 검증셋 예측 ---")
show_predictions(model, val_ds)

# ── 9. TFLite INT8 변환 ───────────────────────────────────────────────────────
print("\n=== TFLite INT8 변환 ===")
converter = tf.lite.TFLiteConverter.from_keras_model(model)
converter.optimizations = [tf.lite.Optimize.DEFAULT]

def representative_dataset():
    for imgs, _ in val_ds.unbatch().batch(1).take(200):
        yield [imgs]

converter.representative_dataset  = representative_dataset
converter.target_spec.supported_ops = [tf.lite.OpsSet.TFLITE_BUILTINS_INT8]
converter.inference_input_type  = tf.float32
converter.inference_output_type = tf.float32

tflite_model = converter.convert()
tflite_path  = f"{SAVE_DIR}/brailblock_int8.tflite"
with open(tflite_path, "wb") as f:
    f.write(tflite_model)
print(f"저장: {tflite_path}  ({len(tflite_model)/1024:.1f} KB)")
