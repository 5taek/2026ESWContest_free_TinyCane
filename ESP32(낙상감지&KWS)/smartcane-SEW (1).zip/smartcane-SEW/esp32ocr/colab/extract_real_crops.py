# ============================================================
# 실사진에서 rec 학습/평가용 조각 자동 추출
#
# 기존 PaddleOCR 파이프라인(det + rec)을 라벨링 도구로 쓴다.
#   det : 글자 영역을 전부 찾음 (무엇이 노선번호인지는 모름)
#   rec : 각 영역을 읽음 -> 노선 목록과 대조해 노선번호만 남김
#         "det가 못 하는 판단을 rec이 대신한다"
#
# 출력 구조:
#   crops/ok/     {라벨}_{일련번호}.png   노선 목록과 일치 -> 신뢰 가능
#   crops/unsure/ {읽은값}_{일련번호}.png  불일치 -> 사람이 확인
#
# 검수 방법:
#   - ok 폴더를 훑어보며 파일명이 틀린 것만 이름 수정
#   - unsure 폴더에서 실제 노선번호인 것을 찾아 이름을 고쳐 ok로 옮김
#   - 나머지(광고, 차량번호판 등)는 삭제
#
# 중요: 조각을 640x480 축소본에서 자른다.
#   보드도 640x480(또는 카메라 프레임)에서 자르기 때문에, 원본 고해상도에서
#   자르면 학습 데이터가 실전보다 선명해져서 분포가 어긋난다.
# ============================================================

import os
import glob
import numpy as np
import cv2
import paddle
import pyclipper
from shapely.geometry import Polygon

# Paddle 3.x는 PIR 모드가 기본이라 새 포맷(.json)을 기대한다.
# 우리 모델은 구형 포맷(.pdmodel + .pdiparams)이므로 PIR을 꺼야 한다.
# (안 끄면 "attempting to parse an empty input" JSON 파싱 에러가 난다)
try:
    paddle.base.framework.set_flags({"FLAGS_enable_pir_api": False})
except Exception:
    pass

paddle.enable_static()

# ==========================================
# 경로
#
# 선생 모델은 INT8 양자화본이 아니라 **Paddle 원본 추론 모델**을 쓴다.
# 양자화본은 보드에 올리려고 정확도를 희생한 것이고, 라벨링에는 가장 정확한
# 모델을 써야 한다. (실측: 같은 사진에서 native "북구2" vs INT8 "불구2")
# ==========================================
IMAGE_DIR = "/content/drive/MyDrive/busdet"          # 버스 사진들
OUT_DIR = "/content/drive/MyDrive/rec_v2/real"

DET_PADDLE_PREFIX = "/content/drive/MyDrive/det_real/inference"
REC_PADDLE_PREFIX = "/content/drive/MyDrive/det/inference"   # rec 원본이 det 폴더에 있음(폴더명 주의)
DICT_PATH = "/content/drive/MyDrive/rec_pipeline/korean_dict.txt"

# ==========================================
# 보드와 동일한 설정
# ==========================================
SRC_W, SRC_H = 640, 480      # 보드가 다루는 프레임 크기
DET_H, DET_W = 224, 224      # 현재 det 입력
REC_H, REC_W = 32, 160       # 새 rec 입력 (보드 수정 예정값)
PAD_VALUE = 127              # 정규화 시 0.0이 되는 값

DET_MEAN = np.array([0.485, 0.456, 0.406], dtype=np.float32)
DET_STD = np.array([0.229, 0.224, 0.225], dtype=np.float32)

# 기존 rec 모델(선생)의 입력 규격
OLD_REC_H, OLD_REC_W = 48, 320

# ==========================================
# 대구 노선 목록 (라벨 검증용)
# gen_synthetic_rec.py 의 ROUTES 와 동일하게 유지할 것
# ==========================================
ROUTES = set([
    "직행1", "직행2",
    "급행1", "급행2", "급행3", "급행5", "급행7", "급행8", "급행8-1",
    "급행9", "급행9-1", "급행9-2", "급행9-3", "급행10",
    "순환2", "순환2-1", "순환3", "순환3-1",
    "101", "101-1", "156", "204", "232", "232-1", "240",
    "300", "304", "306", "309", "320", "326", "349", "356",
    "401", "402", "403", "405", "410", "410-1", "413", "425",
    "501", "503", "504", "509", "518", "520", "523", "527",
    "564", "609", "618", "623", "649", "650", "651", "653",
    "655", "665", "706", "707", "708", "719", "724", "725",
    "726", "730", "802", "805", "814", "836", "848", "894", "937",
    "남구1", "남구1-1", "남구2",
    "동구1", "동구1-1", "동구3", "동구4", "동구4-1", "동구5",
    "동구6", "동구7", "동구8", "동구10",
    "북구1", "북구2", "북구3", "북구4", "북구5", "북구6", "북구7", "북구8",
    "서구1", "서구2",
    "성서1", "성서1-1", "성서2", "성서3",
    "수성1", "수성1-1", "수성2", "수성3", "수성3-1", "수성4", "수성5", "수성6",
    "달서1", "달서2", "달서3", "달서5", "달서6",
    "달성1", "달성2", "달성3", "달성4", "달성5", "달성6", "달성7",
    "칠곡1", "칠곡1-1", "칠곡2", "칠곡3", "칠곡5",
    "가창2", "팔공1",
])

CHARSET = set("0123456789직행급순환남구동북서성수달칠곡가창팔공-")

# ==========================================
# 선생 모델 로딩
# ==========================================
with open(DICT_PATH, "r", encoding="utf-8") as f:
    chars = [line.rstrip("\n") for line in f]
idx2char = {0: ""}
for i, ch in enumerate(chars):
    idx2char[i + 1] = ch


class PaddleModel:
    """Paddle 정적 그래프 추론 모델 래퍼.

    det와 rec을 같은 스코프에 로드하면 파라미터 이름이 겹쳐서 한쪽이 다른 쪽을
    덮어쓴다 (conv2d 채널 불일치 같은 엉뚱한 에러로 나타남).
    반드시 스코프를 분리해야 한다.
    """

    def __init__(self, prefix, tag=""):
        self.tag = tag
        self.scope = paddle.static.Scope()
        self.exe = paddle.static.Executor(paddle.CPUPlace())
        with paddle.static.scope_guard(self.scope):
            self.program, self.feed, self.fetch = \
                paddle.static.load_inference_model(path_prefix=prefix, executor=self.exe)

        # 모델이 기대하는 입력 형상을 확인한다.
        # (-1은 가변 차원. 높이가 고정이면 그 값에 맞춰 전처리해야 한다)
        block = self.program.global_block()
        for name in self.feed:
            try:
                print(f"  [{tag}] feed '{name}' shape = {block.var(name).shape}")
            except Exception:
                print(f"  [{tag}] feed '{name}' (형상 확인 실패)")

    def run(self, x):
        """x: NCHW float32"""
        with paddle.static.scope_guard(self.scope):
            return self.exe.run(self.program,
                                feed={self.feed[0]: x},
                                fetch_list=self.fetch)


# ==========================================
# det 전처리 / 후처리 (기존 파이프라인과 동일)
# ==========================================
def preprocess_det(img_rgb):
    r = cv2.resize(img_rgb, (DET_W, DET_H)).astype(np.float32) / 255.0
    return (r - DET_MEAN) / DET_STD


def unclip_poly(points, ratio=1.6):
    poly = Polygon(points)
    if poly.length == 0:
        return None
    dist = poly.area * ratio / poly.length
    off = pyclipper.PyclipperOffset()
    off.AddPath(points, pyclipper.JT_ROUND, pyclipper.ET_CLOSEDPOLYGON)
    ex = off.Execute(dist)
    return np.array(ex[0]) if ex else None


def find_boxes(prob_map, out_h, out_w,
               thresh=0.3, box_thresh=0.5, unclip_ratio=1.6, min_area=10):
    bitmap = (prob_map > thresh).astype(np.uint8) * 255
    contours, _ = cv2.findContours(bitmap, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
    sx, sy = out_w / DET_W, out_h / DET_H

    boxes = []
    for cnt in contours:
        if cv2.contourArea(cnt) < min_area:
            continue
        rect = cv2.minAreaRect(cnt)
        pts = cv2.boxPoints(rect)
        x, y, w, h = cv2.boundingRect(cnt)
        if w == 0 or h == 0:
            continue
        score = float(prob_map[y:y + h, x:x + w].mean())
        if score < box_thresh:
            continue
        ex = unclip_poly(pts.tolist(), unclip_ratio)
        if ex is None or len(ex) == 0:
            ex = pts
        xs, ys = ex[:, 0], ex[:, 1]
        box = (max(0, int(xs.min() * sx)), max(0, int(ys.min() * sy)),
               min(out_w, int(xs.max() * sx)), min(out_h, int(ys.max() * sy)))
        if box[2] <= box[0] or box[3] <= box[1]:
            continue
        boxes.append((box, score))

    boxes.sort(key=lambda b: -b[1])
    return [b[0] for b in boxes]


# ==========================================
# 선생 rec (기존 3690 클래스 모델)
# ==========================================
def preprocess_old_rec(crop_rgb):
    h, w = crop_rgb.shape[:2]
    if h == 0 or w == 0:
        return None
    ratio = w / float(h)
    rw = min(OLD_REC_W, max(1, int(np.ceil(OLD_REC_H * ratio))))
    r = cv2.resize(crop_rgb, (rw, OLD_REC_H)).astype(np.float32) / 255.0
    r = (r - 0.5) / 0.5
    padded = np.zeros((OLD_REC_H, OLD_REC_W, 3), dtype=np.float32)
    padded[:, :rw, :] = r
    return padded


def ctc_decode(output):
    idxs = np.argmax(output, axis=-1)
    out, prev = [], -1
    for i in idxs:
        if i != prev and i != 0:
            out.append(int(i))
        prev = i
    return "".join(idx2char.get(i, "?") for i in out)


# 혼동 문자 보정 (보드의 normalize_confusables 와 동일한 취지)
CONFUSE = {
    "O": "0", "o": "0", "D": "0", "Q": "0",
    "I": "1", "l": "1", "|": "1", "i": "1",
    "Z": "2", "z": "2", "S": "5", "s": "5",
    "B": "8", "G": "6", "g": "9", "q": "9",
}


def sanitize(text):
    """선생이 읽은 문자열을 정리한다."""
    t = "".join(CONFUSE.get(c, c) for c in text)
    t = "".join(c for c in t if c in CHARSET)   # 글자셋 밖 문자 제거
    return t


# ==========================================
# 보드와 동일한 rec 입력 형식으로 변환
# ==========================================
def to_board_format_gray(crop_bgr):
    """그레이스케일 -> 높이 REC_H 맞춤 -> 남는 폭은 127로 패딩"""
    gray = cv2.cvtColor(crop_bgr, cv2.COLOR_BGR2GRAY)
    h, w = gray.shape
    if h == 0 or w == 0:
        return None
    scale = REC_H / h
    nw = max(1, min(REC_W, int(round(w * scale))))
    r = cv2.resize(gray, (nw, REC_H), interpolation=cv2.INTER_AREA)
    out = np.full((REC_H, REC_W), PAD_VALUE, dtype=np.uint8)
    out[:, :nw] = r
    return out


# ==========================================
# 실행
# ==========================================
def main():
    ok_dir = os.path.join(OUT_DIR, "ok")
    unsure_dir = os.path.join(OUT_DIR, "unsure")
    for d in (ok_dir, unsure_dir):
        os.makedirs(d, exist_ok=True)

    print("선생 모델 로딩 (Paddle 원본)...")
    det_model = PaddleModel(DET_PADDLE_PREFIX, "det")
    rec_model = PaddleModel(REC_PADDLE_PREFIX, "rec")

    paths = sorted(
        glob.glob(os.path.join(IMAGE_DIR, "*.jpg")) +
        glob.glob(os.path.join(IMAGE_DIR, "*.jpeg")) +
        glob.glob(os.path.join(IMAGE_DIR, "*.png"))
    )
    print(f"사진 {len(paths)}장\n")

    n_ok = n_unsure = 0

    for pi, path in enumerate(paths):
        img = cv2.imread(path)
        if img is None:
            print(f"[읽기 실패] {os.path.basename(path)}")
            continue

        # 보드와 같은 조건: 640x480으로 축소한 것에서 시작
        small_bgr = cv2.resize(img, (SRC_W, SRC_H), interpolation=cv2.INTER_AREA)
        small_rgb = cv2.cvtColor(small_bgr, cv2.COLOR_BGR2RGB)

        # Paddle은 NCHW 입력
        det_in = np.expand_dims(preprocess_det(small_rgb).transpose(2, 0, 1), 0)
        prob = det_model.run(det_in)[0][0, 0]     # (H, W)

        boxes = find_boxes(prob, SRC_H, SRC_W)
        base = os.path.splitext(os.path.basename(path))[0]

        for bi, (x1, y1, x2, y2) in enumerate(boxes):
            crop_bgr = small_bgr[y1:y2, x1:x2]
            crop_rgb = small_rgb[y1:y2, x1:x2]
            if crop_bgr.size == 0:
                continue

            ri = preprocess_old_rec(crop_rgb)
            if ri is None:
                continue
            rec_in = np.expand_dims(ri.transpose(2, 0, 1), 0)   # NCHW
            if pi == 0 and bi == 0:
                print(f"  [진단] det 입력 {det_in.shape}, rec 입력 {rec_in.shape}")
            raw = ctc_decode(rec_model.run(rec_in)[0][0])
            label = sanitize(raw)

            out_img = to_board_format_gray(crop_bgr)
            if out_img is None:
                continue

            if label in ROUTES:
                fn = f"{label}_{base}_{bi}.png"
                cv2.imwrite(os.path.join(ok_dir, fn), out_img)
                n_ok += 1
            else:
                safe = label if label else "empty"
                fn = f"{safe}_{base}_{bi}.png"
                cv2.imwrite(os.path.join(unsure_dir, fn), out_img)
                n_unsure += 1

        print(f"[{pi + 1}/{len(paths)}] {base}: 박스 {len(boxes)}개")

    print(f"\n완료")
    print(f"  ok     : {n_ok}개  -> {ok_dir}")
    print(f"  unsure : {n_unsure}개  -> {unsure_dir}")
    print("\n다음 할 일:")
    print("  1) ok 폴더를 훑어보며 파일명이 틀린 것만 수정")
    print("  2) unsure 폴더에서 진짜 노선번호를 찾아 이름 고쳐 ok로 이동")
    print("  3) 나머지(광고/차량번호/정류장명 등)는 삭제")


if __name__ == "__main__":
    main()
