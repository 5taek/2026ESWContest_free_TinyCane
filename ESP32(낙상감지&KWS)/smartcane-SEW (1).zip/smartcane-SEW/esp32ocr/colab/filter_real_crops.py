# ============================================================
# filter_real_crops.py
#
# 실사진 crop 중에서 EasyOCR이 올바른 노선번호를 인식하는 것만 남긴다.
#
# 사용법 (Colab):
#   !pip install easyocr -q
#   !python filter_real_crops.py
#
# 파일명 형식: {노선번호}_{원본사진명}_{박스번호}.png
# EasyOCR이 노선번호를 검출하지 못하면 DROP.
# ============================================================

import os
import shutil
import numpy as np
import cv2
import easyocr

# ── 경로 설정 ──────────────────────────────────────────────
REAL_DIR = "/content/drive/MyDrive/rec_v2/real/ok"       # 필터링할 원본 폴더
OUT_DIR  = "/content/drive/MyDrive/rec_v2/real/filtered" # 통과한 이미지 저장

# ── EasyOCR 초기화 ─────────────────────────────────────────
print("EasyOCR 초기화 중...")
reader = easyocr.Reader(['ko', 'en'], gpu=False)
print("완료\n")

os.makedirs(OUT_DIR, exist_ok=True)

files = sorted(f for f in os.listdir(REAL_DIR) if f.endswith('.png'))
print(f"대상 파일: {len(files)}장")
print("-" * 60)

kept = []
dropped = []

for f in files:
    label = f.split('_')[0]   # 노선번호 = 파일명 첫 번째 '_' 앞
    path  = os.path.join(REAL_DIR, f)

    # EasyOCR은 그레이스케일 crop을 확대해야 더 잘 읽는다
    img = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
    # 32x160 → 64x320 (2배 확대)
    img_big = cv2.resize(img, (img.shape[1] * 2, img.shape[0] * 2),
                         interpolation=cv2.INTER_CUBIC)
    # EasyOCR은 BGR or RGB 입력 가능, grayscale도 됨
    results = reader.readtext(img_big, detail=0, paragraph=False)
    detected = ''.join(results).replace(' ', '').strip()

    # 매칭 판단:
    # label이 detected에 포함되거나, label의 앞 절반 이상이 포함되면 KEEP
    def is_match(lbl, det):
        if lbl in det:
            return True
        # 숫자 부분만 비교 (한글 노선은 숫자가 틀리면 다른 버스)
        digits_lbl = ''.join(c for c in lbl if c.isdigit())
        digits_det = ''.join(c for c in det if c.isdigit())
        if digits_lbl and len(digits_lbl) >= 2 and digits_lbl in digits_det:
            return True
        return False

    if is_match(label, detected):
        shutil.copy(path, os.path.join(OUT_DIR, f))
        kept.append(f)
        print(f"KEEP  {f:50s}  검출: '{detected}'")
    else:
        dropped.append(f)
        print(f"DROP  {f:50s}  검출: '{detected}'")

print("\n" + "=" * 60)
print(f"결과: KEEP {len(kept)}장 / DROP {len(dropped)}장 / 전체 {len(files)}장")
print(f"저장 위치: {OUT_DIR}")

# DROP 목록 저장 (나중에 검토용)
with open(os.path.join(OUT_DIR, "_dropped.txt"), "w") as f_out:
    f_out.write("\n".join(dropped))
print(f"제거 목록: {OUT_DIR}/_dropped.txt")
