# ============================================================
# rec 모델 구조 비교 실험
#
# 과적합 테스트에서 "숫자는 완벽, 한글만 붕괴"가 나왔다.
#   숫자 정상 -> CTC/라벨 인코딩/출력 형상은 문제 없음
#   한글 붕괴 -> 표현력 부족 또는 학습 부족
#
# 세 조합을 같은 데이터로 돌려 원인을 가른다.
#   A : 현재 구조             -> 통과하면 그냥 학습이 부족했던 것
#   B : 채널 확대             -> 이것만 통과하면 용량 문제
#   C : 입력 높이 48          -> 이것만 통과하면 한글 세로구조 해상도 문제
#
# 숫자 정확도와 한글 포함 정확도를 따로 집계한다.
# ============================================================

import os
import glob
import random
import subprocess
import numpy as np
import cv2
import tensorflow as tf
from PIL import Image, ImageDraw, ImageFont

REC_W = 160
MAX_LABEL_LEN = 6
NUM_SAMPLES = 3000
BATCH_SIZE = 64
SEED = 42

# ==========================================
# 비교할 조합
# ==========================================
# 1차 sweep 결과: A/B/C 모두 숫자 1.000, 한글 0.20~0.25.
# 용량을 2배로 키워도(B), 높이를 48로 올려도(C) 한글이 그대로였다.
# -> 원인은 용량도 해상도도 아니고 **가로 수용영역**으로 보인다.
#
#    현재 구조의 가로 수용영역 = 26px
#    숫자 한 글자 폭 16~20px  -> 다 보임  -> 정확도 1.000
#    한글 한 글자 폭 28~32px  -> 못 다 봄 -> 부분만 보고 판단, 유사 글자로 붕괴
#
# 2차 sweep은 수용영역을 넓히는 두 방법을 시험한다.
#   D : 가로 풀링을 한 번 더 (stride 8) + 블록 추가  -> RF 약 54px, T는 20으로 감소
#   E : depthwise 커널 3x3 -> 5x5                    -> RF 약 50px, 연산 증가 적음
#   F : D + 높이 48
# 2차 sweep 결과
#   A(원래)          한글 0.204  손실 1.98
#   E(커널 5x5)      한글 0.377  손실 1.16   <- 가장 좋음, 파라미터도 가장 적음
#   F(RF확대+h48)    한글 0.309  손실 1.17
#   D(RF확대, h32)   한글 0.096  손실 3.82   <- 붕괴
#
# 해석:
#   - 커널 5x5로 수용영역을 넓힌 것이 효과적이었다 (0.204 -> 0.377)
#   - 가로 stride를 8로 키워 T=20으로 만든 D/F는 오히려 손해.
#     글자당 시점이 4개뿐이라 CTC 정렬이 어려워지는 것으로 보인다.
#     -> T는 40을 유지한다
#   - E의 오답을 보면 글자 수/배치/숫자는 맞고 한글의 정체만 틀린다.
#     구조는 파악하는데 19개 한글을 구분할 표현력이 모자란 상태.
#
# 3차 sweep: E의 성공 요소(5x5, T=40)를 유지한 채 높이와 용량, 학습량을 더한다.
CONFIGS = [
    dict(name="G_h48+5x5",    height=48, channels=(16, 32, 64, 96, 128),
         epochs=150, wide_rf=False, dw_kernel=5),
    dict(name="H_G+채널확대",  height=48, channels=(24, 48, 96, 144, 192),
         epochs=150, wide_rf=False, dw_kernel=5),
    dict(name="I_E+장기학습",  height=32, channels=(16, 32, 64, 96, 128),
         epochs=400, wide_rf=False, dw_kernel=5),
]

# ==========================================
# 글자셋
# ==========================================
DIGITS = list("0123456789")
HANGUL = list("직행급순환남구동북서성수달칠곡가창팔공")
SYMBOLS = ["-"]
CHARSET = DIGITS + HANGUL + SYMBOLS
NUM_CLASSES = len(CHARSET) + 1

char2idx = {c: i + 1 for i, c in enumerate(CHARSET)}
idx2char = {i + 1: c for i, c in enumerate(CHARSET)}
idx2char[0] = ""

# 한글이 든 노선을 넉넉히 포함시킨다 (한글 학습이 관건이므로)
ROUTES = [
    "503", "937", "410", "156", "204", "649", "836", "101-1",
    "북구2", "북구5", "급행1", "급행8-1", "순환3", "순환2-1",
    "달서1", "달성3", "수성2", "수성3-1", "성서1", "칠곡3",
    "동구5", "남구2", "서구2", "팔공1", "가창2", "직행2",
]


def encode(t):
    s = [char2idx[c] for c in t if c in char2idx][:MAX_LABEL_LEN]
    return np.array(s + [0] * (MAX_LABEL_LEN - len(s)), dtype=np.int32)


def normalize(x):
    return (x.astype(np.float32) / 255.0 - 0.5) / 0.5


def has_hangul(t):
    return any(c in HANGUL for c in t)


# ==========================================
# 깨끗한 합성 (증강 없음)
# ==========================================
def load_fonts():
    found = []
    try:
        out = subprocess.run(["fc-list", ":lang=ko", "--format=%{file}\\n"],
                             capture_output=True, text=True, timeout=30)
        found = [p for p in out.stdout.strip().split("\n") if p]
    except Exception:
        pass
    if not found:
        for d in ("/usr/share/fonts", "/usr/local/share/fonts"):
            for e in ("ttf", "otf", "ttc"):
                found += glob.glob(os.path.join(d, "**", f"*.{e}"), recursive=True)

    fonts = []
    for p in dict.fromkeys(found):
        try:
            f = ImageFont.truetype(p, 40)
            im = Image.new("L", (60, 60), 0)
            ImageDraw.Draw(im).text((5, 5), "북", font=f, fill=255)
            if np.array(im).sum() > 0:
                fonts.append(p)
        except Exception:
            pass
    if not fonts:
        raise FileNotFoundError("한글 폰트 없음. !apt-get install -y fonts-nanum")
    print(f"폰트 {len(fonts)}개")
    return fonts


def render_clean(text, font_path, rec_h, font_size=72):
    font = ImageFont.truetype(font_path, font_size)
    boxes = [font.getbbox(c) for c in text]
    widths = [b[2] - b[0] for b in boxes]
    top = min(b[1] for b in boxes)
    bottom = max(b[3] for b in boxes)
    total_w, total_h = sum(widths), bottom - top

    m = max(2, int(total_h * 0.08))
    img = Image.new("L", (total_w + m * 2, total_h + m * 2), 40)
    d = ImageDraw.Draw(img)
    x = m
    for i, c in enumerate(text):
        d.text((x - boxes[i][0], m - top), c, font=font, fill=230)
        x += widths[i]

    a = np.array(img)
    h, w = a.shape
    nw = max(1, min(REC_W, int(round(w * rec_h / h))))
    r = cv2.resize(a, (nw, rec_h), interpolation=cv2.INTER_AREA)
    out = np.full((rec_h, REC_W), 127, dtype=np.uint8)
    out[:, :nw] = r
    return out


def make_dataset(fonts, rec_h):
    imgs, lbls = [], []
    for i in range(NUM_SAMPLES):
        t = ROUTES[i % len(ROUTES)]
        imgs.append(render_clean(t, random.choice(fonts), rec_h))
        lbls.append(t)
    return np.array(imgs), lbls


# ==========================================
# 모델
# ==========================================
def build_model(rec_h, ch, wide_rf=False, dw_kernel=3):
    """
    wide_rf=False : 가로 stride 4 (T = REC_W/4 = 40)
    wide_rf=True  : 가로 stride 8 (T = REC_W/8 = 20) + 블록 하나 추가
                    -> 가로 수용영역이 26px에서 약 54px로 넓어진다
    dw_kernel     : depthwise 커널 크기. 5로 키우면 수용영역이 빠르게 늘고
                    depthwise라 연산 증가는 적다
    """
    c1, c2, c3, c4, c5 = ch
    inp = tf.keras.Input(shape=(rec_h, REC_W, 1))

    def dw(x, c):
        x = tf.keras.layers.DepthwiseConv2D(dw_kernel, padding="same", use_bias=False)(x)
        x = tf.keras.layers.BatchNormalization()(x)
        x = tf.keras.layers.ReLU()(x)
        x = tf.keras.layers.Conv2D(c, 1, padding="same", use_bias=False)(x)
        x = tf.keras.layers.BatchNormalization()(x)
        x = tf.keras.layers.ReLU()(x)
        return x

    x = tf.keras.layers.Conv2D(c1, 3, padding="same", use_bias=False)(inp)
    x = tf.keras.layers.BatchNormalization()(x)
    x = tf.keras.layers.ReLU()(x)
    x = tf.keras.layers.MaxPooling2D((2, 2))(x)          # h/2, w/2

    x = dw(x, c2)
    x = tf.keras.layers.MaxPooling2D((2, 2))(x)          # h/4, w/4

    x = dw(x, c3)
    if wide_rf:
        x = tf.keras.layers.MaxPooling2D((2, 2))(x)      # h/8, w/8
    else:
        x = tf.keras.layers.MaxPooling2D((2, 1))(x)      # h/8

    x = dw(x, c4)
    x = tf.keras.layers.MaxPooling2D((2, 1))(x)          # h/16

    if wide_rf:
        # 가로 stride가 8이므로 블록 하나를 더 쌓으면 수용영역이 크게 늘어난다
        x = dw(x, c4)

    # 남은 높이를 1로 눌러 시퀀스로
    rem_h = max(1, rec_h // 16)
    x = tf.keras.layers.Conv2D(c5, (rem_h, 1), padding="valid", use_bias=False)(x)
    x = tf.keras.layers.BatchNormalization()(x)
    x = tf.keras.layers.ReLU()(x)

    x = tf.keras.layers.Conv2D(NUM_CLASSES, 1, padding="same")(x)
    out = tf.keras.layers.Reshape((-1, NUM_CLASSES))(x)
    return tf.keras.Model(inp, out)


def ctc_loss_fn(y_true, y_pred):
    y_true = tf.cast(y_true, tf.int32)
    ll = tf.reduce_sum(tf.cast(y_true > 0, tf.int32), axis=-1)
    b = tf.shape(y_pred)[0]
    tl = tf.fill([b], tf.shape(y_pred)[1])
    return tf.reduce_mean(tf.nn.ctc_loss(
        labels=y_true, logits=y_pred, label_length=ll, logit_length=tl,
        logits_time_major=False, blank_index=0))


def greedy_decode(logits):
    idxs = np.argmax(logits, axis=-1)
    out, prev = [], -1
    for i in idxs:
        if i != prev and i != 0:
            out.append(int(i))
        prev = i
    return "".join(idx2char.get(i, "?") for i in out)


# ==========================================
# 한 조합 실행
# ==========================================
def run_config(cfg, fonts):
    print(f"\n{'=' * 60}")
    print(f"  {cfg['name']}  높이={cfg['height']}  채널={cfg['channels']}")
    print(f"  가로RF확대={cfg.get('wide_rf', False)}  dw커널={cfg.get('dw_kernel', 3)}")
    print(f"{'=' * 60}")

    random.seed(SEED); np.random.seed(SEED); tf.random.set_seed(SEED)

    imgs, lbls = make_dataset(fonts, cfg["height"])
    x = normalize(imgs)[..., np.newaxis]
    y = np.array([encode(t) for t in lbls])

    model = build_model(cfg["height"], cfg["channels"],
                        cfg.get("wide_rf", False), cfg.get("dw_kernel", 3))
    params = model.count_params()
    print(f"출력 시점 수 T = {model.output_shape[1]}  (라벨 최대 길이 {MAX_LABEL_LEN})")

    # 학습률을 단계적으로 낮춘다. CTC는 후반에 미세 구분을 배우므로 중요하다.
    sched = tf.keras.optimizers.schedules.CosineDecay(
        initial_learning_rate=2e-3,
        decay_steps=cfg["epochs"] * (NUM_SAMPLES // BATCH_SIZE),
        alpha=0.02,
    )
    model.compile(optimizer=tf.keras.optimizers.Adam(sched), loss=ctc_loss_fn)

    hist = model.fit(x, y, batch_size=BATCH_SIZE, epochs=cfg["epochs"], verbose=0)
    final_loss = hist.history["loss"][-1]

    preds = model.predict(x, verbose=0)

    n_all = n_dig = n_han = 0
    c_all = c_dig = c_han = 0
    wrong_han = []

    for i, lb in enumerate(lbls):
        ok = (greedy_decode(preds[i]) == lb)
        n_all += 1; c_all += ok
        if has_hangul(lb):
            n_han += 1; c_han += ok
            if not ok and len(wrong_han) < 8:
                wrong_han.append((lb, greedy_decode(preds[i])))
        else:
            n_dig += 1; c_dig += ok

    print(f"파라미터 {params:,}개   최종 손실 {final_loss:.4f}")
    print(f"  전체    정확도 {c_all / n_all:.3f}  ({c_all}/{n_all})")
    print(f"  숫자만  정확도 {c_dig / n_dig:.3f}  ({c_dig}/{n_dig})")
    print(f"  한글포함 정확도 {c_han / n_han:.3f}  ({c_han}/{n_han})")
    if wrong_han:
        print("  한글 오답 예시:")
        for a, b in wrong_han:
            print(f"    '{a}' -> '{b}'")

    return dict(name=cfg["name"], params=params, loss=final_loss,
                acc=c_all / n_all, acc_dig=c_dig / n_dig, acc_han=c_han / n_han)


def main():
    fonts = load_fonts()
    results = [run_config(c, fonts) for c in CONFIGS]

    print(f"\n{'=' * 60}")
    print("  요약")
    print(f"{'=' * 60}")
    print(f"{'조합':<14}{'파라미터':>10}{'손실':>9}{'전체':>8}{'숫자':>8}{'한글':>8}")
    for r in results:
        print(f"{r['name']:<14}{r['params']:>10,}{r['loss']:>9.3f}"
              f"{r['acc']:>8.3f}{r['acc_dig']:>8.3f}{r['acc_han']:>8.3f}")

    print("\n참고: 2차 sweep에서 E(h32+5x5)가 한글 0.377 / 손실 1.16 이었다.")
    print("\n해석:")
    print("  G가 크게 개선  -> 높이 48이 한글에 필요. 입력 크기를 48로 확정")
    print("  H가 크게 개선  -> 표현력 부족. 채널을 키운 채로 진행")
    print("  I가 크게 개선  -> 단순히 학습이 부족했던 것. 에폭을 늘려 본학습")
    print("  전부 0.5 미만  -> 구조 조정만으로는 한계.")
    print("     대안: (a) 폰트/렌더링 재점검  (b) 한글 클래스 노출 빈도 보정")
    print("           (c) API 후보 제약으로 오류를 흡수하는 설계로 전환")


if __name__ == "__main__":
    main()
