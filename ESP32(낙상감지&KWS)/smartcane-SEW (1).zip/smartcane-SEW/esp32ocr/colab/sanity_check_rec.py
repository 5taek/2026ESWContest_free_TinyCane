# ============================================================
# rec 학습 코드 정상 동작 확인 (과적합 테스트)
#
# 목적: "모델이 학습을 못 하는 게 코드 버그 때문인가, 데이터가 어려워서인가"를
#       가른다. 증강 없는 깨끗한 데이터 소량으로 일부러 과적합시켜본다.
#
# 판정:
#   손실이 1 아래로 떨어지고 정확도 90% 이상  -> 코드 정상. 데이터가 문제
#   손실이 안 떨어짐                          -> 코드 버그. CTC/라벨 인코딩 확인
#
# 3만 장을 다시 만들기 전에 이걸 먼저 돌린다.
# ============================================================

import os
import random
import numpy as np
import cv2
import tensorflow as tf
from PIL import Image, ImageDraw, ImageFont
import glob
import subprocess

REC_H, REC_W = 32, 160
MAX_LABEL_LEN = 6
NUM_SAMPLES = 2000
BATCH_SIZE = 64
EPOCHS = 30
SEED = 42

# ==========================================
# 글자셋 (train_rec.py 와 동일)
# ==========================================
DIGITS = list("0123456789")
HANGUL = list("직행급순환남구동북서성수달칠곡가창팔공")
SYMBOLS = ["-"]
CHARSET = DIGITS + HANGUL + SYMBOLS
NUM_CLASSES = len(CHARSET) + 1

char2idx = {c: i + 1 for i, c in enumerate(CHARSET)}
idx2char = {i + 1: c for i, c in enumerate(CHARSET)}
idx2char[0] = ""

ROUTES = [
    "503", "937", "410", "북구2", "급행1", "순환3", "156", "204",
    "달서1", "수성2", "칠곡3", "성서1", "동구5", "남구2", "팔공1", "가창2",
    "101-1", "급행8-1", "직행2", "서구2",
]


def encode(text):
    seq = [char2idx[c] for c in text if c in char2idx][:MAX_LABEL_LEN]
    return np.array(seq + [0] * (MAX_LABEL_LEN - len(seq)), dtype=np.int32)


def normalize(x):
    return (x.astype(np.float32) / 255.0 - 0.5) / 0.5


# ==========================================
# 깨끗한 합성 데이터 (증강 없음)
# ==========================================
def load_fonts():
    found = []
    try:
        out = subprocess.run(["fc-list", ":lang=ko", "--format=%{file}\\n"],
                             capture_output=True, text=True, timeout=30)
        found = [p for p in out.stdout.strip().split("\n") if p]
    except Exception:
        pass
    if not found:
        for d in ("/usr/share/fonts", "/usr/local/share/fonts"):
            for ext in ("ttf", "otf", "ttc"):
                found += glob.glob(os.path.join(d, "**", f"*.{ext}"), recursive=True)

    fonts = []
    for p in dict.fromkeys(found):
        try:
            f = ImageFont.truetype(p, 40)
            img = Image.new("L", (60, 60), 0)
            ImageDraw.Draw(img).text((5, 5), "북", font=f, fill=255)
            if np.array(img).sum() > 0:
                fonts.append(p)
        except Exception:
            pass
    if not fonts:
        raise FileNotFoundError("한글 폰트 없음. !apt-get install -y fonts-nanum")
    print(f"폰트 {len(fonts)}개")
    return fonts


def render_clean(text, font_path, font_size=64):
    """증강 없이 깨끗하게. 글자가 세로를 꽉 채우게."""
    font = ImageFont.truetype(font_path, font_size)
    boxes = [font.getbbox(c) for c in text]
    widths = [b[2] - b[0] for b in boxes]
    top = min(b[1] for b in boxes)
    bottom = max(b[3] for b in boxes)
    total_w, total_h = sum(widths), bottom - top

    m = max(2, int(total_h * 0.08))
    img = Image.new("L", (total_w + m * 2, total_h + m * 2), 40)
    draw = ImageDraw.Draw(img)
    x = m
    for i, c in enumerate(text):
        draw.text((x - boxes[i][0], m - top), c, font=font, fill=230)
        x += widths[i]

    a = np.array(img)
    h, w = a.shape
    nw = max(1, min(REC_W, int(round(w * REC_H / h))))
    r = cv2.resize(a, (nw, REC_H), interpolation=cv2.INTER_AREA)
    out = np.full((REC_H, REC_W), 127, dtype=np.uint8)
    out[:, :nw] = r
    return out


def make_dataset(fonts):
    imgs, lbls = [], []
    for i in range(NUM_SAMPLES):
        t = ROUTES[i % len(ROUTES)]
        imgs.append(render_clean(t, random.choice(fonts)))
        lbls.append(t)
    return np.array(imgs), lbls


# ==========================================
# 모델 (train_rec.py 와 동일)
# ==========================================
def build_model():
    inp = tf.keras.Input(shape=(REC_H, REC_W, 1))

    def dw(x, ch):
        x = tf.keras.layers.DepthwiseConv2D(3, padding="same", use_bias=False)(x)
        x = tf.keras.layers.BatchNormalization()(x)
        x = tf.keras.layers.ReLU()(x)
        x = tf.keras.layers.Conv2D(ch, 1, padding="same", use_bias=False)(x)
        x = tf.keras.layers.BatchNormalization()(x)
        x = tf.keras.layers.ReLU()(x)
        return x

    x = tf.keras.layers.Conv2D(16, 3, padding="same", use_bias=False)(inp)
    x = tf.keras.layers.BatchNormalization()(x)
    x = tf.keras.layers.ReLU()(x)
    x = tf.keras.layers.MaxPooling2D((2, 2))(x)
    x = dw(x, 32)
    x = tf.keras.layers.MaxPooling2D((2, 2))(x)
    x = dw(x, 64)
    x = tf.keras.layers.MaxPooling2D((2, 1))(x)
    x = dw(x, 96)
    x = tf.keras.layers.MaxPooling2D((2, 1))(x)
    x = tf.keras.layers.Conv2D(128, (2, 1), padding="valid", use_bias=False)(x)
    x = tf.keras.layers.BatchNormalization()(x)
    x = tf.keras.layers.ReLU()(x)
    x = tf.keras.layers.Conv2D(NUM_CLASSES, 1, padding="same")(x)
    out = tf.keras.layers.Reshape((-1, NUM_CLASSES))(x)
    return tf.keras.Model(inp, out)


def ctc_loss_fn(y_true, y_pred):
    y_true = tf.cast(y_true, tf.int32)
    label_length = tf.reduce_sum(tf.cast(y_true > 0, tf.int32), axis=-1)
    batch = tf.shape(y_pred)[0]
    logit_length = tf.fill([batch], tf.shape(y_pred)[1])
    return tf.reduce_mean(tf.nn.ctc_loss(
        labels=y_true, logits=y_pred,
        label_length=label_length, logit_length=logit_length,
        logits_time_major=False, blank_index=0))


def greedy_decode(logits):
    idxs = np.argmax(logits, axis=-1)
    out, prev = [], -1
    for i in idxs:
        if i != prev and i != 0:
            out.append(int(i))
        prev = i
    return "".join(idx2char.get(i, "?") for i in out)


# ==========================================
# 실행
# ==========================================
def main():
    random.seed(SEED); np.random.seed(SEED); tf.random.set_seed(SEED)

    fonts = load_fonts()
    imgs, lbls = make_dataset(fonts)
    print(f"깨끗한 합성 {len(imgs)}장, 라벨 {len(set(lbls))}종")

    # 눈으로 확인용
    os.makedirs("/content/sanity_preview", exist_ok=True)
    for i in range(10):
        cv2.imwrite(f"/content/sanity_preview/{i}_{lbls[i]}.png", imgs[i])
    print("미리보기: /content/sanity_preview  <- 읽히는지 꼭 확인할 것")

    x = normalize(imgs)[..., np.newaxis]
    y = np.array([encode(t) for t in lbls])

    # 라벨 인코딩이 맞는지 검증
    print("\n라벨 인코딩 확인:")
    for i in range(3):
        dec = "".join(idx2char[j] for j in y[i] if j > 0)
        print(f"  '{lbls[i]}' -> {y[i]} -> '{dec}'  {'OK' if dec == lbls[i] else '!! 불일치'}")

    model = build_model()
    model.compile(optimizer=tf.keras.optimizers.Adam(1e-3), loss=ctc_loss_fn)

    print("\n학습 시작 (증강 없음, 과적합 목표)")
    model.fit(x, y, batch_size=BATCH_SIZE, epochs=EPOCHS, verbose=1)

    preds = model.predict(x[:500], verbose=0)
    correct = sum(greedy_decode(preds[i]) == lbls[i] for i in range(500))
    acc = correct / 500

    print(f"\n===== 결과 =====")
    print(f"정확도 {acc:.3f} ({correct}/500)")
    for i in range(10):
        print(f"  '{lbls[i]}' -> '{greedy_decode(preds[i])}'")

    print()
    if acc > 0.9:
        print("판정: 코드 정상. 학습 파이프라인에 문제 없음.")
        print("      -> 원래 실패 원인은 합성 데이터의 증강이 과했던 것.")
        print("      -> gen_synthetic_rec.py 의 증강을 약화해 재생성할 것.")
    else:
        print("판정: 코드에 문제가 있음.")
        print("      -> CTC 설정, 라벨 인코딩, 모델 출력 형상을 확인할 것.")
        print("      -> 위 '라벨 인코딩 확인'과 미리보기 이미지부터 점검.")


if __name__ == "__main__":
    main()
