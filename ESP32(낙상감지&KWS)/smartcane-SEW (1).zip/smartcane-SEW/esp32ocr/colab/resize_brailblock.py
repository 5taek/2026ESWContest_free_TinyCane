"""
점자블록 원본 이미지 → 224×224 리사이즈
──────────────────────────────────────
원본 28.5GB → 약 200~300MB로 줄여 드라이브 업로드를 가능하게 한다.

컬러를 유지하는 이유: 라벨링을 노란색 마스킹으로 자동 생성할 예정이므로
색 정보가 필요하다. 학습 시점에 그레이스케일로 읽으면 된다.

사용:
    python resize_brailblock.py <입력폴더> <출력폴더>
"""

import os, sys, glob, time
from concurrent.futures import ProcessPoolExecutor
from PIL import Image

SIZE     = 224
QUALITY  = 92
TIME_LIMIT = float(os.environ.get("TIME_LIMIT", "0"))   # 초, 0이면 무제한

def process(args):
    src, dst = args
    try:
        with Image.open(src) as im:
            # draft: JPEG를 축소된 크기로 바로 디코딩 → 수 배 빠름
            im.draft("RGB", (SIZE, SIZE))
            im = im.convert("RGB").resize((SIZE, SIZE), Image.BILINEAR)
            im.save(dst, "JPEG", quality=QUALITY)
        return 1
    except Exception:
        return 0

def main(in_dir, out_dir):
    os.makedirs(out_dir, exist_ok=True)

    exts  = ("*.jpeg", "*.jpg", "*.png", "*.bmp", "*.JPEG", "*.JPG")
    paths = sorted(sum([glob.glob(os.path.join(in_dir, e)) for e in exts], []))
    print(f"입력 {len(paths)}장")

    jobs = []
    for p in paths:
        stem = os.path.splitext(os.path.basename(p))[0]
        out  = os.path.join(out_dir, stem + ".jpg")
        if not os.path.exists(out):
            jobs.append((p, out))
    print(f"처리 대상 {len(jobs)}장 (이미 처리됨 {len(paths)-len(jobs)}장)")

    done  = 0
    start = time.time()
    with ProcessPoolExecutor(max_workers=os.cpu_count()) as ex:
        futures = ex.map(process, jobs, chunksize=16)
        for i, r in enumerate(futures, 1):
            done += r
            if i % 500 == 0:
                print(f"  {i}/{len(jobs)}  ({time.time()-start:.0f}s)", flush=True)
            if TIME_LIMIT and time.time() - start > TIME_LIMIT:
                print(f"  시간 제한 도달, {i}장에서 중단", flush=True)
                ex.shutdown(wait=False, cancel_futures=True)
                break

    total = sum(os.path.getsize(os.path.join(out_dir, f))
                for f in os.listdir(out_dir))
    print(f"\n완료: {done}장 성공")
    print(f"출력 용량: {total/1024/1024:.1f} MB")

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print(__doc__)
        sys.exit(1)
    main(sys.argv[1], sys.argv[2])
