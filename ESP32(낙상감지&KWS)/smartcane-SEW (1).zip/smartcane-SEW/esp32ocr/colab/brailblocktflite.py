"""
점자블록 TFLite 추론 + NMS 평가
────────────────────────────────
- val 이미지 전체 추론
- NMS로 중복 박스 제거
- GT와 비교 → precision / recall 계산
- 결과 이미지 저장
"""

import os, glob, cv2, math
import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from pathlib import Path
from sklearn.cluster import KMeans

# ── 경로 ─────────────────────────────────────────────────────────────────────
TFLITE_PATH = "/content/drive/MyDrive/brailblock/model/brailblock_int8.tflite"
VAL_IMG     = "/content/brailblock/brailblock/images/val"
VAL_LBL     = "/content/brailblock/brailblock/labels/val"
TRAIN_LBL   = "/content/brailblock/brailblock/labels/train"
SAVE_DIR    = "/content/drive/MyDrive/brailblock/eval"
os.makedirs(SAVE_DIR, exist_ok=True)

IMG_SIZE    = 224
GRID        = 7
NUM_ANCHORS = 3
CONF_THRESH = 0.3
IOU_THRESH  = 0.45   # NMS IoU 임계값
IOU_GT      = 0.5    # GT 매칭 IoU 임계값

# ── 앵커 (학습과 동일하게) ────────────────────────────────────────────────────
def compute_anchors(lbl_dir, n=3):
    whs = []
    for f in glob.glob(f"{lbl_dir}/*.txt"):
        for line in open(f):
            p = line.strip().split()
            if len(p) == 5:
                whs.append([float(p[3]), float(p[4])])
    whs = np.array(whs, dtype=np.float32)
    km = KMeans(n_clusters=n, n_init=10, random_state=42).fit(whs)
    anchors = km.cluster_centers_
    return anchors[np.argsort(anchors[:,0]*anchors[:,1])].astype(np.float32)

ANCHORS = compute_anchors(TRAIN_LBL)
print(f"앵커:\n{ANCHORS}")

# ── TFLite 로드 ───────────────────────────────────────────────────────────────
interp = tf.lite.Interpreter(TFLITE_PATH)
interp.allocate_tensors()
inp_det = interp.get_input_details()[0]
out_det = interp.get_output_details()[0]
print(f"입력: {inp_det['shape']}  dtype={inp_det['dtype']}")

# ── 유틸 ─────────────────────────────────────────────────────────────────────
def sigmoid(x):
    return 1.0 / (1.0 + np.exp(-np.clip(x, -88, 88)))

def decode_output(raw):
    """raw: (7,7,3,6) → boxes list of [cx,cy,w,h,conf] 정규화 좌표"""
    boxes = []
    for gj in range(GRID):
        for gi in range(GRID):
            for a in range(NUM_ANCHORS):
                conf = sigmoid(raw[gj, gi, a, 4])
                if conf < CONF_THRESH:
                    continue
                tx = sigmoid(raw[gj, gi, a, 0])
                ty = sigmoid(raw[gj, gi, a, 1])
                tw = raw[gj, gi, a, 2]
                th = raw[gj, gi, a, 3]
                cx = (gi + tx) / GRID
                cy = (gj + ty) / GRID
                w  = ANCHORS[a, 0] * np.exp(np.clip(tw, -4, 4))
                h  = ANCHORS[a, 1] * np.exp(np.clip(th, -4, 4))
                boxes.append([cx, cy, w, h, conf])
    return np.array(boxes, dtype=np.float32) if boxes else np.zeros((0,5), dtype=np.float32)

def iou_box(b1, b2):
    """cx,cy,w,h 형식 두 박스의 IoU"""
    x1 = max(b1[0]-b1[2]/2, b2[0]-b2[2]/2)
    y1 = max(b1[1]-b1[3]/2, b2[1]-b2[3]/2)
    x2 = min(b1[0]+b1[2]/2, b2[0]+b2[2]/2)
    y2 = min(b1[1]+b1[3]/2, b2[1]+b2[3]/2)
    inter = max(0, x2-x1) * max(0, y2-y1)
    union = b1[2]*b1[3] + b2[2]*b2[3] - inter + 1e-7
    return inter / union

def nms(boxes, iou_thr=IOU_THRESH):
    """boxes: (N,5) cx cy w h conf → NMS 후 남은 박스"""
    if len(boxes) == 0:
        return boxes
    idx = np.argsort(boxes[:,4])[::-1]
    keep = []
    while len(idx) > 0:
        i = idx[0]
        keep.append(i)
        if len(idx) == 1:
            break
        ious = np.array([iou_box(boxes[i], boxes[j]) for j in idx[1:]])
        idx = idx[1:][ious < iou_thr]
    return boxes[keep]

def load_gt(lbl_path):
    boxes = []
    if os.path.exists(lbl_path):
        for line in open(lbl_path):
            p = line.strip().split()
            if len(p) == 5:
                boxes.append([float(p[1]), float(p[2]),
                               float(p[3]), float(p[4])])
    return np.array(boxes, dtype=np.float32) if boxes else np.zeros((0,4), dtype=np.float32)

# ── 추론 ─────────────────────────────────────────────────────────────────────
exts  = ("*.jpg", "*.jpeg", "*.png", "*.bmp")
paths = sorted(sum([glob.glob(f"{VAL_IMG}/{e}") for e in exts], []))
print(f"\nval 이미지: {len(paths)}장")

tp_total = fp_total = fn_total = 0
vis_saved = 0

for i, p in enumerate(paths):
    stem    = Path(p).stem
    lbl_p   = f"{VAL_LBL}/{stem}.txt"
    gt_boxes = load_gt(lbl_p)

    # 전처리
    img_bgr = cv2.imread(p)
    img_gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
    img_r    = cv2.resize(img_gray, (IMG_SIZE, IMG_SIZE))
    inp_arr  = img_r.astype(np.float32) / 255.0
    inp_arr  = inp_arr[np.newaxis, ..., np.newaxis]   # (1,224,224,1)

    # 추론
    interp.set_tensor(inp_det['index'], inp_arr)
    interp.invoke()
    raw = interp.get_tensor(out_det['index'])[0]      # (7,7,3,6)

    # 디코딩 + NMS
    boxes = decode_output(raw)
    boxes = nms(boxes)

    # TP / FP / FN 계산
    matched_gt = [False] * len(gt_boxes)
    tp = fp = 0
    for box in boxes:
        best_iou, best_j = 0, -1
        for j, gt in enumerate(gt_boxes):
            iou = iou_box(box[:4], gt)
            if iou > best_iou:
                best_iou, best_j = iou, j
        if best_iou >= IOU_GT and not matched_gt[best_j]:
            tp += 1
            matched_gt[best_j] = True
        else:
            fp += 1
    fn = matched_gt.count(False)

    tp_total += tp
    fp_total += fp
    fn_total += fn

    # 처음 50장 시각화 저장
    if vis_saved < 50:
        fig, ax = plt.subplots(1, 1, figsize=(5, 5))
        ax.imshow(img_r, cmap="gray")
        # GT (초록)
        for gt in gt_boxes:
            cx,cy,w,h = gt
            x1 = (cx-w/2)*IMG_SIZE; y1 = (cy-h/2)*IMG_SIZE
            ax.add_patch(patches.Rectangle(
                (x1,y1), w*IMG_SIZE, h*IMG_SIZE,
                linewidth=2, edgecolor='lime', facecolor='none'))
        # 예측 (파랑)
        for box in boxes:
            cx,cy,w,h,conf = box
            x1 = (cx-w/2)*IMG_SIZE; y1 = (cy-h/2)*IMG_SIZE
            ax.add_patch(patches.Rectangle(
                (x1,y1), w*IMG_SIZE, h*IMG_SIZE,
                linewidth=2, edgecolor='deepskyblue', facecolor='none'))
            ax.text(x1, y1-2, f"{conf:.2f}", color='deepskyblue', fontsize=7)
        ax.set_title(f"{stem}  TP={tp} FP={fp} FN={fn}")
        ax.axis('off')
        plt.tight_layout()
        plt.savefig(f"{SAVE_DIR}/vis_{vis_saved:03d}_{stem}.jpg",
                    dpi=80, bbox_inches='tight')
        plt.close()
        vis_saved += 1

    if (i+1) % 200 == 0:
        print(f"  {i+1}/{len(paths)}")

# ── 최종 메트릭 ───────────────────────────────────────────────────────────────
precision = tp_total / (tp_total + fp_total + 1e-7)
recall    = tp_total / (tp_total + fn_total + 1e-7)
f1        = 2 * precision * recall / (precision + recall + 1e-7)

print(f"\n=== 최종 결과 (IoU≥{IOU_GT}, conf≥{CONF_THRESH}) ===")
print(f"TP={tp_total}  FP={fp_total}  FN={fn_total}")
print(f"Precision : {precision:.4f}")
print(f"Recall    : {recall:.4f}")
print(f"F1        : {f1:.4f}")
print(f"\n시각화 {vis_saved}장 저장: {SAVE_DIR}")
