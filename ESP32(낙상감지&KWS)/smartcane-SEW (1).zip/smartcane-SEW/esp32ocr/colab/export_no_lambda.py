"""
전처리 Lambda를 뺀 TFLite 재변환
────────────────────────────────
학습 때 그레이→RGB 변환을 Keras Lambda로 모델 안에 넣었더니
TFLite에 TILE 연산이 생겼고, esp-tflite-micro에는 TILE이 없어
ESP32에서 AllocateTensors가 실패한다.

재학습은 필요 없다. Lambda는 가중치가 없으므로
입력을 (224,224,3)으로 바꾼 같은 구조를 만들고 가중치만 얹어
TFLite만 다시 뽑으면 된다.

전처리는 ESP32의 C 코드가 대신한다:
    원래  (gray/255)*255/127.5 - 1  →  gray/127.5 - 1
    세 채널 모두 같은 값을 넣는다.

Colab 셀에 그대로 붙여넣고 CONFIG만 고치면 된다.
"""

import numpy as np
import tensorflow as tf

# ══ CONFIG ═══════════════════════════════════════════════════════════════════
SRC_KERAS = "/content/drive/MyDrive/brailblock/model3/best.keras"
OUT_TFLITE = "/content/drive/MyDrive/brailblock/model3/brailblock_nolambda_int8.tflite"

VAL_IMG   = "/content/brailblock/brailblock/images/val"   # calibration용
IMG_SIZE  = 224
N_CALIB   = 200
# ═════════════════════════════════════════════════════════════════════════════

def build_backbone(weights=None):
    return tf.keras.applications.MobileNetV2(
        alpha=0.35, include_top=False,
        input_shape=(IMG_SIZE, IMG_SIZE, 3), weights=weights
    )

def build_head(x):
    """학습 때와 동일한 헤드"""
    x = tf.keras.layers.Conv2D(32, 1, activation="relu")(x)
    x = tf.keras.layers.Flatten()(x)
    x = tf.keras.layers.Dropout(0.3)(x)
    x = tf.keras.layers.Dense(128, activation="relu")(x)
    x = tf.keras.layers.Dropout(0.2)(x)
    return tf.keras.layers.Dense(5, activation="sigmoid", name="box")(x)

# ── 1. 학습 때와 같은 구조(Lambda 포함)로 가중치를 읽는다 ────────────────────
def build_with_lambda():
    inp = tf.keras.Input((IMG_SIZE, IMG_SIZE, 1), name="image")
    x = tf.keras.layers.Lambda(
        lambda t: tf.keras.applications.mobilenet_v2.preprocess_input(
            tf.repeat(t * 255.0, 3, axis=-1)
        ),
        output_shape=(IMG_SIZE, IMG_SIZE, 3),
        name="gray_to_rgb"
    )(inp)
    bb = build_backbone(None)
    x  = bb(x, training=True)
    out = build_head(x)
    m = tf.keras.Model(inp, out)
    m._backbone = bb
    return m

print(f"가중치 로드: {SRC_KERAS}")
src = build_with_lambda()
src.load_weights(SRC_KERAS)
print("로드 완료")

# ── 2. Lambda 없는 구조를 만들고 가중치를 옮긴다 ─────────────────────────────
def build_without_lambda():
    inp = tf.keras.Input((IMG_SIZE, IMG_SIZE, 3), name="image")   # 이미 전처리된 입력
    bb  = build_backbone(None)
    x   = bb(inp, training=False)
    out = build_head(x)
    m = tf.keras.Model(inp, out)
    m._backbone = bb
    return m

dst = build_without_lambda()

# 백본
dst._backbone.set_weights(src._backbone.get_weights())

# 헤드 (Dropout/Flatten은 가중치가 없어 자동으로 건너뛴다)
src_head = [l for l in src.layers  if l.get_weights()
            and l is not src._backbone]
dst_head = [l for l in dst.layers  if l.get_weights()
            and l is not dst._backbone]
assert len(src_head) == len(dst_head), \
    f"헤드 레이어 수 불일치 {len(src_head)} vs {len(dst_head)}"
for a, b in zip(src_head, dst_head):
    b.set_weights(a.get_weights())
print(f"헤드 레이어 {len(dst_head)}개 이전 완료")

# ── 3. 두 모델의 출력이 같은지 확인 ──────────────────────────────────────────
probe_gray = np.random.rand(2, IMG_SIZE, IMG_SIZE, 1).astype(np.float32)
probe_rgb  = np.repeat(probe_gray * 255.0, 3, axis=-1) / 127.5 - 1.0

o1 = src.predict(probe_gray, verbose=0)
o2 = dst.predict(probe_rgb,  verbose=0)
diff = np.abs(o1 - o2).max()
print(f"출력 최대 차이: {diff:.6f}   {'OK' if diff < 1e-4 else '⚠️ 불일치'}")

# ── 4. TFLite INT8 변환 ──────────────────────────────────────────────────────
import glob, cv2

def calib_gen():
    exts  = ("*.jpg", "*.jpeg", "*.png", "*.bmp")
    paths = sorted(sum([glob.glob(f"{VAL_IMG}/{e}") for e in exts], []))[:N_CALIB]
    print(f"calibration 이미지 {len(paths)}장")
    for p in paths:
        img = cv2.imread(p, cv2.IMREAD_GRAYSCALE)
        if img is None:
            continue
        img = cv2.resize(img, (IMG_SIZE, IMG_SIZE)).astype(np.float32)
        # ESP32 C 코드와 동일한 전처리
        x = img / 127.5 - 1.0
        x = np.repeat(x[..., np.newaxis], 3, axis=-1)
        yield [x[np.newaxis, ...].astype(np.float32)]

conv = tf.lite.TFLiteConverter.from_keras_model(dst)
conv.optimizations = [tf.lite.Optimize.DEFAULT]
conv.representative_dataset  = calib_gen
conv.target_spec.supported_ops = [tf.lite.OpsSet.TFLITE_BUILTINS_INT8]
conv.inference_input_type  = tf.float32
conv.inference_output_type = tf.float32

tfl = conv.convert()
with open(OUT_TFLITE, "wb") as f:
    f.write(tfl)
print(f"\n저장: {OUT_TFLITE}  ({len(tfl)/1024:.1f} KB)")

# ── 5. 사용된 연산 확인 ──────────────────────────────────────────────────────
interp = tf.lite.Interpreter(model_content=tfl)
interp.allocate_tensors()
ops = sorted({d["op_name"] for d in interp._get_ops_details()})
print(f"\n사용 연산 ({len(ops)}종): {', '.join(ops)}")
if "TILE" in ops:
    print("⚠️ TILE이 아직 남아있음")
else:
    print("TILE 없음 — ESP32에서 동작 가능")
