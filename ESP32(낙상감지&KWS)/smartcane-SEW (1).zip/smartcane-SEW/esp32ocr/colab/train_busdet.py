"""
버스 번호판 검출 — 브레일블록 백본 전이학습 + 5-fold 교차검증
──────────────────────────────────────────────────────────────
데이터가 144장뿐이라 val 한 번으로는 성능을 못 믿는다(어떤 22장이 뽑히냐로
IoU가 크게 흔들림). 5-fold로 144장 전부를 한 번씩 검증에 써서 평균을 낸다.

백본은 브레일블록 학습 결과(best.keras)에서 가져온다.
헤드는 새로 만들어 버스 번호판 박스 하나를 회귀한다.

Colab 셀에 그대로 붙여넣고 CONFIG만 고치면 된다.
"""

import os, glob, math, random, shutil
import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt
from pathlib import Path

# ══ CONFIG ═══════════════════════════════════════════════════════════════════
DATA_DIR      = "/content/drive/MyDrive/busnum/train"   # images/ labels/ 있는 곳
BRAIL_MODEL   = "/content/drive/MyDrive/brailblock/model3/best.keras"
SAVE_DIR      = "/content/drive/MyDrive/busnum/model"

IMG_SIZE   = 224
BATCH_SIZE = 16
EPOCHS     = 80
LR_INIT    = 1e-4
N_FOLDS    = 5
SEED       = 42
IOU_THRESH = 0.5
# ═════════════════════════════════════════════════════════════════════════════

os.makedirs(SAVE_DIR, exist_ok=True)
IMG_DIR = os.path.join(DATA_DIR, "images")
LBL_DIR = os.path.join(DATA_DIR, "labels")

# ── 1. 데이터 로드 ────────────────────────────────────────────────────────────
def list_pairs():
    exts  = ("*.jpg", "*.jpeg", "*.png", "*.bmp")
    paths = sorted(sum([glob.glob(os.path.join(IMG_DIR, e)) for e in exts], []))
    pairs = []
    for p in paths:
        lbl = os.path.join(LBL_DIR, Path(p).stem + ".txt")
        if os.path.exists(lbl):
            pairs.append((p, lbl))
    return pairs

PAIRS = list_pairs()
print(f"이미지+라벨 쌍: {len(PAIRS)}개")
if not PAIRS:
    raise RuntimeError(f"데이터를 못 찾음. 경로 확인: {IMG_DIR}")

def load_sample(img_path, lbl_path, augment=False):
    """반환: img (H,W,1) float32, target (5,) = [cx, cy, w, h, has_obj]"""
    import cv2
    img = cv2.imread(str(img_path), cv2.IMREAD_GRAYSCALE)
    if img is None:
        img = np.zeros((IMG_SIZE, IMG_SIZE), np.uint8)
    img = cv2.resize(img, (IMG_SIZE, IMG_SIZE))

    boxes = []
    for line in open(lbl_path):
        p = line.strip().split()
        if len(p) == 5:
            boxes.append([float(v) for v in p[1:]])

    # 여러 개면 면적이 가장 큰 것 하나 (가장 가까운 버스)
    if boxes:
        boxes.sort(key=lambda b: b[2] * b[3], reverse=True)
        box, has_obj = boxes[0], 1.0
    else:
        box, has_obj = [0.0, 0.0, 0.0, 0.0], 0.0

    if augment:
        # 좌우 반전
        if random.random() < 0.5:
            img = cv2.flip(img, 1)
            if has_obj:
                box = [1.0 - box[0], box[1], box[2], box[3]]
        # 밝기·대비 (야외 조명 변화)
        img = np.clip(img.astype(np.float32) * random.uniform(0.7, 1.3)
                      + random.uniform(-30, 30), 0, 255).astype(np.uint8)
        # 노이즈
        if random.random() < 0.4:
            img = np.clip(img.astype(np.float32)
                          + np.random.randn(*img.shape) * 8, 0, 255).astype(np.uint8)
        # 흐림 (움직이는 버스)
        if random.random() < 0.25:
            k = random.choice([3, 5])
            img = cv2.GaussianBlur(img, (k, k), 0)
        # 이동 (데이터가 적어 위치 다양성을 늘린다)
        if has_obj and random.random() < 0.5:
            dx = random.uniform(-0.08, 0.08)
            dy = random.uniform(-0.08, 0.08)
            M  = np.float32([[1, 0, dx * IMG_SIZE], [0, 1, dy * IMG_SIZE]])
            img = cv2.warpAffine(img, M, (IMG_SIZE, IMG_SIZE),
                                 borderMode=cv2.BORDER_REPLICATE)
            box = [np.clip(box[0] + dx, 0, 1), np.clip(box[1] + dy, 0, 1),
                   box[2], box[3]]

    img_f  = img.astype(np.float32)[..., np.newaxis] / 255.0
    target = np.array(box + [has_obj], np.float32)
    return img_f, target

def make_ds(pairs, augment, shuffle):
    def gen():
        idxs = list(range(len(pairs)))
        if shuffle: random.shuffle(idxs)
        for i in idxs:
            yield load_sample(pairs[i][0], pairs[i][1], augment)

    ds = tf.data.Dataset.from_generator(
        gen,
        output_signature=(
            tf.TensorSpec((IMG_SIZE, IMG_SIZE, 1), tf.float32),
            tf.TensorSpec((5,), tf.float32),
        )
    )
    if shuffle: ds = ds.shuffle(200)
    return ds.batch(BATCH_SIZE).repeat().prefetch(tf.data.AUTOTUNE)

# ── 2. 손실 · 메트릭 ──────────────────────────────────────────────────────────
def box_loss(y_true, y_pred):
    has_obj = y_true[:, 4:5]
    coord_err = tf.reduce_sum(
        tf.square(y_true[:, :4] - y_pred[:, :4]), axis=-1, keepdims=True)
    coord_loss = tf.reduce_sum(has_obj * coord_err) / (tf.reduce_sum(has_obj) + 1e-7)
    conf_loss  = tf.reduce_mean(
        tf.keras.losses.binary_crossentropy(y_true[:, 4:5], y_pred[:, 4:5]))
    return 5.0 * coord_loss + 1.0 * conf_loss

def _iou(y_true, y_pred):
    t, p = y_true[:, :4], y_pred[:, :4]
    t_x1, t_y1 = t[:, 0] - t[:, 2]/2, t[:, 1] - t[:, 3]/2
    t_x2, t_y2 = t[:, 0] + t[:, 2]/2, t[:, 1] + t[:, 3]/2
    p_x1, p_y1 = p[:, 0] - p[:, 2]/2, p[:, 1] - p[:, 3]/2
    p_x2, p_y2 = p[:, 0] + p[:, 2]/2, p[:, 1] + p[:, 3]/2
    iw = tf.maximum(0.0, tf.minimum(t_x2, p_x2) - tf.maximum(t_x1, p_x1))
    ih = tf.maximum(0.0, tf.minimum(t_y2, p_y2) - tf.maximum(t_y1, p_y1))
    inter = iw * ih
    union = t[:, 2]*t[:, 3] + p[:, 2]*p[:, 3] - inter + 1e-7
    return inter / union

class MeanIoU(tf.keras.metrics.Metric):
    def __init__(self, **kw):
        super().__init__(**kw)
        self.total = self.add_weight(name="total", shape=(), initializer="zeros")
        self.count = self.add_weight(name="count", shape=(), initializer="zeros")
    def update_state(self, y_true, y_pred, sample_weight=None):
        has_obj = y_true[:, 4]
        self.total.assign_add(tf.reduce_sum(_iou(y_true, y_pred) * has_obj))
        self.count.assign_add(tf.reduce_sum(has_obj))
    def result(self):
        return self.total / (self.count + 1e-7)
    def reset_state(self):
        self.total.assign(0.0); self.count.assign(0.0)

class IoUAccuracy(tf.keras.metrics.Metric):
    def __init__(self, thresh=IOU_THRESH, **kw):
        super().__init__(**kw)
        self.thresh = thresh
        self.hit   = self.add_weight(name="hit",   shape=(), initializer="zeros")
        self.count = self.add_weight(name="count", shape=(), initializer="zeros")
    def update_state(self, y_true, y_pred, sample_weight=None):
        has_obj = y_true[:, 4]
        iou = _iou(y_true, y_pred)
        self.hit.assign_add(
            tf.reduce_sum(tf.cast(iou >= self.thresh, tf.float32) * has_obj))
        self.count.assign_add(tf.reduce_sum(has_obj))
    def result(self):
        return self.hit / (self.count + 1e-7)
    def reset_state(self):
        self.hit.assign(0.0); self.count.assign(0.0)

# ── 3. 모델 (브레일블록 백본 전이) ────────────────────────────────────────────
def gray_to_rgb_layer():
    """그레이스케일 → 3채널 + MobileNetV2 전처리 ([0,1] → [-1,1])
       output_shape를 명시해야 저장·로드 시 shape 추론 오류가 없다."""
    return tf.keras.layers.Lambda(
        lambda t: tf.keras.applications.mobilenet_v2.preprocess_input(
            tf.repeat(t * 255.0, 3, axis=-1)
        ),
        output_shape=(IMG_SIZE, IMG_SIZE, 3),
        name="gray_to_rgb"
    )

def build_backbone(weights=None):
    return tf.keras.applications.MobileNetV2(
        alpha=0.35, include_top=False,
        input_shape=(IMG_SIZE, IMG_SIZE, 3), weights=weights
    )

def build_brail_arch():
    """브레일블록 학습 때와 동일한 구조를 코드로 재현한다.
       Lambda 레이어 때문에 load_model이 실패하므로,
       구조를 만들고 가중치만 얹는다."""
    inp = tf.keras.Input((IMG_SIZE, IMG_SIZE, 1), name="image")
    x   = gray_to_rgb_layer()(inp)
    bb  = build_backbone(None)
    x   = bb(x, training=True)
    x   = tf.keras.layers.Conv2D(32, 1, activation="relu")(x)
    x   = tf.keras.layers.Flatten()(x)
    x   = tf.keras.layers.Dropout(0.3)(x)
    x   = tf.keras.layers.Dense(128, activation="relu")(x)
    x   = tf.keras.layers.Dropout(0.2)(x)
    out = tf.keras.layers.Dense(5, activation="sigmoid", name="box")(x)
    m = tf.keras.Model(inp, out, name="brailblock_reg")
    m._backbone = bb
    return m

print(f"\n브레일블록 백본 가중치 로드: {BRAIL_MODEL}")
_brail = build_brail_arch()
_brail.load_weights(BRAIL_MODEL)
BRAIL_WEIGHTS = _brail._backbone.get_weights()
print(f"백본 로드 완료 ({_brail._backbone.count_params():,} 파라미터)")
del _brail
tf.keras.backend.clear_session()

def build_model():
    inp = tf.keras.Input((IMG_SIZE, IMG_SIZE, 1), name="image")
    x   = gray_to_rgb_layer()(inp)

    backbone = build_backbone(None)
    backbone.set_weights(BRAIL_WEIGHTS)   # 브레일블록에서 배운 가중치로 시작
    backbone.trainable = True
    x = backbone(x, training=True)        # (B, 7, 7, 112)

    # 헤드는 새로 (GAP은 위치 정보를 없애므로 쓰지 않는다)
    x = tf.keras.layers.Conv2D(32, 1, activation="relu")(x)
    x = tf.keras.layers.Flatten()(x)
    x = tf.keras.layers.Dropout(0.4)(x)   # 144장이라 강하게
    x = tf.keras.layers.Dense(128, activation="relu")(x)
    x = tf.keras.layers.Dropout(0.3)(x)
    out = tf.keras.layers.Dense(5, activation="sigmoid", name="box")(x)

    m = tf.keras.Model(inp, out, name="busdet")
    m._backbone = backbone
    return m

# ── 4. 5-fold 교차검증 ────────────────────────────────────────────────────────
random.seed(SEED)
order = list(range(len(PAIRS)))
random.shuffle(order)
folds = [order[i::N_FOLDS] for i in range(N_FOLDS)]

results = []
for k in range(N_FOLDS):
    val_idx   = folds[k]
    train_idx = [i for j in range(N_FOLDS) if j != k for i in folds[j]]
    tr = [PAIRS[i] for i in train_idx]
    va = [PAIRS[i] for i in val_idx]

    print(f"\n{'='*60}\nFold {k+1}/{N_FOLDS}   train {len(tr)}장 / val {len(va)}장\n{'='*60}")

    tf.keras.backend.clear_session()
    model = build_model()
    model.compile(
        optimizer=tf.keras.optimizers.Adam(LR_INIT, clipnorm=1.0),
        loss=box_loss,
        metrics=[MeanIoU(name="iou"), IoUAccuracy(name="acc50")]
    )

    hist = model.fit(
        make_ds(tr, augment=True,  shuffle=True),
        validation_data=make_ds(va, augment=False, shuffle=False),
        epochs=EPOCHS,
        steps_per_epoch=max(1, math.ceil(len(tr) / BATCH_SIZE)),
        validation_steps=max(1, math.ceil(len(va) / BATCH_SIZE)),
        callbacks=[
            tf.keras.callbacks.EarlyStopping(
                monitor="val_iou", mode="max", patience=20,
                restore_best_weights=True, verbose=1),
            tf.keras.callbacks.ReduceLROnPlateau(
                monitor="val_loss", factor=0.5, patience=8, min_lr=1e-6),
        ],
        verbose=2,
    )

    best_iou = max(hist.history["val_iou"])
    best_acc = max(hist.history["val_acc50"])
    results.append((best_iou, best_acc))
    print(f"Fold {k+1} → val IoU {best_iou:.4f}  acc50 {best_acc:.4f}")

ious = [r[0] for r in results]
accs = [r[1] for r in results]
print(f"\n{'='*60}")
print(f"5-fold 평균  IoU {np.mean(ious):.4f} ± {np.std(ious):.4f}")
print(f"5-fold 평균  acc50 {np.mean(accs):.4f} ± {np.std(accs):.4f}")
print(f"{'='*60}")

# ── 5. 전체 데이터로 최종 모델 ────────────────────────────────────────────────
print("\n전체 144장으로 최종 모델 학습")
tf.keras.backend.clear_session()
final = build_model()
final.compile(
    optimizer=tf.keras.optimizers.Adam(LR_INIT, clipnorm=1.0),
    loss=box_loss,
    metrics=[MeanIoU(name="iou"), IoUAccuracy(name="acc50")]
)
final.fit(
    make_ds(PAIRS, augment=True, shuffle=True),
    epochs=EPOCHS,
    steps_per_epoch=max(1, math.ceil(len(PAIRS) / BATCH_SIZE)),
    verbose=2,
)
final.save(f"{SAVE_DIR}/busdet.keras")
print(f"저장: {SAVE_DIR}/busdet.keras")

# ── 6. 예측 시각화 ────────────────────────────────────────────────────────────
import cv2
def show_predictions(model, pairs, n=8):
    picked = random.sample(pairs, min(n, len(pairs)))
    imgs, tgts = [], []
    for p, l in picked:
        a, b = load_sample(p, l, augment=False)
        imgs.append(a); tgts.append(b)
    imgs = np.stack(imgs); tgts = np.stack(tgts)
    preds = model.predict(imgs, verbose=0)

    cols = 4; rows = (len(picked) + cols - 1) // cols
    fig, axes = plt.subplots(rows, cols, figsize=(cols*3, rows*3))
    for i, ax in enumerate(np.array(axes).flatten()):
        if i >= len(picked):
            ax.axis("off"); continue
        vis = cv2.cvtColor((imgs[i, ..., 0]*255).astype(np.uint8), cv2.COLOR_GRAY2RGB)
        for box, col in ((tgts[i], (0, 255, 0)), (preds[i], (0, 120, 255))):
            cx, cy, w, h = box[:4]
            if w <= 0 or h <= 0: continue
            x1, y1 = int((cx-w/2)*IMG_SIZE), int((cy-h/2)*IMG_SIZE)
            x2, y2 = int((cx+w/2)*IMG_SIZE), int((cy+h/2)*IMG_SIZE)
            cv2.rectangle(vis, (x1, y1), (x2, y2), col, 2)
        ax.imshow(vis)
        ax.set_title(f"conf={preds[i][4]:.2f}", fontsize=8)
        ax.axis("off")
    plt.suptitle("green=GT  blue=pred")
    plt.tight_layout(); plt.show()

show_predictions(final, PAIRS)

# ── 7. TFLite INT8 변환 ───────────────────────────────────────────────────────
print("\n=== TFLite INT8 변환 ===")
converter = tf.lite.TFLiteConverter.from_keras_model(final)
converter.optimizations = [tf.lite.Optimize.DEFAULT]

def representative_dataset():
    for p, l in PAIRS[:100]:
        img, _ = load_sample(p, l, augment=False)
        yield [img[np.newaxis, ...]]

converter.representative_dataset  = representative_dataset
converter.target_spec.supported_ops = [tf.lite.OpsSet.TFLITE_BUILTINS_INT8]
converter.inference_input_type  = tf.float32
converter.inference_output_type = tf.float32

tflite_model = converter.convert()
with open(f"{SAVE_DIR}/busdet_int8.tflite", "wb") as f:
    f.write(tflite_model)
print(f"저장: {SAVE_DIR}/busdet_int8.tflite  ({len(tflite_model)/1024:.1f} KB)")
