"""
노란색 마스킹으로 점자블록 라벨 자동 생성
────────────────────────────────────────
AI-Hub 원본 라벨은 기준이 사진마다 달라 (어떤 건 블록 한 장, 어떤 건 여러 장,
어떤 건 화면 일부만) 모델이 학습할 일관된 규칙이 없었다.
"보이는 노란 영역 전부"라는 단일 기준을 코드로 고정해 전체에 동일 적용한다.

전략:
  HSV 노란색 마스크 → 모폴로지 정리 → 작은 덩어리 제거
  → 남은 영역 전체를 감싸는 박스 하나 → YOLO 형식 저장
  → 노란색이 없으면 라벨 파일 없음 (객체 없음)

사용:
  검증 (30장 시각화):
    python autolabel_yellow.py <이미지폴더> --preview <출력png폴더> [--n 30]
  전체 실행:
    python autolabel_yellow.py <이미지폴더> --out <라벨폴더>
"""

import os, sys, glob, argparse, random
import numpy as np
import cv2

# ── 노란색 검출 파라미터 ─────────────────────────────────────────────────────
# 고정 HSV 임계값은 실패한다. 이 데이터셋은 선명한 노랑부터 거의 크림색까지
# 편차가 커서 (LAB b채널 최대값이 사진마다 141~195) 한 값으로 못 자른다.
# → 사진마다 Otsu로 임계값을 자동 결정해 "그 사진 안에서 상대적으로 노란 곳"을 찾는다.

B_FLOOR      = 130   # Otsu 임계값이 이보다 낮으면 노란 것이 없다고 판단
MIN_SEP      = 6     # 전경/배경 b 평균 차이가 이보다 작으면 노랑 없음
MIN_AREA_RATIO  = 0.005   # 전체 대비 이 비율 미만 덩어리는 노이즈로 제거
MIN_TOTAL_RATIO = 0.01    # 노란 영역 총합이 이보다 작으면 "객체 없음"

def yellow_mask(bgr):
    """LAB b채널(파랑↔노랑 축) + 사진별 Otsu 임계값"""
    lab = cv2.cvtColor(bgr, cv2.COLOR_BGR2LAB)
    b   = lab[:, :, 2]

    thr, mask = cv2.threshold(b, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

    # 노란 것이 아예 없는 사진에서도 Otsu는 억지로 둘로 가른다. 아래로 걸러낸다.
    if thr < B_FLOOR:
        return np.zeros_like(mask)
    fg, bg = b[mask > 0], b[mask == 0]
    if fg.size == 0 or bg.size == 0 or (fg.mean() - bg.mean()) < MIN_SEP:
        return np.zeros_like(mask)

    # 열림: 점 노이즈 제거 → 닫힘: 블록 사이 틈·색 바랜 구멍 메우기
    k3 = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
    k7 = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (7, 7))
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN,  k3, iterations=1)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, k7, iterations=2)
    return mask

def mask_to_box(mask):
    """유효한 노란 덩어리 전체를 감싸는 박스 하나 반환.
       반환: (cx, cy, w, h) 정규화 좌표, 없으면 None"""
    H, W = mask.shape
    total_px = H * W

    n, labels, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)

    keep = []
    for i in range(1, n):                       # 0은 배경
        area = stats[i, cv2.CC_STAT_AREA]
        if area / total_px >= MIN_AREA_RATIO:
            keep.append(stats[i])

    if not keep:
        return None
    if sum(s[cv2.CC_STAT_AREA] for s in keep) / total_px < MIN_TOTAL_RATIO:
        return None

    x1 = min(s[cv2.CC_STAT_LEFT] for s in keep)
    y1 = min(s[cv2.CC_STAT_TOP]  for s in keep)
    x2 = max(s[cv2.CC_STAT_LEFT] + s[cv2.CC_STAT_WIDTH]  for s in keep)
    y2 = max(s[cv2.CC_STAT_TOP]  + s[cv2.CC_STAT_HEIGHT] for s in keep)

    cx = (x1 + x2) / 2 / W
    cy = (y1 + y2) / 2 / H
    w  = (x2 - x1) / W
    h  = (y2 - y1) / H
    return (cx, cy, w, h)

def list_images(img_dir):
    exts = ("*.jpg", "*.jpeg", "*.png", "*.bmp", "*.JPG", "*.JPEG")
    return sorted(sum([glob.glob(os.path.join(img_dir, e)) for e in exts], []))

# ── 검증 모드: 원본 / 마스크 / 박스를 나란히 저장 ────────────────────────────
def preview(img_dir, out_dir, n=30, seed=0):
    os.makedirs(out_dir, exist_ok=True)
    paths = list_images(img_dir)
    random.seed(seed)
    picked = random.sample(paths, min(n, len(paths)))

    hit = 0
    for idx, p in enumerate(picked):
        bgr = cv2.imread(p, cv2.IMREAD_COLOR)
        if bgr is None:
            continue
        mask = yellow_mask(bgr)
        box  = mask_to_box(mask)

        vis = bgr.copy()
        # 마스크 영역을 초록으로 반투명 오버레이
        overlay = vis.copy()
        overlay[mask > 0] = (0, 255, 0)
        vis = cv2.addWeighted(overlay, 0.35, vis, 0.65, 0)

        if box:
            hit += 1
            H, W = bgr.shape[:2]
            cx, cy, w, h = box
            x1, y1 = int((cx - w/2) * W), int((cy - h/2) * H)
            x2, y2 = int((cx + w/2) * W), int((cy + h/2) * H)
            cv2.rectangle(vis, (x1, y1), (x2, y2), (0, 0, 255), 2)

        mask_bgr = cv2.cvtColor(mask, cv2.COLOR_GRAY2BGR)
        panel = np.hstack([bgr, mask_bgr, vis])
        cv2.imwrite(os.path.join(out_dir, f"chk_{idx:03d}.jpg"), panel)

    print(f"검증 {len(picked)}장 저장: {out_dir}")
    print(f"박스 생성 {hit}장 / 미검출 {len(picked)-hit}장")

# ── 전체 실행: YOLO 라벨 저장 ────────────────────────────────────────────────
def run(img_dir, lbl_dir, time_limit=0):
    import time
    os.makedirs(lbl_dir, exist_ok=True)
    paths = list_images(img_dir)
    start = time.time()

    hit = miss = skip = 0
    for i, p in enumerate(paths, 1):
        stem = os.path.splitext(os.path.basename(p))[0]
        out  = os.path.join(lbl_dir, stem + ".txt")
        done = os.path.join(lbl_dir, stem + ".none")
        if os.path.exists(out) or os.path.exists(done):
            skip += 1
            continue

        bgr = cv2.imread(p, cv2.IMREAD_COLOR)
        if bgr is None:
            continue
        box = mask_to_box(yellow_mask(bgr))

        if box:
            cx, cy, w, h = box
            with open(out, "w") as f:
                f.write(f"0 {cx:.6f} {cy:.6f} {w:.6f} {h:.6f}\n")
            hit += 1
        else:
            open(done, "w").close()      # 처리 완료 표시 (객체 없음)
            miss += 1

        if i % 1000 == 0:
            print(f"  {i}/{len(paths)}  ({time.time()-start:.0f}s)", flush=True)
        if time_limit and time.time() - start > time_limit:
            print(f"  시간 제한 도달, {i}장에서 중단", flush=True)
            break

    print(f"\n라벨 생성 {hit}장 / 객체없음 {miss}장 / 건너뜀 {skip}장")

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("img_dir")
    ap.add_argument("--preview")
    ap.add_argument("--out")
    ap.add_argument("--n", type=int, default=30)
    ap.add_argument("--time-limit", type=float, default=0)
    a = ap.parse_args()

    if a.preview:
        preview(a.img_dir, a.preview, a.n)
    elif a.out:
        run(a.img_dir, a.out, a.time_limit)
    else:
        print(__doc__)
