# det 최적화 계획

ESP32-S3에서 돌아가는 새 검출 모델 설계 계획.
현재 병목 분석 → 아키텍처 설계 → 학습 전략 순서로 기록한다.

---

## 1. 현재 병목 (paddle_det_full_int8.tflite)

측정 환경: ESP32-S3, 240MHz, PSRAM 80MHz, 입력 640×480 → 224×224

```
op                          횟수   시간(ms)   비율
TRANSPOSE_CONV                 2    6769.9   73.7%   ← 주범
CONV_2D                       57     956.2   10.4%
DEPTHWISE_CONV_2D             15     399.9    4.4%
MEAN                           8     362.7    3.9%
MUL                            8     212.8    2.3%
ADD                           21     207.1    2.3%
PAD                            5     104.9    1.1%
QUANTIZE                       1      70.8    0.8%
HARD_SWISH                    20      45.8    0.5%
DEQUANTIZE                     1      21.9    0.2%
RESIZE_NEAREST_NEIGHBOR        6      20.5    0.2%
CONCATENATION                  1      13.9    0.2%
LOGISTIC                       1       5.2    0.1%
합계                                9191.9ms
```

### 층별 conv 처리량 (주요 층)

```
CONV in=56x56x96  f=3x3x96  out=56x56x24  65.03M MAC  180.6ms  360 MMAC/s
CONV in=56x56x96  f=3x3x96  out=56x56x24  65.03M MAC  152.1ms  427 MMAC/s
CONV in=28x28x96  f=3x3x96  out=28x28x24  16.26M MAC   39.5ms  411 MMAC/s
CONV in=14x14x56  f=1x1x56  out=14x14x96   1.05M MAC    4.8ms  222 MMAC/s
```

conv는 370~430 MMAC/s로 정상 동작 중. 문제는 연산량이 아니라 **TRANSPOSE_CONV가
esp-nn에 구현이 없어 TFLite reference로만 돈다는 것**.

### 핵심 결론

| 문제 | 원인 | 해결 방향 |
|---|---|---|
| TRANSPOSE_CONV 6.77초 (73.7%) | FPN 넥의 업샘플링 op, esp-nn 미지원 | bilinear resize + Conv2D로 교체 |
| HARD_SWISH 45.8ms | int8 LUT 미적용 | 이미 해결 (rec에 적용, det도 동일 적용) |

TRANSPOSE_CONV만 없애도 det 9.2초 → **2~3초대** 예상.

---

## 2. 아키텍처 방향

### 핵심 원칙

- **TRANSPOSE_CONV 금지** — FPN 업샘플링을 `RESIZE_NEAREST_NEIGHBOR + Conv2D`로
- **HARD_SWISH 금지 or LUT** — int8에서 비쌈 (float보다 느려짐)
- **그룹 conv 금지** — esp-nn 미지원
- **PP-LCNet 백본 유지** — 가중치 재사용 가능, 백본 자체는 문제 없음

### 업샘플링 교체 (핵심 수정)

```
기존 FPN:
  특징맵 → TRANSPOSE_CONV(stride=2) → 2배 업샘플

교체:
  특징맵 → RESIZE_NEAREST_NEIGHBOR(scale=2) → Conv2D(3x3) → 결과
```

RESIZE_NEAREST_NEIGHBOR는 이미 det 모델에 6회 들어가 있고 6회 합계 20.5ms에 불과.
TRANSPOSE_CONV 6.77초를 ~200ms으로 줄일 수 있다.

---

## 3. 학습 전략 — 지식 증류

### 왜 지식 증류인가

- 새 모델(학생)은 아키텍처가 달라서 GT 라벨 없이 학습 가능
- 현재 동작하는 paddle_det 모델(교사)이 이미 있음
- 교사의 소프트 출력(확률맵)이 학생의 GT 역할을 함
- 버스 번호판 라벨 직접 만들 필요 없음

### 교사 — paddle_det (현재 모델)

현재 플래싱된 모델 그대로 사용.
Python에서 float32 버전으로 추론해 확률맵을 학생 학습 GT로 사용.

### 자동 라벨링 파이프라인

EasyOCR을 **자동 라벨러**로 사용:
1. 새 사진 수집 (~300장)
2. EasyOCR로 박스 좌표 추출
3. confidence 높은 것만 선별
4. 교사 모델로 확률맵 생성
5. 학생 모델 학습 (DB loss + KD loss)

EasyOCR을 소프트 라벨로 직접 쓰지 않는 이유: CRAFT 기반이라 출력 형식이
DB 확률맵과 다름. 바운딩박스 추출 용도로만 씀.

---

## 4. 점자블록 검출 모델 (우선 진행)

### 왜 점자블록을 먼저 하는가

- 학습 데이터 **10,000장** 보유 → 버스 사진(~100장)과 비교 불가한 양
- 태스크가 단순함 (텍스트 세밀도 불필요, 큰 패턴)
- 같은 PP-LCNet + 경량 헤드 구조를 검증하기 좋은 테스트베드
- 성공하면 버스 det에 동일 아키텍처 적용

### 아키텍처

```
입력: 224×224 RGB (또는 더 작게)
  → PP-LCNet 백본 (PaddleOCR det에서 가중치 이전)
  → 경량 헤드:
      Option A — 이진 분할 (점자블록 영역 여부 per-pixel)
      Option B — YOLO 스타일 (바운딩박스 + 존재 여부)
```

**Option A (이진 분할) 권장**:
- 시각장애인 보조 목적이라 "지금 점자블록 위에 있나?"가 핵심
- 픽셀별 마스크가 방향 안내에 더 유용
- TRANSPOSE_CONV 없이 resize+conv로 구현 가능
- DB 헤드 구조 재활용 가능 (확률맵 한 장만 출력)

### 기대 속도

TRANSPOSE_CONV 제거 + 단순 헤드 → det 대비:
- 예상 추론 시간: **1~3초** (현재 9.2초 대비)
- 점자블록 패턴이 큰 특징이라 입력 해상도도 낮출 수 있음 (160×120도 가능)

### 파티션 계획

현재 파티션은 버스 모델 전용. 점자블록 모델 추가 시 파티션 재구성 필요.
(현재 남은 flash 여유 있으면 기존 구조에 추가 가능)

---

## 5. 남은 작업 순서

| 순서 | 작업 | 데이터 | 예상 난이도 |
|---|---|---|---|
| 1 | 점자블록 모델 학습 (PP-LCNet + 이진분할 헤드) | 10,000장 보유 | 낮음 |
| 2 | ESP32 추론 속도 확인 | — | — |
| 3 | 버스 det 새 모델 설계 (TRANSPOSE_CONV 제거) | 300장 수집 예정 | 중간 |
| 4 | 지식 증류로 버스 det 학습 | paddle_det 교사 | 중간 |
| 5 | 점자블록 + 버스번호 통합 파이프라인 | — | 높음 |
