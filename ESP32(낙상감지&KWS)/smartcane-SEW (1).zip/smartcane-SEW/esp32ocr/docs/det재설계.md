# BrailleDet v1
## ESP32-S3 Optimized Braille Block Detector

---

# 1. 프로젝트 목표

YOLOv8보다 훨씬 가벼운 Detector를 설계하여
ESP32-S3에서 실시간 추론 가능한 점자블록 검출 모델을 개발한다.

목표

- Bounding Box 출력
- YOLOv8 Label 그대로 사용
- MobileNetV2 Backbone
- ESP32-S3 Friendly
- Full INT8 Quantization
- TFLite 변환 지원

---

# 2. 입력

Input

224 × 224 × 1

Grayscale Image

↓

채널 복사

↓

224 × 224 × 3

---

# 3. Backbone

MobileNetV2

alpha = 0.35

ImageNet Pretrained

include_top=False

Feature Map 출력

14 × 14 × C

(14×14 Layer 사용)

사용 연산

- Conv2D
- DepthwiseConv2D
- BatchNorm
- ReLU6
- Add

사용하지 않는 연산

- TransposeConv
- GroupConv
- Attention
- LSTM
- BatchMatMul

---

# 4. Detection Head

입력

14 × 14 × C

↓

1×1 Conv

128 Channel

↓

BatchNorm

↓

ReLU6

↓

3×3 Conv

128 Channel

↓

BatchNorm

↓

ReLU6

↓

1×1 Conv

5 Channel

↓

Output

14 × 14 × 5

---

# 5. Output

각 Grid Cell은

conf

cx

cy

w

h

총 5개 값을 출력한다.

Output Shape

14 × 14 × 5

즉

196개의 Cell이 각각

(conf,cx,cy,w,h)

예측한다.

---

# 6. Label

YOLOv8 Label 사용

형식

class cx cy w h

예시

0 0.52 0.43 0.38 0.24

라벨 변환

grid_x = int(cx × 14)

grid_y = int(cy × 14)

local_x = cx × 14 - grid_x

local_y = cy × 14 - grid_y

Target

target[grid_y,grid_x]

=

conf = 1

cx = local_x

cy = local_y

w

h

나머지 Cell

conf = 0

---

# 7. Loss

Total Loss

=

Confidence Loss

+

Bounding Box Loss

Confidence

Binary Cross Entropy

Bounding Box

Smooth L1

+

IoU Loss

Class Loss

사용하지 않음

---

# 8. Detection

Anchor-Free

Anchor 사용하지 않음

Class 1개

Bounding Box 1개

NMS 사용하지 않음

후처리

196개의 Cell

↓

Confidence 최대 선택

↓

Bounding Box 출력

---

# 9. Activation

Confidence

Sigmoid

cx

Sigmoid

cy

Sigmoid

w

Sigmoid (초기 버전)

h

Sigmoid (초기 버전)

---

# 10. ESP32-S3 Friendly Operator

사용

Conv2D

DepthwiseConv2D

BatchNorm

ReLU6

Sigmoid

Add

AveragePool

Reshape

사용 금지

TransposeConv

GroupConv

Attention

BatchMatMul

StridedSlice

LSTM

---

# 11. TensorFlow Lite

학습

FP32

↓

Representative Dataset

↓

Calibration

↓

Full INT8 Quantization

↓

brailledet_int8.tflite

목표

INT8 Accuracy Drop

1~3% 이하

---

# 12. ESP32 추론

Camera

↓

224×224 Gray

↓

BrailleDet

↓

14×14×5

↓

Confidence 최대 Cell

↓

Bounding Box

↓

Bounding Box 중심(cx)

↓

Left / Center / Right

↓

TTS 출력

---

# 13. 프로젝트 특징

✔ MobileNetV2 Backbone

✔ Detect Head 기반

✔ Anchor-Free

✔ NMS 제거

✔ YOLOv8 Label 그대로 사용

✔ Full INT8 Quantization

✔ ESP32-S3 최적화

✔ Bounding Box 출력

✔ 향후 장애물 Detector로 확장 가능