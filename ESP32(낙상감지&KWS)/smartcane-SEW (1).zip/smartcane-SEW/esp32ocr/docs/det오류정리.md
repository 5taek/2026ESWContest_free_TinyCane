# 점자블록 검출 (DET) 오류 정리

**기간:** 2026-07-31 ~ 2026-08-03  
**범위:** 카메라 코드 작성부터 TFLite 변환까지  
**목표:** ESP32-S3에서 224×224 그레이스케일 입력으로 단일박스 회귀

> ⚠️ **esp-nn depthwise conv의 scratch 버퍼 크기 계산 버그는 esp32ocr
> `개발기록.md`에 없는, 이 프로젝트(브레일블록)에서 처음 밟은 버그다.**
> esp32ocr 문서에 있는 건 1x1 conv 정렬 검사 누락(오류 8)과 5x5 depthwise
> 패딩 채우기 버그, 이 둘뿐이다. esp32ocr의 rec 모델은 채널 수/shape 조합이
> 달라 이 scratch 분기를 밟지 않았을 뿐, "이미 알려진 버그"가 아니다.
> 다음에 비슷한 크래시를 만나면 esp32ocr 기록을 뒤지기 전에 **이 문서의
> 오류 9 계열부터 확인할 것.**

---

## 오류 1: TFLite TILE 연산

**로그:**
```
Didn't find op for builtin opcode 'TILE'
Failed to get registration from op code TILE
E (1284) brail: AllocateTensors 실패
```

**원인:** Lambda 레이어에서 `tf.repeat(t * 255.0, 3, axis=-1)` 사용  
**해결:** Lambda 제거 → 입력을 `(1, 224, 224, 3)` 고정 + 전처리 C 코드로 이동

---

## 오류 2: SHAPE 연산

**로그:**
```
Didn't find op for builtin opcode 'SHAPE'
Failed to get registration from op code SHAPE
```

**원인:** `Flatten()` 레이어가 내부적으로 `tf.shape()` 호출  
**결과:** SHAPE → STRIDED_SLICE → PACK → EXPAND_DIMS 등이 연쇄로 생김  
**해결:** `Flatten()` → `Reshape((1568,))` (고정 숫자로 변경)

---

## 오류 3: STRIDED_SLICE / PACK / EXPAND_DIMS 누적

**로그:**
```
Didn't find op for builtin opcode 'STRIDED_SLICE'
Failed to get registration from op code STRIDED_SLICE
...
Didn't find op for builtin opcode 'PACK'
...
Didn't find op for builtin opcode 'EXPAND_DIMS'
```

**원인:** Flatten의 동적 shape 계산 체인  
**해결:** Reshape로 모두 해결됨 (op 3개씩 사라짐)

---

## 오류 4: VAR_HANDLE 변수

**로그:**
```
Didn't find op for builtin opcode 'VAR_HANDLE'
Failed to get registration from op code VAR_HANDLE
```

**원인:** `tf.function()`으로 concrete function 만들 때 변수가 동결 안 됨  
**해결:** concrete function 우회 → 배치 크기를 모델 구조에 직접 고정 (`batch_shape=(1,...)`)

---

## 오류 5: LoadProhibited / Guru Meditation

**로그:**
```
Guru Meditation Error: Core 0 panic'ed (LoadProhibited)
PC      : 0x4203969b  (MicroInterpreterGraph::InvokeSubgraph)
A8      : 0x1a879e82  ← 텐서 포인터 쓰레기
```

**원인:** Flatten의 동적 할당이 포인터를 제대로 구성하지 않음  
**해결:** Reshape로 고정화 → 포인터 정상 할당

---

## 오류 6: 스택 오버플로우

**로그:**
```
Guru Meditation Error: Core 0 panic'ed (InstrFetchProhibited)
... 0x4200f7eb: infer_task(void*) at main.cpp:306
```

**원인:** `xTaskCreate(infer_task, "infer", 8192, ...)` 스택 8KB 부족  
**해결:** `32768` (32KB)로 증가

---

## 오류 7: 파티션 크기 부족

**로그:**
```
Exception: Input file size exceeds partition size
```

**원인:** 모델 2.44MB > 파티션 1M  
**해결:** `partitions.csv`에서 1M → 3M

---

## 전처리 변환

### 기존 (Lambda)
```
입력: 그레이스케일 (1, 224, 224, 1)
Lambda: gray → [그레이*255, 그레이*255, 그레이*255] → MobileNetV2 preprocess
```

### 변경 후 (C 코드)
```
입력: 이미 전처리된 (1, 224, 224, 3)
C 코드 (resize_norm):
  v = gray / 127.5 - 1.0  // [-1, 1]
  px[0] = px[1] = px[2] = v  // 세 채널 동일
```

---

## 모델 최종 구조

```
Input (1, 224, 224, 3)
  ↓
MobileNetV2 (α=0.35)
  ↓
Conv2D(32, 1×1, relu)
  ↓
Reshape(1568)  ← Flatten 대신
  ↓
Dense(128, relu) + Dropout(0.3)
  ↓
Dense(5, sigmoid)  ← [cx, cy, w, h, conf]
```

---

## 주의사항

| 항목 | 주의 |
|------|------|
| 배치 크기 | `batch_shape=(1,...)` 반드시 고정 (아니면 SHAPE/PACK 생김) |
| Flatten | 금지. Reshape(고정숫자)만 사용 |
| Calibration | 원본과 동일한 전처리 적용, 0장이 아닌지 확인 |
| 모델 크기 | INT8 후 < 1MB. 2MB+ = 양자화 실패 신호 |
| 스택 | infer_task >= 32KB |
| 파티션 | model >= 3M |

---

## 확인 체크리스트

- [x] `export_no_lambda.py` 실행 후 "TILE 없음" 메시지
- [x] 사용 연산 목록에 SHAPE/PACK/EXPAND_DIMS/STRIDED_SLICE 없음
- [x] 모델 파일 크기 < 1MB
- [x] `parttool.py write_partition` 성공
- [x] 보드에서 "모델 준비 완료" 로그
- [x] 입력 shape 224×224×3 확인
- [x] 추론 시간 기록

---

## 오류 8: op 지원 = op 정확성 아님 (esp-nn 커널 버그)

**증상:** 위 오류 1~7을 전부 해결하고 op 목록도 깨끗한데
(`ADD, CONV_2D, DEPTHWISE_CONV_2D, DEQUANTIZE, FULLY_CONNECTED, LOGISTIC,
QUANTIZE, RESHAPE`), 여전히 같은 자리에서 크래시:

```
Guru Meditation Error: Core 0 panic'ed (LoadProhibited)
PC : 0x4203969b (MicroInterpreterGraph::InvokeSubgraph)
A8 : 0xd598808d, 0x1a879e82, 0xbd99808e ...  ← 매번 다른 쓰레기 주소
--- memcpy in ROM
```

**오해했던 지점:** "op가 resolver에 등록돼 있고 지원된다"는 걸
"그 커널 구현이 정확하다"와 혼동함. 별개 문제.

**진단 순서:**
1. `CONFIG_NN_ANSI_C=y`로 esp-nn 최적화를 끄고 순정 reference 커널로 테스트
   → **크래시 사라짐.** esp-nn 커널 버그로 확정.
2. 처음엔 `CONFIG_NN_OPTIMIZED=n`으로 껐는데 **전혀 효과 없었음** (아래 오류 8-A)
3. `esp32ocr` 프로젝트의 `개발기록.md` 5-A 섹션에서 동일 증상(무작위 쓰레기
   포인터, memcpy 크래시)을 이미 겪었고 원인을 규명해둔 기록 발견:
   **1x1 conv SIMD 경로가 "8바이트 정렬 필요"라고 주석에만 적어두고 실제
   검사를 안 함.** `esp_partition_mmap()`으로 flash에서 읽은 필터 포인터는
   정렬이 보장 안 되는데, 이 정렬 안 된 포인터로 SIMD 로드하다가 죽음.
4. MobileNetV2는 1x1 pointwise conv가 압도적으로 많고, 우리도 모델을 flash
   mmap으로 읽으므로 조건이 완전히 일치.

**해결:**
`managed_components/espressif__esp-nn/src/convolution/esp_nn_conv_esp32s3.c`
391번째 줄 근처 `esp_nn_conv_s8_esp32s3()` 함수, 1x1 conv 분기:

```c
// 기존 (버그) — 정렬 검사 없이 채널 수만 확인
if (channels % 8 == 0) {
    esp_nn_conv_s8_mult8_1x1_esp32s3(...);
}

// 수정 — 정렬까지 확인, 안 되면 범용 폴백으로
if (channels % 8 == 0 && ((uintptr_t)filter_data & 7) == 0) {
    esp_nn_conv_s8_mult8_1x1_esp32s3(...);   // 정렬 OK: SIMD 고속 경로
} else {
    esp_nn_conv_s8_1x1(...);                  // 정렬 무관 범용 경로
}
```

참고로 같은 파일의 general conv 경로(1x1이 아닌 conv)는 이미 정렬 검사가
있었음(`(int) filter_data & 15` 체크 후 필요시 정렬된 scratch로 복사).
**1x1 전용 고속 경로에만** 이 검사가 빠져 있었음.

**교훈:**
- op가 resolver에 등록돼 실행된다고 그 구현이 정확하다는 보장은 없다.
  같은 vendored 라이브러리(esp-tflite-micro/esp-nn)를 쓰는 다른 프로젝트가
  이미 같은 버그를 겪었다면 그 기록부터 찾아볼 것 — 처음부터 다시
  디버깅할 필요 없음.
- flash mmap 포인터(`esp_partition_mmap()`)는 정렬이 보장되지 않는다.
  SIMD 어셈블리에 넘기기 전에 항상 의심할 것.
- "크래시 지점이 랜덤한 쓰레기 주소"는 정렬 문제의 전형적인 신호.

---

## 오류 8-A: Kconfig choice에서 `=n`이 안 먹힘

**증상:** `sdkconfig.defaults`에 `CONFIG_NN_OPTIMIZED=n`을 쓰고
`sdkconfig` 삭제 후 재빌드해도 실제로는 계속 `y`로 빌드됨.

**원인:** `NN_OPTIMIZED`는 평범한 bool 옵션이 아니라 **Kconfig choice(양자택일)**
블록 안에 있음 (`espressif__esp-nn/Kconfig.projbuild`):

```
choice NN_OPTIMIZATIONS
   default NN_OPTIMIZED
config NN_ANSI_C
   bool "ANSI C"
config NN_OPTIMIZED
   bool "Optimized versions"
endchoice
```

choice 멤버는 `=n`으로 끌 수 없다. 정상적으로 꺼진 상태의 sdkconfig 표기는
`# CONFIG_NN_OPTIMIZED is not set`이지 `CONFIG_NN_OPTIMIZED=n`이 아니다.
`=n`을 sdkconfig.defaults에 써도 Kconfig가 이를 해석 못 해 조용히 무시하고
choice의 `default NN_OPTIMIZED`로 되돌아간다.

**해결:** 끄고 싶으면 반대쪽을 명시적으로 켜야 한다:
```
CONFIG_NN_ANSI_C=y
```
이러면 choice 규칙에 따라 `NN_OPTIMIZED`가 자동으로 꺼진다.

**교훈:**
- Kconfig choice 안의 옵션은 `=n`이 아니라 **다른 멤버를 `=y`로** 꺼야 한다.
- 옵션이 예상대로 안 먹히면, 그 옵션이 `choice` 블록 안에 있는지부터
  `grep -rn "config NN_OPTIMIZED" managed_components/`로 확인할 것.

---

## 오류 9: 1x1 conv 정렬 패치 후에도 동일 크래시 (진행 중)

**증상:** 오류 8의 1x1 conv 정렬 검사 패치(`esp_nn_conv_esp32s3.c`)를 적용하고
재빌드했는데(`.obj` 재컴파일 확인됨), **완전히 동일한 크래시가 재현됨**
(같은 PC `0x4203969b`, 매번 다른 쓰레기 `EXCVADDR`).

**결론:** 1x1 conv 정렬 문제가 이번 크래시의 원인이 아니었음.
depthwise conv 코드(`esp_nn_depthwise_conv_s8_esp32s3.c`)도 검토했으나,
대부분의 SIMD 경로에서 필터를 `memcpy`로 정렬된 scratch에 복사한 뒤 쓰고
있어 필터 정렬 문제는 아닌 것으로 보임.

**새로운 단서 — 크래시 지점 재확인:**

`micro_interpreter_graph.cc`의 `InvokeSubgraph()`에서, 크래시 PC가 가리키는
줄은 커널 실행(`registration->invoke(...)`, 277번째 줄)이 아니라
**그 다음 줄인 `allocator_->ResetTempAllocations()`(286번째 줄)**이었다.

즉 커널 자체는 에러 없이 끝났는데(`invoke_status == kTfLiteOk`), 바로 다음
줄에서 `allocator_` 포인터를 역참조하다 죽었다. 이는 "이 op가 잘못됐다"보다
**"직전에 실행된 커널이 자기 버퍼 범위를 넘어 써서, 인터프리터 객체 자신의
메모리(`allocator_` 멤버 등)를 훼손했다"**는 가설을 가리킨다. 그래서 죽는
지점이 실제 원인 커널보다 한 스텝 뒤에 나타난다.

**진단 코드 추가 (진행 중):**

`micro_interpreter_graph.cc` 277번째 줄, `invoke_status = registration->invoke(...)`
바로 다음에 노드 실행 완료를 알리는 로그 추가:

```cpp
    invoke_status = registration->invoke(context_, node);
    MicroPrintf("node %lu op=%d done", (unsigned long)current_operator_index_,
                (int)registration->builtin_code);
```

이러면 시리얼 로그에 노드 번호+op 코드가 순서대로 찍히다가, **크래시 직전
마지막으로 찍힌 노드가 범인**(그 커널이 버퍼 오버런을 낸 것)임을 알 수 있다.

**다음 단계:** 보드에서 재현해 마지막 로그 확인 → 해당 op와 텐서 shape을
Colab `tf.lite.experimental.Analyzer`로 대조해 원인 커널 특정.

**교훈 (지금까지):**
- 크래시가 발생하는 줄이 항상 "원인 줄"은 아니다. 버퍼 오버런형 버그는
  실제 원인 코드가 끝난 **다음** 지점에서야 드러난다.
- 하나의 가설(1x1 정렬)을 세우고 패치했다면, 패치 후 **동일 증상이
  재현되는지 반드시 재확인**할 것. "고쳤을 것 같다"로 넘어가지 말 것.
- 커널 구현을 눈으로 읽어 정렬 문제를 찾는 것보다, 노드별 실행 로그로
  범인을 좁히는 쪽이 훨씬 확실하다 (esp32ocr의 3-3 사례와 동일한 접근).

---

## 오류 9 후속: 실제 크래시 노드 특정 — depthwise conv scratch 오버런 의심

**노드별 로그 결과:**
```
node 0 op=114 done   (QUANTIZE)
node 1 op=3   done   (CONV_2D, stem)
node 2 op=4   done   (DEPTHWISE_CONV_2D, block1)
node 3 op=3   done   (CONV_2D, block1 project)
node 4 op=3   done   (CONV_2D, block2 expand)
node 5 op=4   done   (DEPTHWISE_CONV_2D, block2)
[node 6 로그 없이 크래시]
```

**크래시 상세:**
```
Guru Meditation Error: Core 0 panic'ed (InstrFetchProhibited)
PC      : 0x00000000   ← NULL 함수 포인터 호출
A0      : 0x8201fce5   (복귀 주소 — node 6 invoke 호출 지점)
Backtrace: 0xfffffffd:... 0x4201fce2(MicroInterpreter::Invoke) ...
```

**해석:** node 5(DEPTHWISE_CONV_2D)까지는 "done" 로그가 찍혀 정상 종료.
그런데 **node 6이 시작되기도 전에 PC가 0으로 점프.** 이는 `for` 루프가
다음 노드의 `registration` 포인터를 읽어 `registration->invoke`를 호출하려는
순간, 그 포인터(또는 그 대상 구조체)가 **0으로 덮여 있었다는 뜻.**

**가설:** node 5의 esp-nn depthwise conv SIMD 커널이 자신에게 할당된
scratch 버퍼 범위를 넘어 써서, arena 내 인접 영역(다음 노드의
`node_and_registrations` 메타데이터)을 0으로 뭉갰다.
`esp_nn_get_depthwise_conv_scratch_size_esp32s3()`의 분기가 매우 복잡해
(`managed_components/espressif__esp-nn/src/convolution/esp_nn_depthwise_conv_s8_esp32s3.c`
348~443번째 줄) 특정 채널 수 조합에서 필요 크기를 과소 계산했을 가능성.

**검증을 위한 임시 조치:**
`managed_components/espressif__esp-tflite-micro/tensorflow/lite/micro/kernels/esp_nn/depthwise_conv.cc`
상단에 진단 플래그 추가:
```cpp
#define FORCE_DWCONV_REFERENCE 1
```
그리고 `Eval()`의 int8 분기(352번째 줄 근처)에서 이 플래그가 켜져 있으면
esp-nn을 건너뛰고 TFLite reference로 우회하도록 조건 수정:
```cpp
#if ESP_NN && !FORCE_DWCONV_REFERENCE
    EvalQuantizedPerChannel(...);   // esp-nn SIMD
#else
    reference_integer_ops::DepthwiseConvPerChannel(...);  // 우회
#endif
```

**다음 확인 사항:** 이 상태로 재빌드해서 크래시가 사라지는지 확인.
- **사라지면** depthwise conv scratch 버그 확정 → 정확한 크기 계산 수정 또는
  esp-nn 자체 ANSI C 버전(`esp_nn_depthwise_conv_s8_ansi`, 있다면)으로
  대체해 속도 일부 회복 시도.
- **그래도 크래시면** depthwise도 범인이 아님 → CONV_2D(node 4, block2 expand)
  나 다른 지점을 의심해야 함. node 6, 7 로그가 찍히는지 여부로 판단.

**속도 영향:** depthwise conv 전체를 reference로 우회하면 이전 측정(ANSI C
전체, 4.9~5.4초)과 비슷하거나 약간 나은 수준 예상. conv 최적화는 유지되므로
전부 reference였던 것보다는 빨라야 정상.

**검증 결과:** `FORCE_DWCONV_REFERENCE=1`로 재빌드 후 **크래시 완전히 사라짐.**
node 68(마지막 노드)까지 정상 실행, 추론 결과 정상 출력, 다음 사이클도 정상.
→ **depthwise conv scratch 버퍼 오버런이 크래시 원인으로 확정.**

다만 속도는 5898ms로 이전(전체 ANSI C, 4.9~5.4초)과 거의 동일했음.
MobileNetV2는 depthwise conv 비중이 커서, CONV_2D만 SIMD로 살리고
DEPTHWISE_CONV_2D를 TFLite reference(가장 느린 경로)로 보내면 체감 이득이 없음.
esp32ocr 5-A의 교훈("우회 선택지는 셋: SIMD > esp-nn ANSI C > TFLite
reference, 무심코 가장 느린 곳으로 보내지 말 것")을 그대로 재현한 셈.

**개선: TFLite reference → esp-nn 자체 ANSI-C로 교체**

`esp_nn_depthwise_conv_ansi.c`에 `esp_nn_depthwise_conv_s8_ansi()`가 이미
존재하고, `CMakeLists.txt`의 `c_srcs`에 있어 빌드 설정과 무관하게 항상
컴파일됨. scratch 버퍼도 필요 없어(`esp_nn_get_depthwise_conv_scratch_size_ansi`가
항상 0 반환) SIMD 버전의 scratch 오버런 버그 자체를 원천적으로 피한다.

`depthwise_conv.cc`의 `EvalQuantizedPerChannel()` 내부, 실제 커널 호출부만
`FORCE_DWCONV_REFERENCE`일 때 `esp_nn_depthwise_conv_s8()` 대신
`esp_nn_depthwise_conv_s8_ansi()`를 부르도록 수정. scratch 버퍼 요청/설정
코드도 이 경로에서는 건너뜀 (필요 없으므로).

```cpp
#if FORCE_DWCONV_REFERENCE
    esp_nn_depthwise_conv_s8_ansi(&input_dims, ..., &conv_params, &quant_data);
#else
    esp_nn_depthwise_conv_s8(&input_dims, ..., &conv_params, &quant_data);
#endif
```

**다음 확인 사항:** 이 상태로 재빌드해 (1) 크래시 여전히 없는지,
(2) 속도가 reference 대비 개선됐는지 측정.

**현재 커널 우회 현황 (2026-08-03 기준):**
| 커널 | 경로 | 이유 |
|---|---|---|
| CONV_2D | esp-nn SIMD | 1x1 정렬 검사 패치 후 정상 (오류 8) |
| DEPTHWISE_CONV_2D | esp-nn ANSI-C | SIMD가 scratch 오버런으로 크래시 (오류 9) |

esp32ocr과 마찬가지로 "우회 대상은 개수가 아니라 연산량 기준으로 판단,
선택지는 SIMD > esp-nn ANSI C > TFLite reference 순" 원칙을 그대로 적용.

**결과:** 5898ms → **2377ms** (2.5배 개선). 크래시 없음.

---

## 오류 9 후속2: op별 프로파일링 추가 (다음 최적화 대상 측정)

224 입력 해상도가 병목인지, depthwise conv를 SIMD로 되돌리는 게 더 급한지
추측하지 않고 esp32ocr 5-B 방식(측정 우선)을 그대로 적용.

**추가한 진단 코드:** `micro_interpreter_graph.cc`의 `InvokeSubgraph()`에
op(`builtin_code`)별 누적 시간/호출 횟수를 기록하고, 매 추론 끝에 느린 순
정렬해 출력하도록 수정.

```cpp
namespace {
int64_t g_op_time_us[150] = {0};
int32_t g_op_count[150] = {0};
const char *g_op_name[150] = {nullptr};
}

// 루프 안, invoke 호출을 감싸서 시간 측정
int64_t __t0 = esp_timer_get_time();
invoke_status = registration->invoke(context_, node);
int code = (int)registration->builtin_code;
if (code >= 0 && code < 150) {
    g_op_time_us[code] += esp_timer_get_time() - __t0;
    g_op_count[code]++;
    if (!g_op_name[code]) g_op_name[code] = OpNameFromRegistration(registration);
}

// 루프 끝난 뒤, subgraph_idx == 0 일 때 느린 순으로 출력
```

**출력 형식 예시:**
```
--- op profile (total XXXXms) ---
  DEPTHWISE_CONV_2D    x18   XXXXms  XX.X%
  CONV_2D              x45   XXXXms  XX.X%
  ...
```

**다음 단계:** 이 로그를 보고 CONV_2D와 DEPTHWISE_CONV_2D 중 실제 병목을
확인한 뒤, depthwise SIMD 버그를 고칠 가치가 있는지(비중이 크면 고칠 가치
있음) 또는 입력 해상도 224→160 축소가 더 나은지(구조 변경 없이 쉬움) 결정.

**측정 결과:** DEPTHWISE_CONV_2D 48.2%(1119ms/17회), CONV_2D 47.2%(1095ms/36회).
depthwise가 확실히 병목. esp32ocr의 bus_rec_v2에서는 depthwise가 SIMD로
44ms(4회)에 그쳤던 것과 비교하면 크지만, 그건 입력이 32×160(훨씬 작음)이고
SIMD였기 때문 — 규모와 SIMD 여부가 달라 직접 비교는 부적절. 호출당 시간
(66ms/회)은 비슷한 수준이라, "지금 depthwise가 ANSI-C라서 SIMD 대비 느린
것"이 맞는 진단. → scratch 버그를 고쳐 SIMD 복귀 시도할 가치 있음.

---

## 오류 9 후속3: scratch 오버런 위치 직접 계측 (카나리 진단)

`esp_nn_get_depthwise_conv_scratch_size_esp32s3()`와 실제 사용 코드를
줄 단위로 대조했으나(3x3+patch 다양한 분기), 대부분 일치하거나 오히려
넉넉하게 할당되고 있었다. 유일하게 의심되는 지점은 **타일 처리 분기**
(`esp_nn_depthwise_conv_s8_esp32s3.c` 528~563번째 줄)에서 SAME 패딩을
좌우/상하 **대칭**이라고 가정하는 부분 — stride=2인 depthwise 레이어는
입력 크기 홀짝에 따라 비대칭 패딩이 될 수 있어 이 가정이 깨질 수 있다.
다만 손으로 수식을 맞춰보는 것만으로는 "쓰기 오버런"과 정확히 연결되는지
확신하기 어려워, 추측 대신 **직접 계측**으로 전환.

**계측 방법 (카나리 패턴):**

`depthwise_conv.cc`에 `DWCONV_SCRATCH_DIAG` 플래그 추가. 실제 출력은 항상
안전한 ANSI-C 결과를 쓰고(`FORCE_DWCONV_REFERENCE=1` 그대로 유지), **곁다리로**
매 depthwise 호출마다:

1. `esp_nn_get_depthwise_conv_scratch_size()`로 "선언된" 필요 크기 확인
2. 그보다 8192바이트 더 큰 별도 버�퍼를 PSRAM에 할당
3. 전체를 카나리 값 `0xAA`로 채움
4. **SIMD 커널을 이 버퍼에 대고 실행** (결과는 버림, 진단 전용)
5. "선언된 크기" 이후 영역에서 `0xAA`가 아닌 바이트가 있는지 검사
6. 있으면 몇 바이트나 넘쳤는지 + 그때의 shape(입력/필터/패딩/스트라이드/
   채널배수)를 로그로 출력

```cpp
int declared = esp_nn_get_depthwise_conv_scratch_size(&input_dims, &filter_dims,
                                                       &output_dims, &conv_params);
const int guard = 8192;
uint8_t *diag = heap_caps_malloc(declared + guard, MALLOC_CAP_SPIRAM);
memset(diag, 0xAA, declared + guard);
esp_nn_set_depthwise_conv_scratch_buf(diag);
esp_nn_depthwise_conv_s8(..., diag_out, ...);   // 결과는 버림
// declared 이후 영역에서 0xAA 깨진 지점 찾기 → overrun 바이트 수
```

**안전성:** 이 진단은 인터프리터의 실제 arena와 완전히 분리된 별도 힙
버퍼에서 돌기 때문에, SIMD가 정말로 넘치더라도(가설이 맞다면) 이 진단
버퍼 자체만 훼손되고 실제 추론이나 인터프리터 객체는 훼손되지 않는다.
안전하게 관찰만 하는 구조.

**출력 형식:**
```
[DWCONV DIAG] OVERRUN 96 bytes!  declared=3600  in=56x56x24 filt=3x3 pad=1,1 stride=1,1 ch_mult=1
[DWCONV DIAG] ok  declared=1616  in=112x112x8 filt=3x3 pad=1,1 stride=2,2 ch_mult=1
...
```

**다음 단계:** 로그에서 `OVERRUN`이 찍힌 노드의 shape을 확인해, 그 조건에
해당하는 `esp_nn_get_depthwise_conv_scratch_size_esp32s3()`의 분기를
정확히 찾아 여유분을 늘리거나 계산식을 수정. 전부 `ok`면 이 가설도
기각되고 다른 원인(예: TFLM 쪽 arena 정렬/오프셋 문제)을 봐야 함.

**주의:** 진단이 끝나면 `DWCONV_SCRATCH_DIAG`를 0으로 꺼야 한다 — 매 호출마다
SIMD를 한 번 더 돌리고 PSRAM 할당/해제까지 하므로 이 상태로는 오히려
평소보다 느리다 (측정 전용, 운영용 아님).
