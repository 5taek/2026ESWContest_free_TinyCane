# 점자블록 검출 (Brailblock Detection) 설계 문서

**작성일:** 2026-08-03  
**상태:** 진행 중 (Flatten 레이어 최적화 단계)  
**목표:** ESP32-S3(DFR1154)에서 카메라 영상을 실시간으로 처리해 점자블록 위치와 방향 인식

---

## 1. 전체 파이프라인

```
카메라(GRAYSCALE 640×480)
  ├─ 224×224 리사이즈 + [-1,1] 정규화 (bilinear) → C 코드 전처리
  ├─ TFLite INT8 추론 (MobileNetV2 + 단일박스 회귀)
  │     출력: [cx, cy, w, h, conf]
  │     → 신뢰도 >= 0.5면 유효
  │     → 방향 판정: cx < 0.35 (왼쪽) / 0.65 (오른쪽) / 정면
  └─ 실시간 MJPEG 스트리밍 + JSON 결과 엔드포인트
  
HTTP 대시보드 (브라우저)
  ├─ `/` : HTML 대시보드 (영상 + 초록 박스 오버레이)
  ├─ `/stream` : MJPEG
  ├─ `/result` : JSON 결과 (0.4초마다 폴링)
  └─ `/ir/[on|off|auto]` : IR LED 제어
```

---

## 2. 모델 구조

### 입력
- **형태:** `(1, 224, 224, 3)` (배치 1 고정)
- **타입:** float32, 범위 [-1, 1]
- **생성:** C 코드에서 그레이스케일을 RGB로 복제해 정규화
  ```c
  float v = (gray / 127.5f) - 1.0f;
  px[0] = px[1] = px[2] = v;  // 세 채널 동일
  ```

### 구조
```
Input (1, 224, 224, 3)
  ↓
MobileNetV2 (alpha=0.35) 백본
  ↓
Conv2D(32, 1×1, relu)
  ↓
Reshape(-1, 1568)  ← Flatten() 대신 고정 숫자로 (이유: 아래 참조)
  ↓
Dense(128, relu) + Dropout(0.3)
  ↓
Dense(5, sigmoid) ← [cx, cy, w, h, conf]
```

### 출력
- **형태:** `(1, 5)` float32
- **해석:**
  - `[0:4]` : 정규화된 박스 좌표 (0~1)
  - `[4]` : 신뢰도

---

## 3. 주요 오류와 해결 과정

### 오류 1: TFLite에 TILE 연산 생김

**증상:**
```
Didn't find op for builtin opcode 'TILE'
Failed to get registration from op code TILE
E (1284) brail: AllocateTensors 실패
```

**원인:**
- Keras Lambda 레이어로 그레이→RGB 변환을 모델 안에 구현
- `tf.repeat(t * 255.0, 3, axis=-1)` 내부에서 TILE 연산이 생김
- esp-tflite-micro가 TILE을 지원하지 않음

**해결:**
1. 학습된 모델에서 Lambda를 제거한 새 구조 생성
2. 입력을 `(224, 224, 3)` 고정으로 변경
3. 가중치만 이전해 TFLite 재변환
4. 전처리는 ESP32의 C 코드에서 처리

**코드:** `colab/export_no_lambda.py`

---

### 오류 2: SHAPE / STRIDED_SLICE / PACK 연산 누적

**증상:**
```
Didn't find op for builtin opcode 'SHAPE'
Didn't find op for builtin opcode 'STRIDED_SLICE'
E (1279) brail: AllocateTensors 실패 (arena 부족 또는 미지원 연산)
```

**원인:**
- Keras의 `Flatten()` 레이어 내부 구현
- 배치 크기를 런타임에 계산하기 위해 `tf.shape()` 호출
- 배치를 1로 고정해도 Python 코드 경로 자체가 변하지 않음
- 변환 후 그래프에 SHAPE → StridedSlice → Pack이 남음

**해결:**
- `Flatten()` 대신 고정 숫자로 `Reshape()`
  ```python
  flat_dim = x.shape[1] * x.shape[2] * x.shape[3]  # 7×7×32 = 1568
  x = tf.keras.layers.Reshape((flat_dim,))(x)
  ```
- 이러면 tf.shape() 호출 자체가 없어져서 이 op들이 그래프에 안 생김

---

### 오류 3: LoadProhibited / InstrFetchProhibited 크래시

**증상:**
```
Guru Meditation Error: Core 0 panic'ed (LoadProhibited)
...
A8 : 0x1a879e82  ← 텐서 포인터가 쓰레기 값
Backtrace: ... tflite::MicroInterpreterGraph::InvokeSubgraph(int)
           ... tflite::MicroInterpreter::Invoke()
```

**원인:**
- Flatten의 동적 shape 계산 때문에 텐서 포인터가 제대로 할당되지 않음
- esp-tflite-micro의 SHAPE/PACK 커널 구현이 버그 있음
- memcpy가 잘못된 주소를 접근

**해결:**
- Reshape로 고정 숫자화 (위 오류 2 해결책이 이 문제도 해결)

---

### 오류 4: 스택 오버플로우

**증상:**
```
Guru Meditation Error: Core 0 panic'ed (InstrFetchProhibited)
... PC = 0x4203969b (MicroInterpreterGraph::InvokeSubgraph)
```

**원인:**
- MobileNetV2 같은 깊은 네트워크는 Invoke() 시 스택을 많이 씀
- 처음에 `xTaskCreate(infer_task, "infer", 8192, ...)`로 8KB만 할당
- 스택 오버플로우 → 리턴 주소 깨짐 → 엉뚱한 곳으로 점프

**해결:**
```cpp
xTaskCreate(infer_task, "infer", 32768, NULL, 3, NULL);  // 32KB로 증가
```

---

## 4. TFLite 변환 및 INT8 양자화

### Colab 스크립트: `export_no_lambda.py`

**핵심 단계:**

1. **가중치 로드**
   - 학습된 모델(Lambda 포함) 재구성 후 load_weights

2. **구조 변경**
   - Lambda 제거, 입력 배치 고정 `(1, 224, 224, 3)`
   - Flatten → Reshape(1568) 변경

3. **가중치 이전**
   - 백본 (MobileNetV2): 모두 이전
   - 헤드 (Dense/Conv): 가중치만 이전

4. **검증**
   ```python
   probe_gray = random(2, 224, 224, 1)
   probe_rgb = (probe_gray * 255) / 127.5 - 1
   diff = max(src.predict(probe_gray) - dst.predict(probe_rgb))
   # 0.0003 수준이면 정상 (INT8 오차 0.0078보다 작음)
   ```

5. **INT8 양자화**
   - calibration: 검증 이미지로 범위 학습
   - 입력: float32, 출력: float32 (양자화는 내부에만)

### 주의사항

- **배치 크기 고정:** `batch_shape=(1, ...)` 필수
  - 아니면 SHAPE/PACK 등이 남아 esp-tflite-micro에서 죽음
- **Flatten 금지:** Reshape(고정숫자)만 사용
- **Calibration 데이터:** 원본과 같은 전처리 적용

---

## 5. ESP32 구현

### 파일 구조

```
C:\Users\shiny\brailblock\
├─ main/
│  ├─ main.cpp (1200줄+)
│  ├─ CMakeLists.txt
│  └─ idf_component.yml
├─ data/
│  └─ brailblock_int8.tflite (또는 _nolambda_int8.tflite)
├─ partitions.csv (3줄 추가)
└─ sdkconfig.defaults
```

### 파티션 설정 (`partitions.csv`)

```
factory,  app,  factory, 0x10000, 2M,   (앱 코드)
model,    data, 0x40,    ,        3M,   (TFLite 모델)
```

**플래싱:**
```bash
parttool.py -p COM7 write_partition --partition-name=model --input brailblock_int8.tflite
idf.py flash -p COM7
```

### 주요 함수

#### `resize_norm()`
```cpp
// 640×480 그레이 → 224×224×3, [-1,1] 정규화
// 세 채널에 동일 값 저장
float v = (gray / 127.5f) - 1.0f;
px[0] = px[1] = px[2] = v;
```

#### `infer()`
- 프레임 캡처 (그레이스케일)
- resize_norm() 호출
- s_interp->Invoke()
- 결과 파싱 + 방향 판정

#### `infer_task()`
- 1500ms 간격으로 추론
- 조도센서 읽어 IR LED 자동 제어
- LTR-308: 15 lux 미만 → IR ON, 30 lux 초과 → IR OFF

### HTTP 대시보드

- `/` : HTML 페이지 (canvas로 박스 그림)
- `/stream` : MJPEG (frame2jpg로 그레이 → JPEG 변환)
- `/result` : JSON `{cx, cy, w, h, conf, dir, ms, ir, lux}`
- `/ir/[on|off|auto]` : IR 제어

---

## 6. 현재 상태 및 남은 작업

### ✓ 완료
- 카메라 초기화 (GRAYSCALE 640×480)
- IR LED + 조도센서 (LTR-308)
- HTTP 서버 + 대시보드
- 모델 구조 설계 (Reshape 고정화)
- Colab TFLite 변환 스크립트

### 🔄 진행 중
- `export_no_lambda.py` 최종 확인
  - Reshape(1568) 적용 후 SHAPE/PACK 사라졌는지 확인
  - 사용 연산 목록 재확인
- 새 모델 파일 플래싱 및 보드 테스트

### ⚠️ 주의사항
- 모델 크기가 2.44MB면 INT8 양자화가 제대로 안 먹은 신호
  - calibration 데이터가 0장일 가능성 높음
  - Colab에서 압축 풀어야 함
- Flatten → Reshape 변경 후 재변환 필수

---

## 7. 다음 단계

1. Colab에서 `export_no_lambda.py` 실행
   - Reshape 적용 후 사용 연산 목록 확인 (SHAPE/PACK 없어야 함)
   - 파일 크기 < 1MB 확인

2. 새 모델 파일을 보드에 플래싱
   - `parttool.py write_partition`
   - `idf.py flash`

3. 추론 테스트
   - 브라우저에서 대시보드 확인
   - 박스 및 방향 표시 확인
   - 추론 시간 (ms) 기록

4. 버스 번호판 검출 (별도 작업)
   - 현재 점자블록만 훈련된 상태
   - 버스 데이터 144장으로는 부족 → 자동 라벨링 또는 수동 수집 필요

---

## 참고자료

- esp-tflite-micro 연산 목록: `MicroMutableOpResolver<N>` 등록된 op만 지원
- MobileNetV2: 0.35 alpha (경량화)
- DFR1154: OV3660 카메라, PSRAM 8MB Octal, Flash 8MB
- IR LED: GPIO47 (940nm 4개)
- 조도센서: LTR-308 (I2C 0x53, 카메라 SCCB 버스 공유)
