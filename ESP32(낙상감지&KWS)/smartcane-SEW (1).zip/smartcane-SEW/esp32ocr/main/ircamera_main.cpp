/**
 * DFR1154 (OV3660) 카메라 초기화 테스트
 * ircamera 프로젝트의 main/main.cpp 로 복사해서 쓸 것
 *
 * idf_component.yml 에 추가 필요:
 *   espressif/esp32-camera: "^2.0.0"
 *
 * CMakeLists.txt REQUIRES 에 추가 필요:
 *   esp32-camera
 */
#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"
#include "esp_camera.h"

static const char *TAG = "ircam";

// DFR1154 핀맵 (회로도 확인 완료)
static const camera_config_t CAM_CFG = {
    .pin_pwdn     = -1,
    .pin_reset    = -1,
    .pin_xclk     = 5,
    .pin_sccb_sda = 8,
    .pin_sccb_scl = 9,
    .pin_d7 = 4,
    .pin_d6 = 6,
    .pin_d5 = 7,
    .pin_d4 = 14,
    .pin_d3 = 17,
    .pin_d2 = 21,
    .pin_d1 = 18,
    .pin_d0 = 16,
    .pin_vsync = 1,
    .pin_href  = 2,
    .pin_pclk  = 15,

    .xclk_freq_hz = 20000000,
    .ledc_timer   = LEDC_TIMER_0,
    .ledc_channel = LEDC_CHANNEL_0,

    .pixel_format = PIXFORMAT_JPEG,
    .frame_size   = FRAMESIZE_VGA,   // 640x480
    .jpeg_quality = 12,
    .fb_count     = 2,
    .fb_location  = CAMERA_FB_IN_PSRAM,
    .grab_mode    = CAMERA_GRAB_LATEST,
    .sccb_i2c_port = -1,
};

extern "C" void app_main(void)
{
    ESP_LOGI(TAG, "카메라 초기화 중...");

    esp_err_t ret = esp_camera_init(&CAM_CFG);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "카메라 초기화 실패: 0x%x", ret);
        return;
    }
    ESP_LOGI(TAG, "카메라 초기화 성공");

    sensor_t *s = esp_camera_sensor_get();
    if (s) {
        ESP_LOGI(TAG, "센서 PID: 0x%x", s->id.PID);  // OV3660 = 0x3660
    }

    int frame = 0;
    while (1) {
        camera_fb_t *fb = esp_camera_fb_get();
        if (!fb) {
            ESP_LOGE(TAG, "프레임 캡처 실패");
        } else {
            ESP_LOGI(TAG, "프레임 %d: %u bytes  %dx%d",
                     frame++, fb->len, fb->width, fb->height);
            esp_camera_fb_return(fb);
        }
        vTaskDelay(pdMS_TO_TICKS(1000));
    }
}
