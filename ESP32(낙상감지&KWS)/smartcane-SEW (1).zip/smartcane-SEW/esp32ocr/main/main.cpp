// ============================================================
// ESP32-S3 Bus Number OCR — RPi USB-CDC 연동판
//
// RPi가 usb_serial_jtag(/dev/ttyACM*)로 트리거를 보내면 세션을 시작해서,
// RPi에게 640x480 그레이스케일 프레임을 요청(pull) → det → rec → 후보지 매칭을
// 반복하다가 맞으면(혹은 타임아웃되면) 결과를 텍스트 한 줄로 돌려준다.
//
// det/rec 각각의 op별 프로파일링 로그는 run_det()/run_rec() 안에 여전히
// 남아있지만, RPi와 통신하는 동안은 esp_log_level_set으로 꺼둔다.
// ============================================================

#include <cstdio>
#include <cstring>
#include <cmath>
#include <vector>
#include <algorithm>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "esp_log.h"
#include "esp_timer.h"
#include "esp_partition.h"
#include "esp_heap_caps.h"
#include "driver/usb_serial_jtag.h"

#include "tensorflow/lite/micro/micro_interpreter.h"
#include "tensorflow/lite/micro/micro_mutable_op_resolver.h"
#include "tensorflow/lite/schema/schema_generated.h"

#include "bus_dict.h"

static const char *TAG = "bus_ocr";

// ============================================================
// 0. RPi USB-CDC 프로토콜 (버스 번호 인식 트리거)
//
//   RPi -> ESP32 : MSG_TRIGGER (0xC0)        페이로드 없음, OCR 세션 시작
//   ESP32 -> RPi : MSG_BUS_IMG_REQ (0xA6)     페이로드 없음, 프레임 요청
//   RPi -> ESP32 : 4바이트 length header(LE, uint32, 항상 BUS_IMG_BYTES)
//                  + 640x480 그레이스케일 raw bytes
//   ESP32 -> RPi : 텍스트 한 줄 + '\n'  (예: "937\n", 실패 시 "NONE\n")
//
//   후보지는 RPi가 안 보내고 ESP32 쪽에 하드코딩 (테스트 단계).
// ============================================================

#define MSG_TRIGGER      0xC0
#define MSG_BUS_IMG_REQ  0xA6

#define OCR_TIMEOUT_MS   30000  // 테스트 단계라 넉넉하게 30초

static const char *BUS_CANDIDATES[] = {"937", "503", "북구2", "410"};
static const int BUS_CANDIDATES_COUNT = 4;

// ============================================================
// 1. Model / Image 설정
// ============================================================

#define ORIG_W 640
#define ORIG_H 480

#define DET_W 224
#define DET_H 224

#define GRID_SIZE 14

#define REC_H 32
#define REC_W 160

#define BUS_IMG_BYTES (ORIG_W * ORIG_H)  // 640*480 = 307200 (그레이스케일, RPi가 변환해서 보냄)

static constexpr float DET_CONF_THRES = 0.65f;
static constexpr float DET_IOU_THRES  = 0.30f;

// ============================================================
// 2. Tensor Arena
// ============================================================

constexpr int kDetArenaSize = 3500 * 1024;
constexpr int kRecArenaSize = 1024 * 1024;

static uint8_t *det_tensor_arena = nullptr;
static uint8_t *rec_tensor_arena = nullptr;

// ============================================================
// 3. Bounding Box
// ============================================================

struct Box {
    int x1, y1;
    int x2, y2;
    float score;
};

// ============================================================
// 4. Partition
// ============================================================

struct MappedPartition {
    const void *ptr = nullptr;
    size_t size = 0;
    esp_partition_mmap_handle_t handle{};
};

// ============================================================
// 5. Partition Mapping
// ============================================================

static bool map_partition(const char *name, esp_partition_subtype_t subtype, MappedPartition *out) {
    const esp_partition_t *part = esp_partition_find_first(ESP_PARTITION_TYPE_DATA, subtype, name);
    if (!part) {
        ESP_LOGE(TAG, "파티션 '%s'를 찾을 수 없음", name);
        return false;
    }

    if (esp_partition_mmap(part, 0, part->size, ESP_PARTITION_MMAP_DATA, &out->ptr, &out->handle) != ESP_OK) {
        ESP_LOGE(TAG, "파티션 '%s' mmap 실패", name);
        return false;
    }

    out->size = part->size;
    ESP_LOGI(TAG, "'%s' 파티션 매핑 완료 (%u bytes)", name, (unsigned)part->size);
    return true;
}

// ============================================================
// 6. DET 입력 전처리
//
// Grayscale 640x480 (RPi가 이미 변환해서 보냄) → 224x224 → INT8
// ============================================================

static void prepare_det_input(const uint8_t *src, int8_t *dst, float in_scale, int32_t in_zp) {
    for (int oy = 0; oy < DET_H; oy++) {
        float sy = (oy + 0.5f) * ORIG_H / DET_H - 0.5f;
        int y0 = std::max(0, static_cast<int>(std::floor(sy)));
        int y1 = std::min(ORIG_H - 1, y0 + 1);
        float fy = sy - y0;

        for (int ox = 0; ox < DET_W; ox++) {
            float sx = (ox + 0.5f) * ORIG_W / DET_W - 0.5f;
            int x0 = std::max(0, static_cast<int>(std::floor(sx)));
            int x1 = std::min(ORIG_W - 1, x0 + 1);
            float fx = sx - x0;

            // src가 이미 그레이스케일(1바이트/픽셀)이라 가중합 없이 바로 읽는다
            auto get_gray = [&](int y, int x) -> float {
                return src[y * ORIG_W + x] / 255.0f;
            };

            float top    = get_gray(y0, x0) + (get_gray(y0, x1) - get_gray(y0, x0)) * fx;
            float bottom = get_gray(y1, x0) + (get_gray(y1, x1) - get_gray(y1, x0)) * fx;
            float val    = top + (bottom - top) * fy;

            int32_t q = static_cast<int32_t>(std::round(val / in_scale)) + in_zp;
            q = std::clamp<int32_t>(q, -128, 127);

            dst[oy * DET_W + ox] = static_cast<int8_t>(q);
        }
    }
}

// ============================================================
// 6-B. REC 입력 전처리
//
// det 박스로 원본(640x480 그레이스케일)을 크롭 → 32x160 →
// 학습 코드와 동일한 정규화: (x/255 - 0.5) / 0.5, FLOAT32
// ============================================================

static void prepare_rec_input(const uint8_t *orig_img, int bx1, int by1, int bx2, int by2, float *dst) {
    int bw = std::max(1, bx2 - bx1 + 1);
    int bh = std::max(1, by2 - by1 + 1);

    // 전체를 검정(-1.0 정규화값)으로 채워 시작 — 남는 오른쪽은 패딩으로 남는다
    for (int i = 0; i < REC_H * REC_W; i++) {
        dst[i] = -1.0f;  // (0/255 - 0.5) / 0.5 = -1.0
    }

    // 높이를 32로 맞추고 가로세로 비율은 유지 (콜랩 prepare_rec_crop_esp_style과 동일)
    float scale = (float)REC_H / (float)bh;
    int target_w = static_cast<int>(std::round(bw * scale));
    if (target_w > REC_W) target_w = REC_W;
    if (target_w < 1) target_w = 1;

    // orig_img가 이미 그레이스케일(1바이트/픽셀)이라 가중합 없이 바로 읽는다
    auto get_gray = [&](int y, int x) -> float {
        return orig_img[y * ORIG_W + x] / 255.0f;
    };

    // 비율 유지 리사이즈: 원본 crop(bw x bh) -> (target_w x REC_H), 왼쪽 정렬로 기록
    for (int oy = 0; oy < REC_H; oy++) {
        float sy = by1 + (oy + 0.5f) * bh / (float)REC_H - 0.5f;
        int y0 = std::max(by1, std::min(by2, static_cast<int>(std::floor(sy))));
        int y1 = std::min(by2, y0 + 1);
        float fy = sy - y0;

        for (int ox = 0; ox < target_w; ox++) {
            float sx = bx1 + (ox + 0.5f) * bw / (float)target_w - 0.5f;
            int x0 = std::max(bx1, std::min(bx2, static_cast<int>(std::floor(sx))));
            int x1 = std::min(bx2, x0 + 1);
            float fx = sx - x0;

            float top    = get_gray(y0, x0) + (get_gray(y0, x1) - get_gray(y0, x0)) * fx;
            float bottom = get_gray(y1, x0) + (get_gray(y1, x1) - get_gray(y1, x0)) * fx;
            float val    = top + (bottom - top) * fy;

            // get_gray가 이미 /255를 했으므로 여기서는 (val-0.5)/0.5만 적용
            dst[oy * REC_W + ox] = (val - 0.5f) / 0.5f;
        }
    }
}

// ============================================================
// 6-C. CTC Greedy Decode
//
// argmax per timestep → blank(0) 제거, 연속 중복 제거 → bus_dict.h 매핑
// ============================================================

static void ctc_greedy_decode(const float *logits, int T, int C, char *out_str, size_t out_cap) {
    int prev = -1;
    size_t pos = 0;
    out_str[0] = '\0';

    for (int t = 0; t < T; t++) {
        const float *row = logits + t * C;
        int best = 0;
        float best_v = row[0];
        for (int c = 1; c < C; c++) {
            if (row[c] > best_v) { best_v = row[c]; best = c; }
        }

        if (best != prev && best != 0) {
            const char *ch = idx2char(best);
            if (ch) {
                size_t len = strlen(ch);
                if (pos + len < out_cap - 1) {
                    memcpy(out_str + pos, ch, len);
                    pos += len;
                    out_str[pos] = '\0';
                }
            }
        }
        prev = best;
    }
}

// ============================================================
// 7. IoU
// ============================================================

static float compute_iou(const Box &a, const Box &b) {
    int ix1 = std::max(a.x1, b.x1);
    int iy1 = std::max(a.y1, b.y1);
    int ix2 = std::min(a.x2, b.x2);
    int iy2 = std::min(a.y2, b.y2);

    int iw = std::max(0, ix2 - ix1 + 1);
    int ih = std::max(0, iy2 - iy1 + 1);

    float intersection = iw * ih;
    float area_a = (a.x2 - a.x1 + 1) * (a.y2 - a.y1 + 1);
    float area_b = (b.x2 - b.x1 + 1) * (b.y2 - b.y1 + 1);

    return intersection / (area_a + area_b - intersection + 1e-6f);
}

// ============================================================
// 8. DET
// ============================================================

static bool run_det(const void *model_ptr, const uint8_t *orig_img, Box *out_box) {
    int64_t total_start = esp_timer_get_time();

    // ========================================================
    // Arena
    // ========================================================
    if (!det_tensor_arena) {
        det_tensor_arena = (uint8_t *)heap_caps_aligned_alloc(16, kDetArenaSize, MALLOC_CAP_SPIRAM);
        if (!det_tensor_arena) {
            ESP_LOGE(TAG, "Tensor Arena 할당 실패");
            return false;
        }
    }

    // ========================================================
    // Model
    // ========================================================
    const tflite::Model *model = tflite::GetModel(model_ptr);

    // ========================================================
    // Resolver
    // ========================================================
    static tflite::MicroMutableOpResolver<20> resolver;
    static bool resolver_initialized = false;

    if (!resolver_initialized) {
        resolver.AddConv2D();
        resolver.AddDepthwiseConv2D();
        resolver.AddAdd();
        resolver.AddMul();
        resolver.AddRelu();
        resolver.AddRelu6();
        resolver.AddReshape();
        resolver.AddQuantize();
        resolver.AddDequantize();
        resolver.AddHardSwish();
        resolver.AddConcatenation();
        resolver.AddLogistic();
        resolver_initialized = true;
    }

    // ========================================================
    // Interpreter
    // ========================================================
    static tflite::MicroInterpreter interpreter(model, resolver, det_tensor_arena, kDetArenaSize);

    // ========================================================
    // Allocate Tensor
    // ========================================================
    static bool tensors_allocated = false;
    int64_t alloc_start = esp_timer_get_time();

    if (!tensors_allocated) {
        if (interpreter.AllocateTensors() != kTfLiteOk) {
            ESP_LOGE(TAG, "AllocateTensors 실패");
            return false;
        }
        tensors_allocated = true;
    }

    int64_t alloc_end = esp_timer_get_time();

    // ========================================================
    // Input / Output
    // ========================================================
    TfLiteTensor *input  = interpreter.input(0);
    TfLiteTensor *output = interpreter.output(0);

    // ========================================================
    // Preprocess
    // ========================================================
    int64_t preprocess_start = esp_timer_get_time();
    prepare_det_input(orig_img, input->data.int8, input->params.scale, input->params.zero_point);
    int64_t preprocess_end = esp_timer_get_time();

    // ========================================================
    // ★★★★★ Invoke ★★★★★
    // ========================================================
    int64_t invoke_start = esp_timer_get_time();

    if (interpreter.Invoke() != kTfLiteOk) {
        ESP_LOGE(TAG, "Invoke 실패");
        return false;
    }

    int64_t invoke_end = esp_timer_get_time();

    // ========================================================
    // Grid Decode
    // ========================================================
    int64_t decode_start = esp_timer_get_time();

    float out_scale     = output->params.scale;
    int32_t out_zp       = output->params.zero_point;
    const int8_t *raw_out = output->data.int8;

    std::vector<Box> candidates;
    candidates.reserve(GRID_SIZE * GRID_SIZE);

    for (int gy = 0; gy < GRID_SIZE; gy++) {
        for (int gx = 0; gx < GRID_SIZE; gx++) {
            int base = (gy * GRID_SIZE + gx) * 5;

            float dx   = (raw_out[base + 0] - out_zp) * out_scale;
            float dy   = (raw_out[base + 1] - out_zp) * out_scale;
            float bw   = (raw_out[base + 2] - out_zp) * out_scale;
            float bh   = (raw_out[base + 3] - out_zp) * out_scale;
            float conf = (raw_out[base + 4] - out_zp) * out_scale;

            if (conf >= DET_CONF_THRES && bw <= 0.40f && bh <= 0.40f) {
                float cx = (gx + dx) / static_cast<float>(GRID_SIZE);
                float cy = (gy + dy) / static_cast<float>(GRID_SIZE);

                Box b;
                b.x1 = std::max(0, static_cast<int>((cx - bw / 2.0f) * ORIG_W));
                b.y1 = std::max(0, static_cast<int>((cy - bh / 2.0f) * ORIG_H));
                b.x2 = std::min(ORIG_W - 1, static_cast<int>((cx + bw / 2.0f) * ORIG_W));
                b.y2 = std::min(ORIG_H - 1, static_cast<int>((cy + bh / 2.0f) * ORIG_H));
                b.score = conf;

                candidates.push_back(b);
            }
        }
    }

    int64_t decode_end = esp_timer_get_time();

    // ========================================================
    // NMS
    // ========================================================
    int64_t nms_start = esp_timer_get_time();

    std::sort(candidates.begin(), candidates.end(),
              [](const Box &a, const Box &b) { return a.score > b.score; });

    std::vector<bool> suppressed(candidates.size(), false);
    std::vector<Box> nms_results;

    for (size_t i = 0; i < candidates.size(); i++) {
        if (suppressed[i]) continue;
        nms_results.push_back(candidates[i]);

        for (size_t j = i + 1; j < candidates.size(); j++) {
            if (suppressed[j]) continue;
            if (compute_iou(candidates[i], candidates[j]) > DET_IOU_THRES) {
                suppressed[j] = true;
            }
        }
    }

    int64_t nms_end = esp_timer_get_time();

    // ========================================================
    // 결과
    // ========================================================
    if (nms_results.empty()) {
        int64_t total_end = esp_timer_get_time();

        ESP_LOGI(TAG, "No detection");
        ESP_LOGI(TAG, "Preprocess : %.2f ms", (preprocess_end - preprocess_start) / 1000.0);
        ESP_LOGI(TAG, "Invoke     : %.2f ms", (invoke_end - invoke_start) / 1000.0);
        ESP_LOGI(TAG, "Decode     : %.2f ms", (decode_end - decode_start) / 1000.0);
        ESP_LOGI(TAG, "NMS        : %.2f ms", (nms_end - nms_start) / 1000.0);
        ESP_LOGI(TAG, "TOTAL      : %.2f ms", (total_end - total_start) / 1000.0);

        return false;
    }

    *out_box = nms_results[0];

    int64_t total_end = esp_timer_get_time();

    // ========================================================
    // 전체 프로파일
    // ========================================================
    ESP_LOGI(TAG, "");
    ESP_LOGI(TAG, "==========================================");
    ESP_LOGI(TAG, "          DET PERFORMANCE");
    ESP_LOGI(TAG, "==========================================");
    ESP_LOGI(TAG, "AllocateTensors : %.2f ms", (alloc_end - alloc_start) / 1000.0);
    ESP_LOGI(TAG, "Preprocess      : %.2f ms", (preprocess_end - preprocess_start) / 1000.0);
    ESP_LOGI(TAG, "★ Invoke        : %.2f ms", (invoke_end - invoke_start) / 1000.0);
    ESP_LOGI(TAG, "Grid Decode     : %.2f ms", (decode_end - decode_start) / 1000.0);
    ESP_LOGI(TAG, "NMS             : %.2f ms", (nms_end - nms_start) / 1000.0);
    ESP_LOGI(TAG, "Candidates      : %d", static_cast<int>(candidates.size()));
    ESP_LOGI(TAG, "TOTAL DET       : %.2f ms", (total_end - total_start) / 1000.0);
    ESP_LOGI(TAG, "==========================================");

    return true;
}

// ============================================================
// 8-B. REC
// ============================================================

static bool run_rec(const void *model_ptr, const uint8_t *orig_img, const Box &box, char *out_str, size_t out_cap) {
    int64_t total_start = esp_timer_get_time();

    // ========================================================
    // Arena
    // ========================================================
    if (!rec_tensor_arena) {
        rec_tensor_arena = (uint8_t *)heap_caps_aligned_alloc(16, kRecArenaSize, MALLOC_CAP_SPIRAM);
        if (!rec_tensor_arena) {
            ESP_LOGE(TAG, "REC Tensor Arena 할당 실패");
            return false;
        }
    }

    // ========================================================
    // Model / Resolver
    // ========================================================
    const tflite::Model *model = tflite::GetModel(model_ptr);

    static tflite::MicroMutableOpResolver<20> rec_resolver;
    static bool rec_resolver_initialized = false;

    if (!rec_resolver_initialized) {
        rec_resolver.AddConv2D();
        rec_resolver.AddDepthwiseConv2D();
        rec_resolver.AddMaxPool2D();
        rec_resolver.AddRelu();
        rec_resolver.AddReshape();
        rec_resolver.AddShape();
        rec_resolver.AddStridedSlice();
        rec_resolver.AddPack();
        rec_resolver.AddQuantize();
        rec_resolver.AddDequantize();
        rec_resolver_initialized = true;
    }

    // ========================================================
    // Interpreter
    // ========================================================
    static tflite::MicroInterpreter rec_interpreter(model, rec_resolver, rec_tensor_arena, kRecArenaSize);

    static bool rec_tensors_allocated = false;
    if (!rec_tensors_allocated) {
        if (rec_interpreter.AllocateTensors() != kTfLiteOk) {
            ESP_LOGE(TAG, "REC AllocateTensors 실패");
            return false;
        }
        rec_tensors_allocated = true;
    }

    TfLiteTensor *input  = rec_interpreter.input(0);
    TfLiteTensor *output = rec_interpreter.output(0);

    // ========================================================
    // Preprocess (det 박스로 크롭)
    // ========================================================
    int64_t pre_start = esp_timer_get_time();
    prepare_rec_input(orig_img, box.x1, box.y1, box.x2, box.y2, input->data.f);
    int64_t pre_end = esp_timer_get_time();

    // ========================================================
    // Invoke
    // ========================================================
    int64_t inv_start = esp_timer_get_time();
    if (rec_interpreter.Invoke() != kTfLiteOk) {
        ESP_LOGE(TAG, "REC Invoke 실패");
        return false;
    }
    int64_t inv_end = esp_timer_get_time();

    // ========================================================
    // CTC Greedy Decode
    // ========================================================
    int T = output->dims->data[1];
    int C = output->dims->data[2];
    ctc_greedy_decode(output->data.f, T, C, out_str, out_cap);

    int64_t total_end = esp_timer_get_time();

    ESP_LOGI(TAG, "");
    ESP_LOGI(TAG, "==========================================");
    ESP_LOGI(TAG, "          REC PERFORMANCE");
    ESP_LOGI(TAG, "==========================================");
    ESP_LOGI(TAG, "Preprocess : %.2f ms", (pre_end - pre_start) / 1000.0);
    ESP_LOGI(TAG, "★ Invoke   : %.2f ms", (inv_end - inv_start) / 1000.0);
    ESP_LOGI(TAG, "TOTAL REC  : %.2f ms", (total_end - total_start) / 1000.0);
    ESP_LOGI(TAG, "==========================================");

    return true;
}

// ============================================================
// 8-C. RPi USB-CDC 통신 헬퍼
// ============================================================

static void usb_cdc_init(void) {
    usb_serial_jtag_driver_config_t cfg = USB_SERIAL_JTAG_DRIVER_CONFIG_DEFAULT();
    cfg.rx_buffer_size = 4096;
    cfg.tx_buffer_size = 4096;
    usb_serial_jtag_driver_install(&cfg);
}

// length 바이트를 다 받을 때까지 블로킹, timeout_ms 넘으면 false
static bool usb_cdc_read_exact(uint8_t *buf, size_t length, int timeout_ms) {
    size_t got = 0;
    int64_t deadline = esp_timer_get_time() + (int64_t)timeout_ms * 1000;

    while (got < length) {
        if (esp_timer_get_time() > deadline) return false;
        int n = usb_serial_jtag_read_bytes(buf + got, length - got, pdMS_TO_TICKS(100));
        if (n > 0) got += n;
    }
    return true;
}

static void usb_cdc_write(const void *data, size_t len) {
    usb_serial_jtag_write_bytes(data, len, pdMS_TO_TICKS(1000));
    usb_serial_jtag_wait_tx_done(pdMS_TO_TICKS(1000));
}

// 트리거 바이트(0xC0)가 올 때까지 한 바이트씩 폴링. 다른 바이트는 그냥 버림.
static void wait_for_trigger(void) {
    uint8_t b;
    while (true) {
        int n = usb_serial_jtag_read_bytes(&b, 1, pdMS_TO_TICKS(200));
        if (n == 1 && b == MSG_TRIGGER) return;
    }
}

// RPi에 640x480 그레이스케일 프레임을 요청해서 buf(BUS_IMG_BYTES)에 채운다.
static bool request_bus_frame(uint8_t *buf) {
    uint8_t req = MSG_BUS_IMG_REQ;
    usb_cdc_write(&req, 1);

    uint8_t header[4];
    if (!usb_cdc_read_exact(header, 4, 5000)) return false;

    uint32_t len = header[0] | (header[1] << 8) | (header[2] << 16) | ((uint32_t)header[3] << 24);
    if (len != (uint32_t)BUS_IMG_BYTES) return false;

    return usb_cdc_read_exact(buf, BUS_IMG_BYTES, 5000);
}

// 매 시도마다 무슨 일이 있었는지 RPi로 그대로 흘려보낸다 ("TRY:..." 접두사).
// 모니터 로그가 꺼져있는 동안 유일한 디버그 창구라서, 실패 이유까지 구분해서 보낸다.
static void send_try(const char *text) {
    char line[80];
    int n = snprintf(line, sizeof(line), "TRY:%s\n", text);
    usb_cdc_write(line, n);
}

// 최종 결과 ("RESULT:937\n" 또는 "RESULT:NONE\n")
static void send_bus_result(const char *text) {
    char line[64];
    int n = snprintf(line, sizeof(line), "RESULT:%s\n", text);
    usb_cdc_write(line, n);
}

static const char *match_candidate(const char *rec_text) {
    for (int i = 0; i < BUS_CANDIDATES_COUNT; i++) {
        if (strcmp(rec_text, BUS_CANDIDATES[i]) == 0) return BUS_CANDIDATES[i];
    }
    return nullptr;
}

// ============================================================
// 8-D. 버스 OCR 세션 (트리거 1회당 1번 실행)
// ============================================================

static void run_bus_ocr_session(const void *det_model_ptr, const void *rec_model_ptr, uint8_t *frame_buf) {
    esp_log_level_set("*", ESP_LOG_NONE);  // RPi 통신 채널에 로그가 섞이지 않도록

    int64_t start = esp_timer_get_time();
    char rec_text[64];
    const char *matched = nullptr;

    while ((esp_timer_get_time() - start) / 1000 < OCR_TIMEOUT_MS) {
        if (!request_bus_frame(frame_buf)) {
            send_try("(frame_fail)");
            continue;
        }

        Box box;
        if (!run_det(det_model_ptr, frame_buf, &box)) {
            send_try("(no_det)");
            continue;
        }

        if (!run_rec(rec_model_ptr, frame_buf, box, rec_text, sizeof(rec_text))) {
            send_try("(rec_fail)");
            continue;
        }

        send_try(rec_text[0] ? rec_text : "(empty)");

        matched = match_candidate(rec_text);
        if (matched) break;
    }

    esp_log_level_set("*", ESP_LOG_INFO);  // 세션 종료 후 로그 복구 (모니터로 볼 땐 참고용)

    send_bus_result(matched ? matched : "NONE");
}

// ============================================================
// 9. MAIN
// ============================================================

extern "C" void app_main(void) {
    ESP_LOGI(TAG, "==========================================");
    ESP_LOGI(TAG, " ESP32-S3 BUS OCR (RPi USB-CDC 연동)");
    ESP_LOGI(TAG, "==========================================");

    // ========================================================
    // 모델 파티션
    // ========================================================
    MappedPartition det_model;
    if (!map_partition("detmodel", (esp_partition_subtype_t)0x40, &det_model)) {
        ESP_LOGE(TAG, "DET model mapping 실패");
        return;
    }

    MappedPartition rec_model;
    if (!map_partition("recmodel", (esp_partition_subtype_t)0x41, &rec_model)) {
        ESP_LOGE(TAG, "REC model mapping 실패");
        return;
    }

    // ========================================================
    // 프레임 버퍼 (RPi가 보내는 640x480 그레이스케일, PSRAM)
    // ========================================================
    uint8_t *frame_buf = (uint8_t *)heap_caps_malloc(BUS_IMG_BYTES, MALLOC_CAP_SPIRAM);
    if (!frame_buf) {
        ESP_LOGE(TAG, "프레임 버퍼 할당 실패 (%d bytes)", BUS_IMG_BYTES);
        return;
    }

    // ========================================================
    // USB-CDC 초기화 + 트리거 대기 루프
    // ========================================================
    usb_cdc_init();
    ESP_LOGI(TAG, "RPi 트리거(0x%02X) 대기 중...", MSG_TRIGGER);

    while (true) {
        wait_for_trigger();
        ESP_LOGI(TAG, "🚏 트리거 수신 — OCR 세션 시작");

        run_bus_ocr_session(det_model.ptr, rec_model.ptr, frame_buf);

        ESP_LOGI(TAG, "세션 종료, 다음 트리거 대기 중...");
    }
}
