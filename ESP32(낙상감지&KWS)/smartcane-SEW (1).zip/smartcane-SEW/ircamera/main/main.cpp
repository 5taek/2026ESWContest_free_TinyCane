/**
 * DFR1154 (OV3660) MJPEG 스트리밍 서버
 * 브라우저에서 http://<ESP32-IP>/ 접속
 */
// TEST_SKIP_MODEL_LOAD 테스트 빌드에서는 장애물/점자블록/모드전환 관련 함수들이
// 정의만 되고 안 쓰이는 상태라 -Wunused-function이 뜬다. brailblock sdkconfig를
// 그대로 가져오면서 경고가 에러로 승격돼 빌드가 막히므로, 이 파일 전체에서만 끔.
#pragma GCC diagnostic ignored "-Wunused-function"
#include <stdio.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/event_groups.h"
#include "esp_log.h"
#include "esp_camera.h"
#include "nvs_flash.h"
#include "esp_netif.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_http_server.h"
#include "driver/gpio.h"
#include "driver/i2c_master.h"
#include "driver/i2s_std.h"
#include "esp_http_client.h"
#include "esp_crt_bundle.h"
#include "esp_heap_caps.h"
#include "mp3dec.h"
#include "esp_partition.h"
#include "esp_timer.h"
#include "img_converters.h"
#include <math.h>
#include <ctype.h>

#include "tensorflow/lite/micro/micro_interpreter.h"
#include "tensorflow/lite/micro/micro_mutable_op_resolver.h"
#include "tensorflow/lite/micro/micro_log.h"
#include "tensorflow/lite/schema/schema_generated.h"

#include <vector>
#include <algorithm>

#include "bus_dict.h"

static const char *TAG = "ircam";

// 부팅 무한루프 원인 이분탐색용 임시 스위치.
// 1이면 모드 전환 코드(USB-CDC, 상태머신, 비디오 푸시)는 전부 그대로 돌되
// 실제 모델 로딩(obs_init/bus_det_init/bus_rec_init/bb_init, PSRAM arena 할당)만 건너뛴다.
// 원인 못 찾을 때까지 이 값만 바꿔가며 테스트. 원인 찾으면 0으로 되돌리고 이 블록 제거.
#define TEST_SKIP_MODEL_LOAD 0

// ── IR / 조도센서 ────────────────────────────────────────────────────────────
#define IR_LED_GPIO      GPIO_NUM_47   // 940nm IR LED 4개
#define ALS_I2C_ADDR     0x53          // LTR-308 (카메라 SCCB와 같은 버스)
#define ALS_I2C_PORT     1             // 카메라 로그에서 확인된 포트

#define IR_ON_LUX        15.0f         // 이보다 어두우면 IR ON
#define IR_OFF_LUX       30.0f         // 이보다 밝으면 IR OFF (히스테리시스)
#define IR_WARMUP_MS     150           // IR 켠 뒤 촬영까지 대기 (안 하면 검은 화면)

typedef enum { IR_MODE_AUTO, IR_MODE_ON, IR_MODE_OFF } ir_mode_t;

static i2c_master_dev_handle_t s_als     = NULL;
static volatile ir_mode_t      s_ir_mode = IR_MODE_AUTO;
static volatile bool           s_ir_on   = false;
static volatile float          s_lux     = -1.0f;

// ── 점자블록 검출 모델 ───────────────────────────────────────────────────────
#define BB_INPUT_SIZE   224
#define BB_ARENA_SIZE   (1200 * 1024)   // PSRAM에서 잡는다
#define BB_CONF_THRESH  0.5f
#define BB_INTERVAL_MS  2000            // 추론 주기

typedef struct {
    float cx, cy, w, h, conf;
    const char *dir;      // "left" / "center" / "right" / "none"
    int   ms;             // 추론 소요 시간
    bool  valid;
} bb_result_t;

static bb_result_t s_bb = { 0, 0, 0, 0, 0, "none", 0, false };

static tflite::MicroInterpreter *s_bb_interp = nullptr;
static TfLiteTensor             *s_bb_in     = nullptr;
static TfLiteTensor             *s_bb_out    = nullptr;
static uint8_t                  *s_bb_arena  = nullptr;

// ── 스피커 (MAX98357 I2S 앰프) ───────────────────────────────────────────────
#define SPK_BCLK_GPIO    GPIO_NUM_45
#define SPK_LRCLK_GPIO   GPIO_NUM_46
#define SPK_DIN_GPIO     GPIO_NUM_42
#define SPK_GAIN_GPIO    GPIO_NUM_41   // LOW = 15dB(최대), HIGH = 6dB
#define SPK_MODE_GPIO    GPIO_NUM_40   // LOW = shutdown, HIGH = 좌채널 재생
#define SPK_SAMPLE_RATE  24000   // 구글 TTS MP3 출력이 24kHz

static i2s_chan_handle_t s_spk = NULL;
static i2s_std_config_t  s_spk_cfg;
static SemaphoreHandle_t s_spk_lock = NULL;   // TTS 중복 재생 방지

#define WIFI_SSID "sew"
#define WIFI_PASS "shin0509"
#define WIFI_CONNECTED_BIT BIT0

static EventGroupHandle_t s_wifi_event_group;

// ── 핀맵 ──────────────────────────────────────────────────────────────────────
static const camera_config_t CAM_CFG = {
    .pin_pwdn     = -1,
    .pin_reset    = -1,
    .pin_xclk     = 5,
    .pin_sccb_sda = 8,
    .pin_sccb_scl = 9,
    .pin_d7 = 4,
    .pin_d6 = 6,
    .pin_d5 = 7,
    .pin_d4 = 14,
    .pin_d3 = 17,
    .pin_d2 = 21,
    .pin_d1 = 18,
    .pin_d0 = 16,
    .pin_vsync = 1,
    .pin_href  = 2,
    .pin_pclk  = 15,
    .xclk_freq_hz = 20000000,
    .ledc_timer   = LEDC_TIMER_0,
    .ledc_channel = LEDC_CHANNEL_0,
    // 추론 입력이 그레이스케일이라 센서에서 바로 GRAYSCALE로 받는다.
    // JPEG 디코딩이 필요 없어지고 메모리도 1/3이다.
    // 스트리밍용 JPEG는 frame2jpg()로 그때그때 만든다.
    .pixel_format = PIXFORMAT_GRAYSCALE,
    .frame_size   = FRAMESIZE_VGA,        // 640x480
    .jpeg_quality = 12,
    .fb_count     = 2,
    .fb_location  = CAMERA_FB_IN_PSRAM,
    .grab_mode    = CAMERA_GRAB_LATEST,
    .sccb_i2c_port = -1,
};

// ── IR LED ───────────────────────────────────────────────────────────────────
static void ir_gpio_init(void)
{
    gpio_config_t io = {
        .pin_bit_mask = 1ULL << IR_LED_GPIO,
        .mode         = GPIO_MODE_OUTPUT,
        .pull_up_en   = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type    = GPIO_INTR_DISABLE,
    };
    ESP_ERROR_CHECK(gpio_config(&io));
    gpio_set_level(IR_LED_GPIO, 0);
    ESP_LOGI(TAG, "IR LED GPIO%d 초기화", IR_LED_GPIO);
}

static void spk_beep(int freq_hz, int ms, float vol);   // 전방 선언
static bool tts_speak(const char *text);
static volatile bool s_wifi_ready = false;

static void ir_set(bool on)
{
    if (s_ir_on == on) return;
    s_ir_on = on;
    gpio_set_level(IR_LED_GPIO, on ? 1 : 0);
    ESP_LOGI(TAG, "IR LED %s", on ? "ON" : "OFF");

    // WiFi가 붙어 있으면 음성, 아니면 비프음으로 대체
    if (s_wifi_ready) {
        if (tts_speak(on ? "적외선 켜짐" : "적외선 꺼짐")) return;
    }
    spk_beep(on ? 1200 : 600, 120, 0.35f);
}

// ── 스피커 ───────────────────────────────────────────────────────────────────
static void spk_init(void)
{
    // GAIN / MODE 는 아날로그 전압으로 동작을 고르는 핀이라 GPIO로 직접 구동한다.
    gpio_config_t io = {
        .pin_bit_mask = (1ULL << SPK_GAIN_GPIO) | (1ULL << SPK_MODE_GPIO),
        .mode         = GPIO_MODE_OUTPUT,
        .pull_up_en   = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type    = GPIO_INTR_DISABLE,
    };
    ESP_ERROR_CHECK(gpio_config(&io));
    gpio_set_level(SPK_GAIN_GPIO, 0);   // 최대 음량
    gpio_set_level(SPK_MODE_GPIO, 1);   // 앰프 enable

    i2s_chan_config_t ch = I2S_CHANNEL_DEFAULT_CONFIG(I2S_NUM_AUTO, I2S_ROLE_MASTER);
    ESP_ERROR_CHECK(i2s_new_channel(&ch, &s_spk, NULL));

    s_spk_cfg = (i2s_std_config_t){
        .clk_cfg  = I2S_STD_CLK_DEFAULT_CONFIG(SPK_SAMPLE_RATE),
        .slot_cfg = I2S_STD_PHILIPS_SLOT_DEFAULT_CONFIG(
                        I2S_DATA_BIT_WIDTH_16BIT, I2S_SLOT_MODE_MONO),
        .gpio_cfg = {
            .mclk = I2S_GPIO_UNUSED,
            .bclk = SPK_BCLK_GPIO,
            .ws   = SPK_LRCLK_GPIO,
            .dout = SPK_DIN_GPIO,
            .din  = I2S_GPIO_UNUSED,
            .invert_flags = { false, false, false },
        },
    };
    ESP_ERROR_CHECK(i2s_channel_init_std_mode(s_spk, &s_spk_cfg));
    ESP_ERROR_CHECK(i2s_channel_enable(s_spk));

    s_spk_lock = xSemaphoreCreateMutex();
    ESP_LOGI(TAG, "스피커 I2S 초기화 (BCLK%d LRCLK%d DIN%d)",
             SPK_BCLK_GPIO, SPK_LRCLK_GPIO, SPK_DIN_GPIO);
}

/* MP3마다 샘플레이트가 다를 수 있어 재생 직전에 맞춰준다 */
static void spk_set_rate(int rate)
{
    static int cur = SPK_SAMPLE_RATE;
    if (rate == cur || rate <= 0) return;
    i2s_channel_disable(s_spk);
    s_spk_cfg.clk_cfg.sample_rate_hz = rate;
    i2s_channel_reconfig_std_clock(s_spk, &s_spk_cfg.clk_cfg);
    i2s_channel_enable(s_spk);
    cur = rate;
}

static void spk_beep(int freq_hz, int ms, float vol)
{
    if (!s_spk) return;

    const int  n_total = SPK_SAMPLE_RATE * ms / 1000;
    const int  chunk   = 256;
    int16_t    buf[chunk];
    size_t     written;
    const float amp  = 32767.0f * vol;
    const float step = 2.0f * (float)M_PI * freq_hz / SPK_SAMPLE_RATE;

    for (int i = 0; i < n_total; i += chunk) {
        int n = (n_total - i < chunk) ? (n_total - i) : chunk;
        for (int k = 0; k < n; k++) {
            // 시작·끝을 부드럽게 해 '툭' 소리 방지
            float env = 1.0f;
            int   pos = i + k;
            if (pos < 200)              env = pos / 200.0f;
            else if (pos > n_total-200) env = (n_total - pos) / 200.0f;
            buf[k] = (int16_t)(amp * env * sinf(step * pos));
        }
        i2s_channel_write(s_spk, buf, n * sizeof(int16_t), &written, 200);
    }
}

// ── TTS (구글 번역 TTS → MP3 → I2S) ─────────────────────────────────────────
// 비공식 엔드포인트라 User-Agent가 없으면 403을 돌려준다.
#define TTS_UA  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " \
                "(KHTML, like Gecko) Chrome/120.0 Safari/537.36"

static void url_encode(const char *src, char *dst, size_t dst_sz)
{
    static const char hex[] = "0123456789ABCDEF";
    size_t j = 0;
    for (size_t i = 0; src[i] && j + 4 < dst_sz; i++) {
        unsigned char c = (unsigned char)src[i];
        if (isalnum(c) || c == '-' || c == '_' || c == '.' || c == '~') {
            dst[j++] = c;
        } else {
            dst[j++] = '%';
            dst[j++] = hex[c >> 4];
            dst[j++] = hex[c & 0xF];
        }
    }
    dst[j] = '\0';
}

static bool tts_speak(const char *text)
{
    if (!s_spk || !s_spk_lock) return false;
    if (xSemaphoreTake(s_spk_lock, pdMS_TO_TICKS(3000)) != pdTRUE) return false;

    bool ok = false;

    char enc[512];
    url_encode(text, enc, sizeof(enc));

    char url[768];
    snprintf(url, sizeof(url),
             "https://translate.google.com/translate_tts"
             "?ie=UTF-8&client=tw-ob&tl=ko&q=%s", enc);

    // 버퍼는 PSRAM에 잡는다 (내부 RAM 아끼기)
    const size_t IN_SZ  = 8192;
    uint8_t *in   = (uint8_t *)heap_caps_malloc(IN_SZ, MALLOC_CAP_SPIRAM);
    int16_t *pcm  = (int16_t *)heap_caps_malloc(1152 * 2 * sizeof(int16_t),
                                                MALLOC_CAP_SPIRAM);
    HMP3Decoder dec = MP3InitDecoder();
    esp_http_client_handle_t cli = NULL;

    if (!in || !pcm || !dec) { ESP_LOGE(TAG, "TTS 메모리 부족"); goto done; }

    {
        esp_http_client_config_t cfg = {};
        cfg.url             = url;
        cfg.crt_bundle_attach = esp_crt_bundle_attach;
        cfg.timeout_ms      = 8000;
        cfg.buffer_size     = 2048;
        cli = esp_http_client_init(&cfg);
        if (!cli) goto done;
        esp_http_client_set_header(cli, "User-Agent", TTS_UA);
        esp_http_client_set_header(cli, "Referer", "https://translate.google.com/");

        if (esp_http_client_open(cli, 0) != ESP_OK) {
            ESP_LOGE(TAG, "TTS 연결 실패");
            goto done;
        }
        esp_http_client_fetch_headers(cli);
        int status = esp_http_client_get_status_code(cli);
        if (status != 200) {
            ESP_LOGE(TAG, "TTS HTTP %d", status);
            goto done;
        }
    }

    {
        int  fill = 0;
        bool eof  = false;
        while (true) {
            if (!eof && fill < (int)IN_SZ) {
                int r = esp_http_client_read(cli, (char *)in + fill, IN_SZ - fill);
                if (r > 0)      fill += r;
                else if (r == 0) eof = true;
                else             break;
            }
            if (fill == 0 && eof) { ok = true; break; }

            uint8_t *p    = in;
            int      left = fill;
            int      off  = MP3FindSyncWord(p, left);
            if (off < 0) {                       // 동기 못 찾음 → 버퍼 비우고 계속
                fill = 0;
                if (eof) { ok = true; break; }
                continue;
            }
            p    += off;
            left -= off;

            int err = MP3Decode(dec, &p, &left, pcm, 0);
            if (err) {
                if (err == ERR_MP3_INDATA_UNDERFLOW && !eof) {
                    memmove(in, p, left);        // 데이터 더 받아서 재시도
                    fill = left;
                    continue;
                }
                fill = 0;
                if (eof) { ok = true; break; }
                continue;
            }

            MP3FrameInfo fi;
            MP3GetLastFrameInfo(dec, &fi);
            spk_set_rate(fi.samprate);

            size_t written;
            i2s_channel_write(s_spk, pcm, fi.outputSamps * sizeof(int16_t),
                              &written, 1000);

            memmove(in, p, left);
            fill = left;
        }
    }

done:
    if (cli) { esp_http_client_close(cli); esp_http_client_cleanup(cli); }
    if (dec) MP3FreeDecoder(dec);
    free(in);
    free(pcm);
    xSemaphoreGive(s_spk_lock);
    if (!ok) ESP_LOGW(TAG, "TTS 실패: %s", text);
    return ok;
}

// ── LTR-308 조도센서 (카메라가 만든 I2C 버스에 얹는다) ───────────────────────
// I2C는 원래 1:N 규격이라 주소만 다르면 공존한다. 카메라 0x3C, ALS 0x53.
static esp_err_t als_write(uint8_t reg, uint8_t val)
{
    uint8_t buf[2] = { reg, val };
    return i2c_master_transmit(s_als, buf, 2, 100);
}

static esp_err_t als_read(uint8_t reg, uint8_t *dst, size_t len)
{
    return i2c_master_transmit_receive(s_als, &reg, 1, dst, len, 100);
}

static bool als_init(void)
{
    i2c_master_bus_handle_t bus = NULL;
    if (i2c_master_get_bus_handle(ALS_I2C_PORT, &bus) != ESP_OK || !bus) {
        ESP_LOGW(TAG, "I2C 버스 핸들 획득 실패 → 조도센서 없이 동작");
        return false;
    }

    i2c_device_config_t dev = {
        .dev_addr_length = I2C_ADDR_BIT_LEN_7,
        .device_address  = ALS_I2C_ADDR,
        .scl_speed_hz    = 100000,
        .scl_wait_us     = 0,
        .flags           = {},
    };
    if (i2c_master_bus_add_device(bus, &dev, &s_als) != ESP_OK) {
        ESP_LOGW(TAG, "조도센서 등록 실패 → 조도센서 없이 동작");
        s_als = NULL;
        return false;
    }

    // MAIN_CTRL(0x00) bit1 = ALS enable
    if (als_write(0x00, 0x02) != ESP_OK) {
        ESP_LOGW(TAG, "조도센서 응답 없음 → 조도센서 없이 동작");
        s_als = NULL;
        return false;
    }
    als_write(0x04, 0x22);   // ALS_MEAS_RATE: 18bit 해상도, 100ms 주기
    als_write(0x05, 0x01);   // ALS_GAIN: x3

    ESP_LOGI(TAG, "LTR-308 조도센서 초기화 성공");
    return true;
}

static float als_read_lux(void)
{
    if (!s_als) return -1.0f;
    uint8_t d[3];
    if (als_read(0x0D, d, 3) != ESP_OK) return -1.0f;   // ALS_DATA_0..2
    uint32_t raw = d[0] | (d[1] << 8) | ((uint32_t)(d[2] & 0x0F) << 16);
    // lux = 0.6 * raw / (gain * int_time),  gain=3, int_time=1.0 (100ms/18bit)
    return 0.6f * raw / 3.0f;
}

// ── IR 자동 제어 태스크 ──────────────────────────────────────────────────────
static void ir_task(void *arg)
{
    while (true) {
        if (s_ir_mode == IR_MODE_ON) {
            ir_set(true);
        } else if (s_ir_mode == IR_MODE_OFF) {
            ir_set(false);
        } else {
            float lux = als_read_lux();
            s_lux = lux;
            if (lux >= 0.0f) {
                if (!s_ir_on && lux < IR_ON_LUX)       ir_set(true);
                else if (s_ir_on && lux > IR_OFF_LUX)  ir_set(false);
            }
        }
        vTaskDelay(pdMS_TO_TICKS(1000));
    }
}

// ── 점자블록 모델 ────────────────────────────────────────────────────────────
/* 파티션을 flash에 매핑해 포인터처럼 쓴다. RAM 복사가 없다. */
static const void *map_partition(const char *label, size_t *out_size)
{
    const esp_partition_t *part = esp_partition_find_first(
        ESP_PARTITION_TYPE_DATA, (esp_partition_subtype_t)0x40, label);
    if (!part) {
        ESP_LOGE(TAG, "파티션 '%s' 없음", label);
        return nullptr;
    }
    const void *ptr = nullptr;
    esp_partition_mmap_handle_t h{};
    if (esp_partition_mmap(part, 0, part->size,
                           ESP_PARTITION_MMAP_DATA, &ptr, &h) != ESP_OK) {
        ESP_LOGE(TAG, "파티션 '%s' mmap 실패", label);
        return nullptr;
    }
    if (out_size) *out_size = part->size;
    return ptr;
}

// 모드 전환마다 이 arena를 해제/재할당한다 (한 번에 하나의 모델만 메모리에 있으면 되므로).
static bool bb_init(void)
{
    if (s_bb_interp) return true;  // 이미 로드돼 있으면 재사용

    size_t sz = 0;
    const void *model_data = map_partition("bbmodel", &sz);
    if (!model_data) return false;

    const tflite::Model *model = tflite::GetModel(model_data);
    if (model->version() != TFLITE_SCHEMA_VERSION) {
        ESP_LOGE(TAG, "모델 스키마 버전 불일치 (%lu)", (unsigned long)model->version());
        return false;
    }

    s_bb_arena = (uint8_t *)heap_caps_aligned_alloc(
        16, BB_ARENA_SIZE, MALLOC_CAP_SPIRAM);
    if (!s_bb_arena) {
        ESP_LOGE(TAG, "tensor arena 할당 실패 (%d bytes)", BB_ARENA_SIZE);
        return false;
    }

    // MobileNetV2 + 회귀 헤드에 필요한 연산들.
    // gray_to_rgb 전처리가 MUL/SUB/CONCAT 등을 만들 수 있어 넉넉히 등록한다.
    static tflite::MicroMutableOpResolver<16> resolver;
    resolver.AddConv2D();
    resolver.AddDepthwiseConv2D();
    resolver.AddAdd();
    resolver.AddPad();
    resolver.AddReshape();
    resolver.AddFullyConnected();
    resolver.AddLogistic();
    resolver.AddQuantize();
    resolver.AddDequantize();
    resolver.AddMul();
    resolver.AddSub();
    resolver.AddConcatenation();
    resolver.AddRelu6();
    resolver.AddMean();
    resolver.AddTranspose();
    resolver.AddStridedSlice();

    // 모드 전환 때마다 alloc/free를 반복하므로 function-local static이 아니라
    // 힙(new)에 만들어서 s_bb_interp로 들고 있어야 deinit에서 delete 가능하다.
    tflite::MicroInterpreter *interp = new tflite::MicroInterpreter(model, resolver, s_bb_arena, BB_ARENA_SIZE);
    if (interp->AllocateTensors() != kTfLiteOk) {
        ESP_LOGE(TAG, "AllocateTensors 실패 — arena 부족이거나 미지원 연산");
        delete interp;
        heap_caps_free(s_bb_arena);
        s_bb_arena = nullptr;
        return false;
    }

    s_bb_interp = interp;
    s_bb_in     = interp->input(0);
    s_bb_out    = interp->output(0);

    ESP_LOGI(TAG, "모델 로드 완료");
    ESP_LOGI(TAG, "  입력 %dx%dx%d type=%d",
             s_bb_in->dims->data[1], s_bb_in->dims->data[2],
             s_bb_in->dims->data[3], s_bb_in->type);
    ESP_LOGI(TAG, "  출력 %d개 type=%d", s_bb_out->dims->data[1], s_bb_out->type);
    ESP_LOGI(TAG, "  arena 사용 %u / %u KB",
             (unsigned)(interp->arena_used_bytes() / 1024), BB_ARENA_SIZE / 1024);
    return true;
}

static void bb_deinit(void)
{
    if (s_bb_interp) { delete s_bb_interp; s_bb_interp = nullptr; }
    if (s_bb_arena)  { heap_caps_free(s_bb_arena); s_bb_arena = nullptr; }
    s_bb_in = nullptr;
    s_bb_out = nullptr;
}

/* 640x480 그레이스케일 → 224x224, [0,1] 정규화 (bilinear) */
static void resize_gray(const uint8_t *src, int sw, int sh, float *dst, int dn)
{
    const float rx = (float)sw / dn;
    const float ry = (float)sh / dn;
    for (int y = 0; y < dn; y++) {
        float  fy = (y + 0.5f) * ry - 0.5f;
        int    y0 = (int)floorf(fy);
        float  wy = fy - y0;
        int    y1 = y0 + 1;
        if (y0 < 0) y0 = 0;
        if (y1 > sh - 1) y1 = sh - 1;

        for (int x = 0; x < dn; x++) {
            float fx = (x + 0.5f) * rx - 0.5f;
            int   x0 = (int)floorf(fx);
            float wx = fx - x0;
            int   x1 = x0 + 1;
            if (x0 < 0) x0 = 0;
            if (x1 > sw - 1) x1 = sw - 1;

            float p00 = src[y0 * sw + x0], p01 = src[y0 * sw + x1];
            float p10 = src[y1 * sw + x0], p11 = src[y1 * sw + x1];
            float top = p00 + (p01 - p00) * wx;
            float bot = p10 + (p11 - p10) * wx;
            dst[y * dn + x] = (top + (bot - top) * wy) / 255.0f;
        }
    }
}

static void bb_infer(const camera_fb_t *fb)
{
    if (!s_bb_interp || !fb) return;

    int64_t t0 = esp_timer_get_time();

    resize_gray(fb->buf, fb->width, fb->height,
                s_bb_in->data.f, BB_INPUT_SIZE);

    if (s_bb_interp->Invoke() != kTfLiteOk) {
        ESP_LOGE(TAG, "추론 실패");
        return;
    }

    const float *o = s_bb_out->data.f;
    bb_result_t r;
    r.cx   = o[0];  r.cy = o[1];
    r.w    = o[2];  r.h  = o[3];
    r.conf = o[4];
    r.ms   = (int)((esp_timer_get_time() - t0) / 1000);

    if (r.conf >= BB_CONF_THRESH) {
        r.dir   = (r.cx < 0.35f) ? "left" : (r.cx > 0.65f) ? "right" : "center";
        r.valid = true;
    } else {
        r.dir   = "none";
        r.valid = false;
    }
    s_bb = r;

    ESP_LOGI(TAG, "추론 %dms  conf=%.2f  box=(%.2f,%.2f,%.2f,%.2f)  %s",
             r.ms, r.conf, r.cx, r.cy, r.w, r.h, r.dir);
}

static void bb_task(void *arg)
{
    while (true) {
        camera_fb_t *fb = esp_camera_fb_get();
        if (fb) {
            bb_infer(fb);
            esp_camera_fb_return(fb);
        }
        vTaskDelay(pdMS_TO_TICKS(BB_INTERVAL_MS));
    }
}

// ── 버스 번호 OCR (esp32ocr 프로젝트 로직 이식, RPi 없이 카메라 직결) ─────────
// esp32ocr/main.cpp를 참고해서 새로 작성한 코드. esp32ocr 폴더 자체는 건드리지 않음.
// 카메라가 이미 그레이스케일 640x480(VGA)이라 RGB 가중합 없이 바로 읽는다.

#define BUS_ORIG_W 640
#define BUS_ORIG_H 480
#define BUS_DET_W  224
#define BUS_DET_H  224
#define BUS_GRID_SIZE 14
#define BUS_REC_H 32
#define BUS_REC_W 160

static constexpr float BUS_DET_CONF_THRES = 0.65f;
static constexpr float BUS_DET_IOU_THRES  = 0.30f;

static constexpr int kBusDetArenaSize = 3500 * 1024;
static constexpr int kBusRecArenaSize = 1024 * 1024;

static uint8_t *s_bus_det_arena = nullptr;
static uint8_t *s_bus_rec_arena = nullptr;
static tflite::MicroInterpreter *s_bus_det_interp = nullptr;
static tflite::MicroInterpreter *s_bus_rec_interp = nullptr;

static const char *BUS_CANDIDATES[] = {"937", "503", "북구2", "410"};
static const int BUS_CANDIDATES_COUNT = 4;

static char       s_bus_last_match[32] = {0};
static SemaphoreHandle_t s_bus_result_lock = NULL;

// 버스모드 매 사이클 USB-CDC 리포트용 (매칭 여부와 무관하게 매번 갱신).
static char  s_bus_report_text[64]  = {0};   // 이번 사이클에 rec이 읽은 원문 (실패시 빈 문자열)
static float s_bus_report_conf      = 0.0f;  // 이번 사이클 det box score (실패시 0)
static bool  s_bus_report_matched   = false; // 이번 사이클에 사전 후보와 매칭됐는지

// 웹 대시보드에 노출할 버스 OCR 최신 결과 (det 성공 시마다 갱신, 매칭 여부와 무관)
// 검출 사이클(0.5~2초)마다 no_det로 바로 꺼지면 폰 화면에서 거의 안 보이므로,
// 마지막 성공 후 BUS_STICKY_US 동안은 valid를 유지한다 (sticky).
static constexpr int64_t BUS_STICKY_US = 2 * 1000000;  // 2초

struct bus_result_t {
    bool    valid = false;
    float   cx = 0, cy = 0, w = 0, h = 0;   // 0~1 정규화 좌표
    float   conf = 0;
    char    text[64]  = {0};                // rec 원본 인식 결과
    char    match[32] = {0};                // 후보지 매칭 결과 (없으면 빈 문자열)
    int     ms = 0;
    int64_t last_success_us = 0;            // 마지막으로 det 성공한 시각
};
static bus_result_t s_bus_result;

struct BusBox {
    int x1, y1, x2, y2;
    float score;
};

// ---- DET 입력 전처리: 640x480 그레이스케일 -> 224x224 INT8 ----
static void bus_prepare_det_input(const uint8_t *src, int8_t *dst, float in_scale, int32_t in_zp) {
    for (int oy = 0; oy < BUS_DET_H; oy++) {
        float sy = (oy + 0.5f) * BUS_ORIG_H / BUS_DET_H - 0.5f;
        int y0 = std::max(0, static_cast<int>(std::floor(sy)));
        int y1 = std::min(BUS_ORIG_H - 1, y0 + 1);
        float fy = sy - y0;

        for (int ox = 0; ox < BUS_DET_W; ox++) {
            float sx = (ox + 0.5f) * BUS_ORIG_W / BUS_DET_W - 0.5f;
            int x0 = std::max(0, static_cast<int>(std::floor(sx)));
            int x1 = std::min(BUS_ORIG_W - 1, x0 + 1);
            float fx = sx - x0;

            auto get_gray = [&](int y, int x) -> float {
                return src[y * BUS_ORIG_W + x] / 255.0f;
            };

            float top    = get_gray(y0, x0) + (get_gray(y0, x1) - get_gray(y0, x0)) * fx;
            float bottom = get_gray(y1, x0) + (get_gray(y1, x1) - get_gray(y1, x0)) * fx;
            float val    = top + (bottom - top) * fy;

            int32_t q = static_cast<int32_t>(std::round(val / in_scale)) + in_zp;
            q = std::clamp<int32_t>(q, -128, 127);

            dst[oy * BUS_DET_W + ox] = static_cast<int8_t>(q);
        }
    }
}

// ---- REC 입력 전처리: det 박스로 크롭 -> 32x160, 비율유지+검정패딩 ----
static void bus_prepare_rec_input(const uint8_t *src, int bx1, int by1, int bx2, int by2, float *dst) {
    int bw = std::max(1, bx2 - bx1 + 1);
    int bh = std::max(1, by2 - by1 + 1);

    for (int i = 0; i < BUS_REC_H * BUS_REC_W; i++) {
        dst[i] = -1.0f;  // (0/255 - 0.5) / 0.5 = -1.0 (검정 패딩)
    }

    float scale = (float)BUS_REC_H / (float)bh;
    int target_w = static_cast<int>(std::round(bw * scale));
    if (target_w > BUS_REC_W) target_w = BUS_REC_W;
    if (target_w < 1) target_w = 1;

    auto get_gray = [&](int y, int x) -> float {
        return src[y * BUS_ORIG_W + x] / 255.0f;
    };

    for (int oy = 0; oy < BUS_REC_H; oy++) {
        float sy = by1 + (oy + 0.5f) * bh / (float)BUS_REC_H - 0.5f;
        int y0 = std::max(by1, std::min(by2, static_cast<int>(std::floor(sy))));
        int y1 = std::min(by2, y0 + 1);
        float fy = sy - y0;

        for (int ox = 0; ox < target_w; ox++) {
            float sx = bx1 + (ox + 0.5f) * bw / (float)target_w - 0.5f;
            int x0 = std::max(bx1, std::min(bx2, static_cast<int>(std::floor(sx))));
            int x1 = std::min(bx2, x0 + 1);
            float fx = sx - x0;

            float top    = get_gray(y0, x0) + (get_gray(y0, x1) - get_gray(y0, x0)) * fx;
            float bottom = get_gray(y1, x0) + (get_gray(y1, x1) - get_gray(y1, x0)) * fx;
            float val    = top + (bottom - top) * fy;

            dst[oy * BUS_REC_W + ox] = (val - 0.5f) / 0.5f;
        }
    }
}

static float bus_compute_iou(const BusBox &a, const BusBox &b) {
    int ix1 = std::max(a.x1, b.x1), iy1 = std::max(a.y1, b.y1);
    int ix2 = std::min(a.x2, b.x2), iy2 = std::min(a.y2, b.y2);
    int iw = std::max(0, ix2 - ix1 + 1), ih = std::max(0, iy2 - iy1 + 1);
    float inter = iw * ih;
    float area_a = (a.x2 - a.x1 + 1) * (a.y2 - a.y1 + 1);
    float area_b = (b.x2 - b.x1 + 1) * (b.y2 - b.y1 + 1);
    return inter / (area_a + area_b - inter + 1e-6f);
}

static void bus_ctc_greedy_decode(const float *logits, int T, int C, char *out_str, size_t out_cap) {
    int prev = -1;
    size_t pos = 0;
    out_str[0] = '\0';

    for (int t = 0; t < T; t++) {
        const float *row = logits + t * C;
        int best = 0;
        float best_v = row[0];
        for (int c = 1; c < C; c++) {
            if (row[c] > best_v) { best_v = row[c]; best = c; }
        }
        if (best != prev && best != 0) {
            const char *ch = idx2char(best);
            if (ch) {
                size_t len = strlen(ch);
                if (pos + len < out_cap - 1) {
                    memcpy(out_str + pos, ch, len);
                    pos += len;
                    out_str[pos] = '\0';
                }
            }
        }
        prev = best;
    }
}

static const char *bus_match_candidate(const char *rec_text) {
    for (int i = 0; i < BUS_CANDIDATES_COUNT; i++) {
        if (strcmp(rec_text, BUS_CANDIDATES[i]) == 0) return BUS_CANDIDATES[i];
    }
    return nullptr;
}

// 모드 전환마다 init/deinit으로 arena를 잡았다 놓는다 (한 번에 하나의 모델만 메모리에).
static bool bus_det_init(const void *model_ptr) {
    if (s_bus_det_interp) return true;  // 이미 로드됨

    s_bus_det_arena = (uint8_t *)heap_caps_aligned_alloc(16, kBusDetArenaSize, MALLOC_CAP_SPIRAM);
    if (!s_bus_det_arena) { ESP_LOGE(TAG, "버스 det arena 할당 실패"); return false; }

    const tflite::Model *model = tflite::GetModel(model_ptr);

    static tflite::MicroMutableOpResolver<20> resolver;
    static bool resolver_init = false;
    if (!resolver_init) {
        resolver.AddConv2D();
        resolver.AddDepthwiseConv2D();
        resolver.AddAdd();
        resolver.AddMul();
        resolver.AddRelu();
        resolver.AddRelu6();
        resolver.AddReshape();
        resolver.AddQuantize();
        resolver.AddDequantize();
        resolver.AddHardSwish();
        resolver.AddConcatenation();
        resolver.AddLogistic();
        resolver_init = true;
    }

    tflite::MicroInterpreter *interpreter = new tflite::MicroInterpreter(model, resolver, s_bus_det_arena, kBusDetArenaSize);
    if (interpreter->AllocateTensors() != kTfLiteOk) {
        ESP_LOGE(TAG, "버스 det AllocateTensors 실패");
        delete interpreter;
        heap_caps_free(s_bus_det_arena);
        s_bus_det_arena = nullptr;
        return false;
    }
    s_bus_det_interp = interpreter;
    return true;
}

static void bus_det_deinit(void) {
    if (s_bus_det_interp) { delete s_bus_det_interp; s_bus_det_interp = nullptr; }
    if (s_bus_det_arena)  { heap_caps_free(s_bus_det_arena); s_bus_det_arena = nullptr; }
}

static bool bus_run_det(const void *model_ptr, const uint8_t *orig_img, BusBox *out_box) {
    if (!bus_det_init(model_ptr)) return false;

    TfLiteTensor *input  = s_bus_det_interp->input(0);
    TfLiteTensor *output = s_bus_det_interp->output(0);

    bus_prepare_det_input(orig_img, input->data.int8, input->params.scale, input->params.zero_point);

    if (s_bus_det_interp->Invoke() != kTfLiteOk) { ESP_LOGE(TAG, "버스 det Invoke 실패"); return false; }

    float out_scale = output->params.scale;
    int32_t out_zp   = output->params.zero_point;
    const int8_t *raw_out = output->data.int8;

    std::vector<BusBox> candidates;
    candidates.reserve(BUS_GRID_SIZE * BUS_GRID_SIZE);

    for (int gy = 0; gy < BUS_GRID_SIZE; gy++) {
        for (int gx = 0; gx < BUS_GRID_SIZE; gx++) {
            int base = (gy * BUS_GRID_SIZE + gx) * 5;
            float dx   = (raw_out[base + 0] - out_zp) * out_scale;
            float dy   = (raw_out[base + 1] - out_zp) * out_scale;
            float bw   = (raw_out[base + 2] - out_zp) * out_scale;
            float bh   = (raw_out[base + 3] - out_zp) * out_scale;
            float conf = (raw_out[base + 4] - out_zp) * out_scale;

            if (conf >= BUS_DET_CONF_THRES && bw <= 0.40f && bh <= 0.40f) {
                float cx = (gx + dx) / (float)BUS_GRID_SIZE;
                float cy = (gy + dy) / (float)BUS_GRID_SIZE;

                BusBox b;
                b.x1 = std::max(0, (int)((cx - bw / 2.0f) * BUS_ORIG_W));
                b.y1 = std::max(0, (int)((cy - bh / 2.0f) * BUS_ORIG_H));
                b.x2 = std::min(BUS_ORIG_W - 1, (int)((cx + bw / 2.0f) * BUS_ORIG_W));
                b.y2 = std::min(BUS_ORIG_H - 1, (int)((cy + bh / 2.0f) * BUS_ORIG_H));
                b.score = conf;
                candidates.push_back(b);
            }
        }
    }

    if (candidates.empty()) return false;

    std::sort(candidates.begin(), candidates.end(),
              [](const BusBox &a, const BusBox &b) { return a.score > b.score; });

    std::vector<bool> suppressed(candidates.size(), false);
    std::vector<BusBox> nms_results;
    for (size_t i = 0; i < candidates.size(); i++) {
        if (suppressed[i]) continue;
        nms_results.push_back(candidates[i]);
        for (size_t j = i + 1; j < candidates.size(); j++) {
            if (suppressed[j]) continue;
            if (bus_compute_iou(candidates[i], candidates[j]) > BUS_DET_IOU_THRES) suppressed[j] = true;
        }
    }

    if (nms_results.empty()) return false;
    *out_box = nms_results[0];
    return true;
}

static bool bus_rec_init(const void *model_ptr) {
    if (s_bus_rec_interp) return true;

    s_bus_rec_arena = (uint8_t *)heap_caps_aligned_alloc(16, kBusRecArenaSize, MALLOC_CAP_SPIRAM);
    if (!s_bus_rec_arena) { ESP_LOGE(TAG, "버스 rec arena 할당 실패"); return false; }

    const tflite::Model *model = tflite::GetModel(model_ptr);

    static tflite::MicroMutableOpResolver<20> resolver;
    static bool resolver_init = false;
    if (!resolver_init) {
        resolver.AddConv2D();
        resolver.AddDepthwiseConv2D();
        resolver.AddMaxPool2D();
        resolver.AddRelu();
        resolver.AddReshape();
        resolver.AddShape();
        resolver.AddStridedSlice();
        resolver.AddPack();
        resolver.AddQuantize();
        resolver.AddDequantize();
        resolver_init = true;
    }

    tflite::MicroInterpreter *interpreter = new tflite::MicroInterpreter(model, resolver, s_bus_rec_arena, kBusRecArenaSize);
    if (interpreter->AllocateTensors() != kTfLiteOk) {
        ESP_LOGE(TAG, "버스 rec AllocateTensors 실패");
        delete interpreter;
        heap_caps_free(s_bus_rec_arena);
        s_bus_rec_arena = nullptr;
        return false;
    }
    s_bus_rec_interp = interpreter;
    return true;
}

static void bus_rec_deinit(void) {
    if (s_bus_rec_interp) { delete s_bus_rec_interp; s_bus_rec_interp = nullptr; }
    if (s_bus_rec_arena)  { heap_caps_free(s_bus_rec_arena); s_bus_rec_arena = nullptr; }
}

static bool bus_run_rec(const void *model_ptr, const uint8_t *orig_img, const BusBox &box, char *out_str, size_t out_cap) {
    if (!bus_rec_init(model_ptr)) return false;

    TfLiteTensor *input  = s_bus_rec_interp->input(0);
    TfLiteTensor *output = s_bus_rec_interp->output(0);

    bus_prepare_rec_input(orig_img, box.x1, box.y1, box.x2, box.y2, input->data.f);

    if (s_bus_rec_interp->Invoke() != kTfLiteOk) { ESP_LOGE(TAG, "버스 rec Invoke 실패"); return false; }

    int T = output->dims->data[1];
    int C = output->dims->data[2];
    bus_ctc_greedy_decode(output->data.f, T, C, out_str, out_cap);
    return true;
}

static void bus_ocr_deinit(void) { bus_det_deinit(); bus_rec_deinit(); }

// 카메라 프레임버퍼는 stream_handler도 동시에 esp_camera_fb_get()으로 가져간다.
// det+rec 추론(수백 ms) 동안 fb를 들고 있으면 카메라가 다음 프레임을 못 내줘서
// 스트리밍이 그 시간만큼 멈춘다. 그래서 받자마자 복사해서 즉시 반납하고,
// 무거운 추론은 복사본으로 한다 (카메라 점유 시간을 memcpy 수준으로 최소화).
static uint8_t *s_bus_frame_copy = nullptr;

// 모드 상태머신이 버스모드 동안 반복 호출하는 단발 시도 함수.
// 후보 매칭에 성공하면 true (호출부가 그때 모드를 끝내면 됨).
static bool bus_ocr_try_once(const void *det_model, const void *rec_model) {
    if (!s_bus_frame_copy) {
        s_bus_frame_copy = (uint8_t *)heap_caps_malloc(BUS_ORIG_W * BUS_ORIG_H, MALLOC_CAP_SPIRAM);
        if (!s_bus_frame_copy) { ESP_LOGE(TAG, "버스 프레임 복사 버퍼 할당 실패"); return false; }
    }

    int64_t t0 = esp_timer_get_time();
    camera_fb_t *fb = esp_camera_fb_get();
    bool got_frame = false;
    if (fb) {
        if (fb->len == (size_t)(BUS_ORIG_W * BUS_ORIG_H)) {
            memcpy(s_bus_frame_copy, fb->buf, fb->len);
            got_frame = true;
        }
        esp_camera_fb_return(fb);  // 복사 끝났으니 카메라는 바로 반납 (스트리밍 안 막음)
    }
    if (!got_frame) {
        // 프레임을 못 받은 사이클 — 리포트 값은 갱신하지 않고 이전 값 유지
        return false;
    }

    BusBox box;
    char rec_text[64] = {0};
    bool det_ok = bus_run_det(det_model, s_bus_frame_copy, &box);
    bool rec_ok = false;
    const char *matched = nullptr;

    if (det_ok) {
        rec_ok = bus_run_rec(rec_model, s_bus_frame_copy, box, rec_text, sizeof(rec_text));
        if (rec_ok) {
            ESP_LOGI(TAG, "[버스OCR 시도] %s", rec_text[0] ? rec_text : "(empty)");
            matched = bus_match_candidate(rec_text);
            if (matched) {
                ESP_LOGI(TAG, "🚌 [버스OCR 매칭] %s", matched);
                strncpy(s_bus_last_match, matched, sizeof(s_bus_last_match) - 1);
            }
        } else {
            ESP_LOGI(TAG, "[버스OCR 시도] (rec_fail)");
        }
    } else {
        ESP_LOGI(TAG, "[버스OCR 시도] (no_det)");
    }

    // 웹 대시보드용 박스 갱신 (sticky, 마지막 성공 후 BUS_STICKY_US 유지)
    if (s_bus_result_lock && xSemaphoreTake(s_bus_result_lock, pdMS_TO_TICKS(100)) == pdTRUE) {
        int64_t now = esp_timer_get_time();
        if (det_ok) {
            s_bus_result.last_success_us = now;
            s_bus_result.cx   = (box.x1 + box.x2) / 2.0f / BUS_ORIG_W;
            s_bus_result.cy   = (box.y1 + box.y2) / 2.0f / BUS_ORIG_H;
            s_bus_result.w    = (box.x2 - box.x1) / (float)BUS_ORIG_W;
            s_bus_result.h    = (box.y2 - box.y1) / (float)BUS_ORIG_H;
            s_bus_result.conf = box.score;
            strncpy(s_bus_result.text, rec_ok ? rec_text : "", sizeof(s_bus_result.text) - 1);
            s_bus_result.text[sizeof(s_bus_result.text) - 1] = '\0';
            strncpy(s_bus_result.match, matched ? matched : "", sizeof(s_bus_result.match) - 1);
            s_bus_result.match[sizeof(s_bus_result.match) - 1] = '\0';
        }
        s_bus_result.valid = (now - s_bus_result.last_success_us) < BUS_STICKY_US;
        if (!s_bus_result.valid) {
            s_bus_result.text[0]  = '\0';
            s_bus_result.match[0] = '\0';
        }
        s_bus_result.ms = (int)((esp_timer_get_time() - t0) / 1000);
        xSemaphoreGive(s_bus_result_lock);
    }

    // 매 사이클 USB-CDC 리포트 갱신 — 매칭 여부와 무관하게 이번에 읽은 값을 그대로 반영.
    strncpy(s_bus_report_text, rec_ok ? rec_text : "", sizeof(s_bus_report_text) - 1);
    s_bus_report_text[sizeof(s_bus_report_text) - 1] = '\0';
    s_bus_report_conf    = det_ok ? box.score : 0.0f;
    s_bus_report_matched = (matched != nullptr);

    return matched != nullptr;
}

// ── 장애물감지 (SSD, smartcane 프로젝트 model_inference_ssd.cc 로직 이식) ──────
// smartcane 폴더 자체는 건드리지 않음. RPi에서 이미지를 당겨받던 부분만 빼고
// ircamera 자체 카메라 프레임을 직접 넣도록 바꿈. 후처리(softmax+NMS+박스디코딩)는
// torchvision SSD BoxCoder 수식 그대로 유지 (smartcane 쪽 주석의 경고사항 동일 적용).
#include "ssd_anchors.h"   // smartcane/main/ssd_anchors.h 복사본 (1602개 앵커)

#define OBS_INPUT_W 224
#define OBS_INPUT_H 224
#define OBS_NUM_CLASSES 5   // 배경(0) + 자전거/킥보드/볼라드/사람(1~4)

static constexpr size_t kObsArenaSize   = 6 * 1024 * 1024;
static constexpr float  kObsConfThres   = 0.30f;
static constexpr float  kObsNmsIou      = 0.45f;
static constexpr float  kObsBoxWeightXY = 10.0f;
static constexpr float  kObsBoxWeightWH = 5.0f;
static constexpr int    kObsMaxCandidates = 96;

static const char *OBS_CLASS_NAMES[] = {"자전거", "킥보드", "볼라드", "사람"};

static uint8_t *s_obs_arena = nullptr;
static tflite::MicroInterpreter *s_obs_interp = nullptr;
static TfLiteTensor *s_obs_input    = nullptr;
static TfLiteTensor *s_obs_bbox_out = nullptr;
static TfLiteTensor *s_obs_cls_out  = nullptr;

struct ObsCandidate { int class_id; float score; float x1, y1, x2, y2; float cx; };
static ObsCandidate s_obs_candidates[kObsMaxCandidates];

struct obs_result_t {
    bool  valid = false;
    int   class_id = -1;       // 0~3
    float score = 0;
    float x1 = 0, y1 = 0, x2 = 0, y2 = 0, cx = 0;
    int   direction = 1;       // 0=left 1=center 2=right
};
static obs_result_t s_obs_result;

static void obs_deinit(void) {
    if (s_obs_interp) { delete s_obs_interp; s_obs_interp = nullptr; }
    if (s_obs_arena)  { heap_caps_free(s_obs_arena); s_obs_arena = nullptr; }
    s_obs_input = s_obs_bbox_out = s_obs_cls_out = nullptr;
}

static bool obs_configure_ops(tflite::MicroMutableOpResolver<32> *r) {
    return r->AddConv2D() == kTfLiteOk &&
           r->AddDepthwiseConv2D() == kTfLiteOk &&
           r->AddAdd() == kTfLiteOk &&
           r->AddMul() == kTfLiteOk &&
           r->AddSub() == kTfLiteOk &&
           r->AddConcatenation() == kTfLiteOk &&
           r->AddAveragePool2D() == kTfLiteOk &&
           r->AddMaxPool2D() == kTfLiteOk &&
           r->AddFullyConnected() == kTfLiteOk &&
           r->AddReshape() == kTfLiteOk &&
           r->AddPad() == kTfLiteOk &&
           r->AddPadV2() == kTfLiteOk &&
           r->AddLogistic() == kTfLiteOk &&
           r->AddSoftmax() == kTfLiteOk &&
           r->AddQuantize() == kTfLiteOk &&
           r->AddDequantize() == kTfLiteOk &&
           r->AddTransposeConv() == kTfLiteOk &&
           r->AddTranspose() == kTfLiteOk &&
           r->AddSlice() == kTfLiteOk &&
           r->AddHardSwish() == kTfLiteOk &&
           r->AddRelu() == kTfLiteOk &&
           r->AddRelu6() == kTfLiteOk &&
           r->AddMean() == kTfLiteOk &&
           r->AddResizeNearestNeighbor() == kTfLiteOk;
}

static bool obs_init(const void *model_ptr) {
    if (s_obs_interp) return true;  // 이미 로드됨

    s_obs_arena = (uint8_t *)heap_caps_malloc(kObsArenaSize, MALLOC_CAP_SPIRAM);
    if (!s_obs_arena) { ESP_LOGE(TAG, "장애물 arena(%uB) 할당 실패", (unsigned)kObsArenaSize); return false; }

    const tflite::Model *model = tflite::GetModel(model_ptr);

    static tflite::MicroMutableOpResolver<32> resolver;
    static bool resolver_ready = false;
    if (!resolver_ready) {
        if (!obs_configure_ops(&resolver)) {
            ESP_LOGE(TAG, "장애물 op resolver 구성 실패");
            heap_caps_free(s_obs_arena); s_obs_arena = nullptr;
            return false;
        }
        resolver_ready = true;
    }

    tflite::MicroInterpreter *interp = new tflite::MicroInterpreter(model, resolver, s_obs_arena, kObsArenaSize);
    if (interp->AllocateTensors() != kTfLiteOk) {
        ESP_LOGE(TAG, "장애물 AllocateTensors 실패");
        delete interp;
        heap_caps_free(s_obs_arena); s_obs_arena = nullptr;
        return false;
    }

    s_obs_interp = interp;
    s_obs_input  = interp->input(0);
    for (size_t i = 0; i < interp->outputs_size(); i++) {
        TfLiteTensor *out = interp->output(i);
        if (!out || !out->dims || out->dims->size < 1) continue;
        int last = out->dims->data[out->dims->size - 1];
        if (last == 4) s_obs_bbox_out = out;
        else if (last == OBS_NUM_CLASSES) s_obs_cls_out = out;
    }
    if (!s_obs_bbox_out || !s_obs_cls_out) {
        ESP_LOGE(TAG, "장애물 출력 텐서(bbox/cls) 식별 실패");
        obs_deinit();
        return false;
    }
    if (s_obs_input->type != kTfLiteInt8) {
        ESP_LOGE(TAG, "장애물 입력이 int8이 아님 (type=%d)", (int)s_obs_input->type);
        obs_deinit();
        return false;
    }

    ESP_LOGI(TAG, "장애물 모델 로드 완료 | arena %uKB 중 %uKB 사용",
             (unsigned)(kObsArenaSize / 1024), (unsigned)(interp->arena_used_bytes() / 1024));
    return true;
}

// 640x480 그레이스케일 → 224x224 int8 양자화 (bilinear, 버스 det 전처리와 동일한 방식)
static void obs_prepare_input(const uint8_t *src, int8_t *dst, float in_scale, int32_t in_zp) {
    for (int oy = 0; oy < OBS_INPUT_H; oy++) {
        float sy = (oy + 0.5f) * BUS_ORIG_H / OBS_INPUT_H - 0.5f;
        int y0 = std::max(0, (int)floorf(sy));
        int y1 = std::min(BUS_ORIG_H - 1, y0 + 1);
        float fy = sy - y0;

        for (int ox = 0; ox < OBS_INPUT_W; ox++) {
            float sx = (ox + 0.5f) * BUS_ORIG_W / OBS_INPUT_W - 0.5f;
            int x0 = std::max(0, (int)floorf(sx));
            int x1 = std::min(BUS_ORIG_W - 1, x0 + 1);
            float fx = sx - x0;

            auto g = [&](int y, int x) -> float { return src[y * BUS_ORIG_W + x] / 255.0f; };
            float top = g(y0, x0) + (g(y0, x1) - g(y0, x0)) * fx;
            float bot = g(y1, x0) + (g(y1, x1) - g(y1, x0)) * fx;
            float val = top + (bot - top) * fy;

            int32_t q = (int32_t)lroundf(val / in_scale) + in_zp;
            q = std::max<int32_t>(-128, std::min<int32_t>(127, q));
            dst[oy * OBS_INPUT_W + ox] = (int8_t)q;
        }
    }
}

static inline float obs_read_bbox(int a, int k) {
    int idx = a * 4 + k;
    if (s_obs_bbox_out->type == kTfLiteFloat32) return s_obs_bbox_out->data.f[idx];
    return ((float)s_obs_bbox_out->data.int8[idx] - s_obs_bbox_out->params.zero_point) * s_obs_bbox_out->params.scale;
}
static inline float obs_read_cls(int a, int c) {
    int idx = a * OBS_NUM_CLASSES + c;
    if (s_obs_cls_out->type == kTfLiteFloat32) return s_obs_cls_out->data.f[idx];
    return ((float)s_obs_cls_out->data.int8[idx] - s_obs_cls_out->params.zero_point) * s_obs_cls_out->params.scale;
}

static float obs_iou(const ObsCandidate &a, const ObsCandidate &b) {
    float l = std::max(a.x1, b.x1), t = std::max(a.y1, b.y1);
    float r = std::min(a.x2, b.x2), bo = std::min(a.y2, b.y2);
    float w = std::max(0.0f, r - l), h = std::max(0.0f, bo - t);
    float inter = w * h;
    float ua = std::max(0.0f, a.x2 - a.x1) * std::max(0.0f, a.y2 - a.y1);
    float ub = std::max(0.0f, b.x2 - b.x1) * std::max(0.0f, b.y2 - b.y1);
    float uni = ua + ub - inter;
    return uni <= 0.0f ? 0.0f : inter / uni;
}

// 0=왼쪽 1=중앙 2=오른쪽
static int obs_direction(float cx) {
    if (cx < 0.33f) return 0;
    if (cx < 0.66f) return 1;
    return 2;
}

// 추론 1회 (단발 호출용). 결과는 s_obs_result에 반영.
static bool obs_run_once(const uint8_t *orig_img) {
    if (!s_obs_interp) return false;

    obs_prepare_input(orig_img, s_obs_input->data.int8, s_obs_input->params.scale, s_obs_input->params.zero_point);
    if (s_obs_interp->Invoke() != kTfLiteOk) { ESP_LOGE(TAG, "장애물 Invoke 실패"); return false; }

    const float kLogitMargin = logf(kObsConfThres / (1.0f - kObsConfThres));
    int cand_count = 0;

    for (int a = 0; a < SSD_ANCHOR_COUNT; a++) {
        float logit_bg = obs_read_cls(a, 0);
        float max_fg = -1e30f;
        for (int c = 1; c < OBS_NUM_CLASSES; c++) {
            float l = obs_read_cls(a, c);
            if (l > max_fg) max_fg = l;
        }
        if ((max_fg - logit_bg) < kLogitMargin) continue;

        float probs[OBS_NUM_CLASSES];
        float max_logit = -1e30f;
        for (int c = 0; c < OBS_NUM_CLASSES; c++) { probs[c] = obs_read_cls(a, c); if (probs[c] > max_logit) max_logit = probs[c]; }
        float sum_exp = 0.0f;
        for (int c = 0; c < OBS_NUM_CLASSES; c++) { probs[c] = expf(probs[c] - max_logit); sum_exp += probs[c]; }

        for (int c = 1; c < OBS_NUM_CLASSES; c++) {
            float score = probs[c] / sum_exp;
            if (score < kObsConfThres || cand_count >= kObsMaxCandidates) continue;

            float ax = ssd_anchors[a][0], ay = ssd_anchors[a][1];
            float aw = ssd_anchors[a][2], ah = ssd_anchors[a][3];
            float dx = obs_read_bbox(a, 0) / kObsBoxWeightXY;
            float dy = obs_read_bbox(a, 1) / kObsBoxWeightXY;
            float dw = obs_read_bbox(a, 2) / kObsBoxWeightWH;
            float dh = obs_read_bbox(a, 3) / kObsBoxWeightWH;
            float pcx = ax + dx * aw, pcy = ay + dy * ah;
            float pw = aw * expf(dw), ph = ah * expf(dh);

            ObsCandidate &cd = s_obs_candidates[cand_count++];
            cd.class_id = c - 1;
            cd.score = score;
            cd.x1 = std::max(0.0f, std::min(1.0f, pcx - pw / 2));
            cd.y1 = std::max(0.0f, std::min(1.0f, pcy - ph / 2));
            cd.x2 = std::max(0.0f, std::min(1.0f, pcx + pw / 2));
            cd.y2 = std::max(0.0f, std::min(1.0f, pcy + ph / 2));
            cd.cx = std::max(0.0f, std::min(1.0f, pcx));
        }
    }

    // 점수 내림차순 정렬 + NMS (smartcane과 동일, 후보 최대 96개라 선택정렬로 충분)
    for (int i = 0; i < cand_count - 1; i++) {
        int best = i;
        for (int j = i + 1; j < cand_count; j++) if (s_obs_candidates[j].score > s_obs_candidates[best].score) best = j;
        if (best != i) { ObsCandidate tmp = s_obs_candidates[i]; s_obs_candidates[i] = s_obs_candidates[best]; s_obs_candidates[best] = tmp; }
    }
    bool suppressed[kObsMaxCandidates] = {false};
    int kept = 0;
    for (int i = 0; i < cand_count; i++) {
        if (suppressed[i]) continue;
        if (kept != i) s_obs_candidates[kept] = s_obs_candidates[i];
        ObsCandidate sel = s_obs_candidates[kept];
        kept++;
        for (int j = i + 1; j < cand_count; j++) {
            if (suppressed[j] || s_obs_candidates[j].class_id != sel.class_id) continue;
            if (obs_iou(sel, s_obs_candidates[j]) > kObsNmsIou) suppressed[j] = true;
        }
    }

    obs_result_t r;
    if (kept > 0) {
        const ObsCandidate &best = s_obs_candidates[0];
        r.valid = true;
        r.class_id = best.class_id;
        r.score = best.score;
        r.x1 = best.x1; r.y1 = best.y1; r.x2 = best.x2; r.y2 = best.y2; r.cx = best.cx;
        r.direction = obs_direction(best.cx);
        ESP_LOGI(TAG, "[장애물] %s score=%.2f dir=%d", OBS_CLASS_NAMES[best.class_id], best.score, r.direction);
    } else {
        ESP_LOGI(TAG, "[장애물] 탐지 없음");
    }
    s_obs_result = r;
    return kept > 0;
}

// ── RPi ttyACM1 USB-CDC 프로토콜 + 모드 상태머신 ──────────────────────────────
// RPi -> ESP32 : 1바이트 명령. 0x01=버스모드 진입, 0x02=점자블록모드 진입.
//                (아무것도 안 보내면 계속 장애물모드 유지/복귀)
// ESP32 -> RPi : 결과 패킷. 첫 바이트로 종류 구분.
//   0xB0 장애물 [object_code 1B][direction_code 1B][conf0-100 1B]
//       object_code: 0x01자전거 0x02킥보드 0x03볼라드 0x04사람 0x05미상
//       direction_code: 0x01왼쪽 0x02중앙 0x03오른쪽
//   0xB1 버스   [len 1B][번호 텍스트 len바이트][conf0-100 1B][matched 1B(0/1)]
//       matched=0: 아직 사전 후보와 미매칭(진행중 추정값), 1: 사전 매칭 확정(버스모드 종료)
//   0xB2 점자블록 [있음여부 1B(0/1)][conf0-100 1B][근접여부 1B(0/1)]
#include "driver/usb_serial_jtag.h"

#define MODE_CMD_BUS     0x01
#define MODE_CMD_BRAILLE 0x02

#define RESULT_MSG_OBSTACLE 0xB0
#define RESULT_MSG_BUS       0xB1
#define RESULT_MSG_BRAILLE    0xB2

enum class CaneMode { OBSTACLE, BUS, BRAILLE };
static CaneMode s_mode = CaneMode::OBSTACLE;
static int64_t  s_mode_enter_us = 0;

static constexpr int64_t kBusModeTimeoutUs     = 30LL * 1000000;
static constexpr int64_t kBrailleModeTimeoutUs = 5LL  * 1000000;

static const void *s_obs_model     = nullptr;
static const void *s_bus_det_model = nullptr;
static const void *s_bus_rec_model = nullptr;

static void usb_cdc_init(void) {
    usb_serial_jtag_driver_config_t cfg = USB_SERIAL_JTAG_DRIVER_CONFIG_DEFAULT();
    usb_serial_jtag_driver_install(&cfg);
}

static void usb_cdc_write(const void *data, size_t len) {
    usb_serial_jtag_write_bytes((const uint8_t *)data, len, pdMS_TO_TICKS(1000));
    usb_serial_jtag_wait_tx_done(pdMS_TO_TICKS(1000));
}

// 논블로킹: 명령 1바이트 와 있으면 true
static bool usb_cdc_poll_cmd(uint8_t *out_cmd) {
    uint8_t b;
    int n = usb_serial_jtag_read_bytes(&b, 1, 0);
    if (n == 1) { *out_cmd = b; return true; }
    return false;
}

static void send_obstacle_result(void) {
    uint8_t object_code = 0x05, dir_code = 0x02, conf100 = 0;
    if (s_obs_result.valid) {
        object_code = (uint8_t)(s_obs_result.class_id + 1);     // 1~4
        dir_code    = (uint8_t)(s_obs_result.direction + 1);     // 1~3
        conf100     = (uint8_t)(s_obs_result.score * 100.0f);
    }
    uint8_t pkt[4] = { RESULT_MSG_OBSTACLE, object_code, dir_code, conf100 };
    usb_cdc_write(pkt, sizeof(pkt));
}

static void send_bus_result(const char *text, float conf, bool matched) {
    uint8_t len = (uint8_t)strnlen(text, 31);
    uint8_t conf100 = (uint8_t)(conf * 100.0f);
    uint8_t pkt[2 + 31 + 2];
    pkt[0] = RESULT_MSG_BUS;
    pkt[1] = len;
    memcpy(pkt + 2, text, len);
    pkt[2 + len]     = conf100;
    pkt[2 + len + 1] = (uint8_t)(matched ? 1 : 0);
    usb_cdc_write(pkt, 2 + len + 2);
}

static void send_braille_result(bool present, float conf, bool near) {
    uint8_t pkt[4] = { RESULT_MSG_BRAILLE, (uint8_t)(present ? 1 : 0),
                        (uint8_t)(conf * 100.0f), (uint8_t)(near ? 1 : 0) };
    usb_cdc_write(pkt, sizeof(pkt));
}

static void enter_mode(CaneMode m) {
    // 한 번에 하나의 모델만 메모리에 있으면 되므로, 새 모드에 필요없는 건 다 내린다.
    if (m != CaneMode::OBSTACLE) obs_deinit();
    if (m != CaneMode::BUS)      { bus_det_deinit(); bus_rec_deinit(); }
    if (m != CaneMode::BRAILLE)  bb_deinit();

#if !TEST_SKIP_MODEL_LOAD
    if (m == CaneMode::OBSTACLE && s_obs_model)     obs_init(s_obs_model);
    if (m == CaneMode::BUS)                          { if (s_bus_det_model) bus_det_init(s_bus_det_model); if (s_bus_rec_model) bus_rec_init(s_bus_rec_model); }
    if (m == CaneMode::BRAILLE)                      bb_init();
#else
    ESP_LOGW(TAG, "[TEST_SKIP_MODEL_LOAD] 모델 로딩 건너뜀 (부팅루프 원인 이분탐색용)");
#endif

    s_mode = m;
    s_mode_enter_us = esp_timer_get_time();
    ESP_LOGI(TAG, "모드 전환 -> %s",
             m == CaneMode::OBSTACLE ? "장애물" : m == CaneMode::BUS ? "버스" : "점자블록");
}

// 예전(esp32ocr 이식 직후) 상태로 되돌리는 테스트용 태스크 — 모드 상태머신/USB-CDC/
// 장애물모델 없이, 버스 det+rec만 계속 돌면서 웹 대시보드(포트 80/81)에 박스를 올린다.
// 보드 자체가 정상 동작하는지(브라운아웃 없이 카메라+WiFi+OCR까지 도는지) 확인하는 용도.
static void bus_ocr_only_task(void *arg) {
    size_t sz = 0;
    const void *det_model = map_partition("detmodel", &sz);
    const void *rec_model = map_partition("recmodel", &sz);
    if (!det_model || !rec_model) {
        ESP_LOGE(TAG, "버스 모델 파티션 없음 — bus_ocr_only_task 종료");
        vTaskDelete(NULL);
        return;
    }
    while (true) {
        bus_ocr_try_once(det_model, rec_model);
        vTaskDelay(pdMS_TO_TICKS(500));
    }
}

static void cane_mode_task(void *arg) {
    usb_cdc_init();

    size_t sz = 0;
    s_obs_model     = map_partition("ssdmodel", &sz);
    s_bus_det_model = map_partition("detmodel", &sz);
    s_bus_rec_model = map_partition("recmodel", &sz);
    if (!s_obs_model)     ESP_LOGW(TAG, "ssdmodel 파티션 없음 — 장애물감지 비활성화");
    if (!s_bus_det_model || !s_bus_rec_model) ESP_LOGW(TAG, "버스 모델 파티션 없음 — 버스모드 비활성화");

    enter_mode(CaneMode::OBSTACLE);  // 기본 모드

    while (true) {
        uint8_t cmd;
        if (usb_cdc_poll_cmd(&cmd)) {
            if (cmd == MODE_CMD_BUS && s_mode != CaneMode::BUS) enter_mode(CaneMode::BUS);
            else if (cmd == MODE_CMD_BRAILLE && s_mode != CaneMode::BRAILLE) enter_mode(CaneMode::BRAILLE);
        }

        int64_t elapsed = esp_timer_get_time() - s_mode_enter_us;

        if (s_mode == CaneMode::OBSTACLE) {
            camera_fb_t *fb = esp_camera_fb_get();
            if (fb) {
                static uint8_t *obs_copy = nullptr;
                if (!obs_copy) obs_copy = (uint8_t *)heap_caps_malloc(BUS_ORIG_W * BUS_ORIG_H, MALLOC_CAP_SPIRAM);
                if (obs_copy && fb->len == (size_t)(BUS_ORIG_W * BUS_ORIG_H)) {
                    memcpy(obs_copy, fb->buf, fb->len);
                    esp_camera_fb_return(fb);
                    obs_run_once(obs_copy);
                    send_obstacle_result();
                } else {
                    esp_camera_fb_return(fb);
                }
            }
            vTaskDelay(pdMS_TO_TICKS(300));

        } else if (s_mode == CaneMode::BUS) {
            bool matched = bus_ocr_try_once(s_bus_det_model, s_bus_rec_model);
            // 매칭 여부와 무관하게 매 사이클 리포트 전송 — RPi는 matched 바이트로
            // "아직 진행중인 추정값"과 "사전 매칭 확정값"을 구분한다.
            send_bus_result(matched ? s_bus_last_match : s_bus_report_text,
                             s_bus_report_conf, matched);
            if (matched) {
                enter_mode(CaneMode::OBSTACLE);
            } else if (elapsed > kBusModeTimeoutUs) {
                ESP_LOGI(TAG, "버스모드 30초 타임아웃 — 장애물모드 복귀");
                enter_mode(CaneMode::OBSTACLE);
            }
            vTaskDelay(pdMS_TO_TICKS(200));

        } else { // BRAILLE
            camera_fb_t *fb = esp_camera_fb_get();
            if (fb) {
                bb_infer(fb);
                esp_camera_fb_return(fb);
            }
            if (s_bb.valid || elapsed > kBrailleModeTimeoutUs) {
                bool near = s_bb.valid && (s_bb.w * s_bb.h > 0.15f);
                send_braille_result(s_bb.valid, s_bb.conf, near);
                enter_mode(CaneMode::OBSTACLE);
            }
            vTaskDelay(pdMS_TO_TICKS(200));
        }
    }
}

// ── RPi로 영상 푸시 (박스 오버레이 JPEG, TCP push) ────────────────────────────
// 개발/테스트 단계에서는 RPi 자체 핫스팟 대신 기존 공유기 와이파이(Bitdol_5G)에
// ESP32/RPi 둘 다 붙는 방식으로 임시 변경 (디버깅 편의상). VIDEO_PUSH_IP는 RPi가
// 그 와이파이에서 DHCP로 받은 실제 IP(192.168.0.206)로 고정 — RPi 쪽 IP가
// 바뀌면 여기도 같이 바꿔야 함. 나중에 실제 배포 시 RPi 핫스팟 방식으로 되돌릴 것.
// 프레임마다 [4바이트 LE 길이][JPEG 바이트열]을 계속 보낸다.
// 현재 활성 모드의 박스(장애물/버스/점자블록)를 그레이스케일 프레임에 직접
// 그려 넣은 뒤 JPEG 인코딩해서 보낸다 (RPi 쪽에서 따로 박스를 그릴 필요 없음).
#include "lwip/sockets.h"
#include "lwip/inet.h"

#define VIDEO_PUSH_IP   "10.158.254.224"
#define VIDEO_PUSH_PORT 8090

static void draw_box_gray(uint8_t *buf, int W, int H,
                           float nx1, float ny1, float nx2, float ny2, uint8_t val) {
    int x1 = std::max(0, std::min(W - 1, (int)(nx1 * W)));
    int y1 = std::max(0, std::min(H - 1, (int)(ny1 * H)));
    int x2 = std::max(0, std::min(W - 1, (int)(nx2 * W)));
    int y2 = std::max(0, std::min(H - 1, (int)(ny2 * H)));
    if (x2 <= x1 || y2 <= y1) return;

    const int t = 3; // 테두리 두께(px)
    for (int dy = 0; dy < t; dy++) {
        if (y1 + dy < H) memset(buf + (y1 + dy) * W + x1, val, x2 - x1);
        if (y2 - dy >= 0 && y2 - dy < H) memset(buf + (y2 - dy) * W + x1, val, x2 - x1);
    }
    for (int y = y1; y <= y2 && y < H; y++) {
        for (int dx = 0; dx < t; dx++) {
            if (x1 + dx < W) buf[y * W + x1 + dx] = val;
            if (x2 - dx >= 0 && x2 - dx < W) buf[y * W + x2 - dx] = val;
        }
    }
}

static int s_video_sock = -1;

static bool video_push_connect(void) {
    if (s_video_sock >= 0) return true;

    int sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (sock < 0) return false;

    struct timeval tv = { .tv_sec = 2, .tv_usec = 0 };
    setsockopt(sock, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));

    struct sockaddr_in addr = {};
    addr.sin_family = AF_INET;
    addr.sin_port   = htons(VIDEO_PUSH_PORT);
    inet_pton(AF_INET, VIDEO_PUSH_IP, &addr.sin_addr);

    if (connect(sock, (struct sockaddr *)&addr, sizeof(addr)) != 0) {
        close(sock);
        return false;
    }
    s_video_sock = sock;
    ESP_LOGI(TAG, "영상 푸시 연결됨 (%s:%d)", VIDEO_PUSH_IP, VIDEO_PUSH_PORT);
    return true;
}

static void video_push_disconnect(void) {
    if (s_video_sock >= 0) { close(s_video_sock); s_video_sock = -1; }
}

static void video_push_task(void *arg) {
    static uint8_t *frame_copy = nullptr;
    if (!frame_copy) frame_copy = (uint8_t *)heap_caps_malloc(BUS_ORIG_W * BUS_ORIG_H, MALLOC_CAP_SPIRAM);

    while (true) {
        if (!frame_copy) { vTaskDelay(pdMS_TO_TICKS(1000)); continue; }

        if (!video_push_connect()) {
            vTaskDelay(pdMS_TO_TICKS(2000));  // RPi 연결 안 됐으면 잠시 후 재시도
            continue;
        }

        camera_fb_t *fb = esp_camera_fb_get();
        if (!fb) { vTaskDelay(pdMS_TO_TICKS(100)); continue; }
        if (fb->len != (size_t)(BUS_ORIG_W * BUS_ORIG_H)) { esp_camera_fb_return(fb); continue; }
        memcpy(frame_copy, fb->buf, fb->len);
        esp_camera_fb_return(fb);  // 복사 끝났으니 바로 반납 (다른 태스크 카메라 사용 안 막음)

        // 현재 활성 모드의 박스만 그려 넣는다
        if (s_mode == CaneMode::OBSTACLE && s_obs_result.valid) {
            draw_box_gray(frame_copy, BUS_ORIG_W, BUS_ORIG_H,
                          s_obs_result.x1, s_obs_result.y1, s_obs_result.x2, s_obs_result.y2, 255);
        } else if (s_mode == CaneMode::BUS && s_bus_result.valid) {
            draw_box_gray(frame_copy, BUS_ORIG_W, BUS_ORIG_H,
                          s_bus_result.cx - s_bus_result.w / 2, s_bus_result.cy - s_bus_result.h / 2,
                          s_bus_result.cx + s_bus_result.w / 2, s_bus_result.cy + s_bus_result.h / 2, 255);
        } else if (s_mode == CaneMode::BRAILLE && s_bb.valid) {
            draw_box_gray(frame_copy, BUS_ORIG_W, BUS_ORIG_H,
                          s_bb.cx - s_bb.w / 2, s_bb.cy - s_bb.h / 2,
                          s_bb.cx + s_bb.w / 2, s_bb.cy + s_bb.h / 2, 255);
        }

        uint8_t *jpg = nullptr;
        size_t jpg_len = 0;
        if (fmt2jpg(frame_copy, BUS_ORIG_W * BUS_ORIG_H, BUS_ORIG_W, BUS_ORIG_H,
                    PIXFORMAT_GRAYSCALE, 80, &jpg, &jpg_len)) {
            uint32_t len_le = (uint32_t)jpg_len;  // ESP32는 리틀엔디안이라 그대로 씀
            int wr1 = send(s_video_sock, &len_le, sizeof(len_le), 0);
            int wr2 = (wr1 == (int)sizeof(len_le)) ? send(s_video_sock, jpg, jpg_len, 0) : -1;
            if (wr1 != (int)sizeof(len_le) || wr2 != (int)jpg_len) {
                ESP_LOGW(TAG, "영상 푸시 전송 실패 — 재연결");
                video_push_disconnect();
            }
            free(jpg);
        }

        vTaskDelay(pdMS_TO_TICKS(200));  // 대략 5fps
    }
}

// ── WiFi 이벤트 핸들러 ──────────────────────────────────────────────────────
static void wifi_event_handler(void *arg, esp_event_base_t base,
                                int32_t id, void *data)
{
    if (base == WIFI_EVENT && id == WIFI_EVENT_STA_START) {
        esp_wifi_connect();
    } else if (base == WIFI_EVENT && id == WIFI_EVENT_STA_DISCONNECTED) {
        ESP_LOGW(TAG, "WiFi 재연결 중...");
        esp_wifi_connect();
    } else if (base == IP_EVENT && id == IP_EVENT_STA_GOT_IP) {
        ip_event_got_ip_t *e = (ip_event_got_ip_t *)data;
        ESP_LOGI(TAG, "IP 주소: " IPSTR, IP2STR(&e->ip_info.ip));
        ESP_LOGI(TAG, "브라우저에서 http://" IPSTR "/ 접속", IP2STR(&e->ip_info.ip));
        s_wifi_ready = true;
        xEventGroupSetBits(s_wifi_event_group, WIFI_CONNECTED_BIT);
    }
}

static void wifi_init(void)
{
    s_wifi_event_group = xEventGroupCreate();
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());
    esp_netif_create_default_wifi_sta();

    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));

    ESP_ERROR_CHECK(esp_event_handler_register(WIFI_EVENT, ESP_EVENT_ANY_ID,
                                               wifi_event_handler, NULL));
    ESP_ERROR_CHECK(esp_event_handler_register(IP_EVENT, IP_EVENT_STA_GOT_IP,
                                               wifi_event_handler, NULL));

    wifi_config_t wifi_cfg = {};
    strncpy((char *)wifi_cfg.sta.ssid,     WIFI_SSID, sizeof(wifi_cfg.sta.ssid));
    strncpy((char *)wifi_cfg.sta.password, WIFI_PASS, sizeof(wifi_cfg.sta.password));

    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_STA, &wifi_cfg));
    ESP_ERROR_CHECK(esp_wifi_start());

    xEventGroupWaitBits(s_wifi_event_group, WIFI_CONNECTED_BIT,
                        pdFALSE, pdTRUE, portMAX_DELAY);
}

// ── MJPEG 스트리밍 핸들러 ──────────────────────────────────────────────────
#define PART_BOUNDARY "123456789000000000000987654321"
static const char *STREAM_CONTENT_TYPE =
    "multipart/x-mixed-replace;boundary=" PART_BOUNDARY;
static const char *STREAM_BOUNDARY =
    "\r\n--" PART_BOUNDARY "\r\n";
static const char *STREAM_PART =
    "Content-Type: image/jpeg\r\nContent-Length: %u\r\n\r\n";

static esp_err_t stream_handler(httpd_req_t *req)
{
    esp_err_t res = httpd_resp_set_type(req, STREAM_CONTENT_TYPE);
    if (res != ESP_OK) return res;

    httpd_resp_set_hdr(req, "Access-Control-Allow-Origin", "*");

    // IR가 방금 켜졌다면 센서가 적응할 시간을 준다 (없으면 검은 화면)
    if (s_ir_on) vTaskDelay(pdMS_TO_TICKS(IR_WARMUP_MS));

    char part_buf[64];
    while (true) {
        camera_fb_t *fb = esp_camera_fb_get();
        if (!fb) {
            ESP_LOGE(TAG, "프레임 캡처 실패");
            res = ESP_FAIL;
            break;
        }

        // 센서가 GRAYSCALE로 주므로 전송용 JPEG는 여기서 만든다
        uint8_t *jpg = NULL;
        size_t   jpg_len = 0;
        bool     conv = frame2jpg(fb, 70, &jpg, &jpg_len);
        esp_camera_fb_return(fb);
        if (!conv) {
            ESP_LOGE(TAG, "JPEG 변환 실패");
            res = ESP_FAIL;
            break;
        }

        res = httpd_resp_send_chunk(req, STREAM_BOUNDARY, strlen(STREAM_BOUNDARY));
        if (res == ESP_OK) {
            int hlen = snprintf(part_buf, sizeof(part_buf), STREAM_PART, jpg_len);
            res = httpd_resp_send_chunk(req, part_buf, hlen);
        }
        if (res == ESP_OK) {
            res = httpd_resp_send_chunk(req, (const char *)jpg, jpg_len);
        }
        free(jpg);
        vTaskDelay(pdMS_TO_TICKS(50));   // ~20fps 상한, FB-OVF 억제
        if (res != ESP_OK) break;
    }
    return res;
}

// ── IR 제어 / 상태 엔드포인트 ────────────────────────────────────────────────
static esp_err_t ir_ctl_handler(httpd_req_t *req)
{
    const char *uri = req->uri;
    if      (strstr(uri, "/ir/on"))   s_ir_mode = IR_MODE_ON;
    else if (strstr(uri, "/ir/off"))  s_ir_mode = IR_MODE_OFF;
    else if (strstr(uri, "/ir/auto")) s_ir_mode = IR_MODE_AUTO;

    const char *mode = s_ir_mode == IR_MODE_ON   ? "on"
                     : s_ir_mode == IR_MODE_OFF  ? "off" : "auto";
    char buf[128];
    int n = snprintf(buf, sizeof(buf),
                     "{\"mode\":\"%s\",\"ir\":%s,\"lux\":%.1f}",
                     mode, s_ir_on ? "true" : "false", s_lux);
    httpd_resp_set_type(req, "application/json");
    return httpd_resp_send(req, buf, n);
}

// ── 추론 결과 JSON ───────────────────────────────────────────────────────────
static esp_err_t result_handler(httpd_req_t *req)
{
    bb_result_t r = s_bb;

    bus_result_t b;
    if (s_bus_result_lock && xSemaphoreTake(s_bus_result_lock, pdMS_TO_TICKS(100)) == pdTRUE) {
        b = s_bus_result;
        xSemaphoreGive(s_bus_result_lock);
    }

    char buf[512];
    int n = snprintf(buf, sizeof(buf),
        "{\"valid\":%s,\"cx\":%.4f,\"cy\":%.4f,\"w\":%.4f,\"h\":%.4f,"
        "\"conf\":%.4f,\"dir\":\"%s\",\"ms\":%d,\"ir\":%s,\"lux\":%.1f,"
        "\"bus_valid\":%s,\"bus_cx\":%.4f,\"bus_cy\":%.4f,\"bus_w\":%.4f,\"bus_h\":%.4f,"
        "\"bus_conf\":%.4f,\"bus_text\":\"%s\",\"bus_match\":\"%s\",\"bus_ms\":%d}",
        r.valid ? "true" : "false", r.cx, r.cy, r.w, r.h,
        r.conf, r.dir, r.ms, s_ir_on ? "true" : "false", s_lux,
        b.valid ? "true" : "false", b.cx, b.cy, b.w, b.h,
        b.conf, b.text, b.match, b.ms);
    httpd_resp_set_type(req, "application/json");
    httpd_resp_set_hdr(req, "Access-Control-Allow-Origin", "*");
    return httpd_resp_send(req, buf, n);
}

// ── 대시보드 ─────────────────────────────────────────────────────────────────
static const char DASH_HTML[] = R"HTML(<!doctype html><html><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>점자블록 검출</title><style>
body{background:#111;color:#eee;font-family:system-ui,sans-serif;margin:0;padding:16px}
h1{font-size:18px;margin:0 0 12px}
.wrap{position:relative;display:inline-block;line-height:0}
#v{width:min(90vw,640px);display:block}
#c{position:absolute;left:0;top:0;width:100%;height:100%}
.info{margin-top:12px;font-size:15px;line-height:1.9}
.k{color:#888;display:inline-block;width:88px}
.dir{font-size:32px;font-weight:700;color:#4ade80}
.off{color:#666}
</style></head><body>
<h1>점자블록 검출</h1>
<div class="wrap"><img id="v"><canvas id="c"></canvas></div>
<div class="info">
  <div class="dir" id="dir">-</div>
  <div><span class="k">신뢰도</span><span id="conf">-</span></div>
  <div><span class="k">추론 시간</span><span id="ms">-</span></div>
  <div><span class="k">박스</span><span id="box">-</span></div>
  <div><span class="k">조도 / IR</span><span id="ir">-</span></div>
</div>
<div class="info">
  <div style="color:#fb923c;font-weight:700">버스 OCR</div>
  <div><span class="k">인식결과</span><span id="busText">-</span></div>
  <div><span class="k">후보매칭</span><span id="busMatch">-</span></div>
  <div><span class="k">신뢰도</span><span id="busConf">-</span></div>
  <div><span class="k">추론 시간</span><span id="busMs">-</span></div>
</div>
<script>
const v=document.getElementById('v'),c=document.getElementById('c'),x=c.getContext('2d');
const KO={left:'왼쪽',center:'정면',right:'오른쪽',none:'검출 없음'};
// /stream은 별도 포트(81)의 서버가 처리한다 (80번 서버가 스트리밍에 안 묶이게 분리함)
v.src='http://'+location.hostname+':81/stream';
function fit(){c.width=v.clientWidth;c.height=v.clientHeight;}
v.addEventListener('load',fit);addEventListener('resize',fit);
async function tick(){
  try{
    const r=await(await fetch('/result')).json();
    document.getElementById('dir').textContent=KO[r.dir]||r.dir;
    document.getElementById('dir').className='dir'+(r.valid?'':' off');
    document.getElementById('conf').textContent=r.conf.toFixed(3);
    document.getElementById('ms').textContent=r.ms+' ms';
    document.getElementById('box').textContent=
      r.valid?`${r.cx.toFixed(2)}, ${r.cy.toFixed(2)}  ${r.w.toFixed(2)}x${r.h.toFixed(2)}`:'-';
    document.getElementById('ir').textContent=
      `${r.lux.toFixed(0)} lux / ${r.ir?'ON':'OFF'}`;
    document.getElementById('busText').textContent=r.bus_text||'-';
    document.getElementById('busMatch').textContent=r.bus_match||'-';
    document.getElementById('busConf').textContent=r.bus_valid?r.bus_conf.toFixed(3):'-';
    document.getElementById('busMs').textContent=r.bus_valid?(r.bus_ms+' ms'):'-';

    fit(); x.clearRect(0,0,c.width,c.height);
    if(r.valid){
      const X=(r.cx-r.w/2)*c.width, Y=(r.cy-r.h/2)*c.height;
      x.strokeStyle='#4ade80'; x.lineWidth=3;
      x.strokeRect(X,Y,r.w*c.width,r.h*c.height);
    }
    if(r.bus_valid){
      const BX=(r.bus_cx-r.bus_w/2)*c.width, BY=(r.bus_cy-r.bus_h/2)*c.height;
      x.strokeStyle='#fb923c'; x.lineWidth=3;
      x.strokeRect(BX,BY,r.bus_w*c.width,r.bus_h*c.height);
      if(r.bus_match) x.fillStyle='#fb923c', x.font='bold 16px sans-serif', x.fillText(r.bus_match, BX, Math.max(14,BY-6));
    }
  }catch(e){}
  setTimeout(tick,500);
}
tick();
</script></body></html>)HTML";

static esp_err_t dash_handler(httpd_req_t *req)
{
    httpd_resp_set_type(req, "text/html; charset=utf-8");
    return httpd_resp_send(req, DASH_HTML, HTTPD_RESP_USE_STRLEN);
}

static esp_err_t beep_handler(httpd_req_t *req)
{
    spk_beep(880, 200, 0.4f);
    vTaskDelay(pdMS_TO_TICKS(80));
    spk_beep(1320, 200, 0.4f);
    httpd_resp_set_type(req, "application/json");
    return httpd_resp_sendstr(req, "{\"beep\":\"ok\"}");
}

// /say?t=안녕하세요  → 아무 문장이나 음성 출력
static esp_err_t say_handler(httpd_req_t *req)
{
    char q[512] = {0}, text[400] = {0};
    if (httpd_req_get_url_query_str(req, q, sizeof(q)) == ESP_OK) {
        httpd_query_key_value(q, "t", text, sizeof(text));
    }
    if (!text[0]) strcpy(text, "안녕하세요");

    bool ok = tts_speak(text);
    httpd_resp_set_type(req, "application/json");
    char buf[64];
    int n = snprintf(buf, sizeof(buf), "{\"ok\":%s}", ok ? "true" : "false");
    return httpd_resp_send(req, buf, n);
}

// esp_http_server는 요청을 처리하는 태스크가 하나뿐이라, /stream처럼 핸들러가
// 끝없이 이어지는(MJPEG 무한루프) 요청이 하나만 들어와도 그 태스크가 거기 묶여서
// 다른 요청(/result 등)이 전부 Pending으로 무한 대기하게 된다. 그래서 스트리밍만
// 별도 포트(81)의 두 번째 httpd 인스턴스로 분리해서, 스트리밍이 오래 걸려도
// 원래 서버(80, /result·/ir·/say 등)는 계속 정상 응답하도록 한다.
static httpd_handle_t start_stream_server(void)
{
    httpd_config_t config    = HTTPD_DEFAULT_CONFIG();
    config.server_port       = 81;
    config.ctrl_port         = 32769;   // 기본 서버(80)와 ctrl 포트 충돌 방지
    config.max_uri_handlers  = 2;
    config.stack_size        = 6144;

    httpd_handle_t stream_server = NULL;
    if (httpd_start(&stream_server, &config) != ESP_OK) {
        ESP_LOGE(TAG, "스트리밍 서버(81) 시작 실패");
        return NULL;
    }

    httpd_uri_t stream_uri = {
        .uri      = "/stream",
        .method   = HTTP_GET,
        .handler  = stream_handler,
        .user_ctx = NULL,
        .is_websocket = false,
        .handle_ws_control_frames = false,
        .supported_subprotocol = NULL,
    };
    httpd_register_uri_handler(stream_server, &stream_uri);
    return stream_server;
}

static httpd_handle_t start_webserver(void)
{
    httpd_config_t config = HTTPD_DEFAULT_CONFIG();
    config.server_port      = 80;
    config.max_uri_handlers = 8;
    config.stack_size       = 8192;   // TTS 디코딩 여유
    config.uri_match_fn     = httpd_uri_match_wildcard;

    httpd_handle_t server = NULL;
    if (httpd_start(&server, &config) != ESP_OK) {
        ESP_LOGE(TAG, "HTTP 서버 시작 실패");
        return NULL;
    }

    httpd_uri_t ir_uri = {
        .uri      = "/ir/*",
        .method   = HTTP_GET,
        .handler  = ir_ctl_handler,
        .user_ctx = NULL,
        .is_websocket = false,
        .handle_ws_control_frames = false,
        .supported_subprotocol = NULL,
    };
    httpd_register_uri_handler(server, &ir_uri);

    httpd_uri_t beep_uri = {
        .uri      = "/beep",
        .method   = HTTP_GET,
        .handler  = beep_handler,
        .user_ctx = NULL,
        .is_websocket = false,
        .handle_ws_control_frames = false,
        .supported_subprotocol = NULL,
    };
    httpd_register_uri_handler(server, &beep_uri);

    httpd_uri_t say_uri = {
        .uri      = "/say",
        .method   = HTTP_GET,
        .handler  = say_handler,
        .user_ctx = NULL,
        .is_websocket = false,
        .handle_ws_control_frames = false,
        .supported_subprotocol = NULL,
    };
    httpd_register_uri_handler(server, &say_uri);

    httpd_uri_t result_uri = {
        .uri      = "/result",
        .method   = HTTP_GET,
        .handler  = result_handler,
        .user_ctx = NULL,
        .is_websocket = false,
        .handle_ws_control_frames = false,
        .supported_subprotocol = NULL,
    };
    httpd_register_uri_handler(server, &result_uri);

    httpd_uri_t dash_uri = {
        .uri      = "/",
        .method   = HTTP_GET,
        .handler  = dash_handler,
        .user_ctx = NULL,
        .is_websocket = false,
        .handle_ws_control_frames = false,
        .supported_subprotocol = NULL,
    };
    httpd_register_uri_handler(server, &dash_uri);

    start_stream_server();  // /stream은 별도 포트(81)에서 독립적으로 처리
    return server;
}

// ── 메인 ──────────────────────────────────────────────────────────────────────
extern "C" void app_main(void)
{
    ESP_ERROR_CHECK(nvs_flash_init());

#if !TEST_SKIP_MODEL_LOAD
    ir_gpio_init();
    spk_init();
#endif

    // 카메라를 먼저 초기화해야 한다. 조도센서와 I2C 버스를 공유하는데
    // 순서가 바뀌면 버스 설정이 충돌한다.
    ESP_LOGI(TAG, "카메라 초기화 중...");
    ESP_ERROR_CHECK(esp_camera_init(&CAM_CFG));
    ESP_LOGI(TAG, "카메라 초기화 성공  PID=0x%x",
             esp_camera_sensor_get()->id.PID);

    // hmirror+vflip을 같이 걸면 오히려 좌우반전이 생겨서, vflip만 적용 (2026-08-12 확인)
    esp_camera_sensor_get()->set_vflip(esp_camera_sensor_get(), 1);

    // s_bus_result_lock은 대시보드(웹)가 항상 참조하므로, 태스크 생성 전에 먼저 만든다.
    s_bus_result_lock = xSemaphoreCreateMutex();

#if !TEST_SKIP_MODEL_LOAD
    // 카메라가 만든 I2C 버스에 조도센서를 얹는다 (실패해도 계속 진행)
    als_init();
    xTaskCreate(ir_task, "ir_task", 8192, NULL, 4, NULL);   // TTS 디코딩 여유

    // 장애물(기본)/버스/점자블록 모드 상태머신 — 한 번에 하나의 모델만 메모리에 올려두고
    // RPi(ttyACM1)의 0x01/0x02 명령으로 모드를 전환한다.
    xTaskCreate(cane_mode_task, "cane_mode_task", 16384, NULL, 3, NULL);
#else
    ESP_LOGW(TAG, "[TEST_SKIP_MODEL_LOAD] IR/스피커/조도센서/cane_mode_task 끔 — 예전(esp32ocr 이식 직후) 상태로 되돌려서 카메라+WiFi+버스OCR+웹 대시보드(80/81)만 테스트");
    xTaskCreate(bus_ocr_only_task, "bus_ocr_only_task", 16384, NULL, 3, NULL);
#endif
    // WiFi 연결 — video_push_task보다 반드시 먼저 해야 한다. wifi_init() 안에서
    // esp_netif_init()이 lwIP tcpip_thread를 띄우는데, 그 전에 socket()을 부르면
    // "Invalid mbox" assert로 죽는다 (2026-08-12에 실제로 겪음, 개발기록 참고).
    ESP_LOGI(TAG, "WiFi 연결 중...");
    wifi_init();

    // sdkconfig 교체로 브라운아웃 원인 해결 확인됐으니, 이번엔 HTTP MJPEG 대신
    // RPi TCP 푸시(video_push_task)로 되돌려서 테스트.
    xTaskCreate(video_push_task, "video_push_task", 8192, NULL, 2, NULL);

    // HTTP MJPEG 대시보드는 이번 테스트에서 꺼둠 (TCP 푸시만 확인)
    // start_webserver();
    // ESP_LOGI(TAG, "스트리밍 서버 시작");
}
